"""Embedding providers for markdown-vault-mcp.

Provides an :class:`EmbeddingProvider` ABC and four concrete implementations:

- :class:`OllamaProvider` — Ollama server; embeds via Ollama's
  OpenAI-compatible endpoint (``{host}/v1``), with the native REST API kept
  for capabilities the compatibility layer cannot express (CPU-only
  inference, the context-length probe).
- :class:`OpenAIProvider` — OpenAI-compatible Embeddings API via the
  official ``openai`` SDK.
- :class:`VoyageProvider` — Voyage AI's OpenAI-compatible Embeddings API,
  with the base URL pinned to ``https://api.voyageai.com/v1``.
- :class:`FastEmbedProvider` — local fastembed/ONNX runtime embeddings.

All three API providers share one wire protocol and one client
(:class:`_OpenAICompatEmbeddings`); the provider names are ergonomic presets
over it, not separate code paths (#916).

Use :func:`get_embedding_provider` to auto-detect and return the best
available provider based on a :class:`ProjectConfig` instance.
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

from markdown_vault_mcp.exceptions import ConfigurationError

if TYPE_CHECKING:
    from markdown_vault_mcp.config import ProjectConfig

logger = logging.getLogger(__name__)

# Maximum texts per ONNX inference call inside FastEmbed.
# BAAI/bge-small-en-v1.5 (512-token context, the default model) has a
# manageable attention footprint even at batch_size=32.  If you switch to a
# long-context model such as nomic-embed-text-v1.5 (8192-token context) you
# may need to reduce this value significantly — see issue #306.
_FASTEMBED_ONNX_BATCH_SIZE = 32

# FastEmbed's model registry exposes only `dim`, not context length, so we
# carry a small table for the models we default to / commonly use. Unknown
# models return None and fall back to a conservative chunk cap.
_FASTEMBED_CONTEXT_LENGTHS: dict[str, int] = {
    "BAAI/bge-small-en-v1.5": 512,
    "BAAI/bge-base-en-v1.5": 512,
    "nomic-ai/nomic-embed-text-v1.5": 8192,
    "jinaai/jina-embeddings-v2-base-en": 8192,
}

# OpenAI's embeddings API does not report a model's context length, so we
# carry a table for the supported models. Unknown models return None and
# fall back to a conservative chunk cap.
_OPENAI_CONTEXT_LENGTHS: dict[str, int] = {
    "text-embedding-3-small": 8191,
    "text-embedding-3-large": 8191,
    "text-embedding-ada-002": 8191,
}

# Voyage's embeddings API does not report a model's context length either, so
# the same table treatment applies. Values from https://docs.voyageai.com —
# the voyage-4 and voyage-3.5 families, voyage-code-3 and voyage-finance-2 all
# take 32k tokens; voyage-law-2 takes 16k. Unknown models return None and fall
# back to a conservative chunk cap.
_VOYAGE_CONTEXT_LENGTHS: dict[str, int] = {
    "voyage-4-large": 32000,
    "voyage-4": 32000,
    "voyage-4-lite": 32000,
    "voyage-3.5": 32000,
    "voyage-3.5-lite": 32000,
    "voyage-code-3": 32000,
    "voyage-finance-2": 32000,
    "voyage-law-2": 16000,
}


# The openai SDK requires a non-None api_key string even for servers that
# ignore auth (Ollama's own docs suggest this placeholder).
_PLACEHOLDER_API_KEY = "ollama"


class _OpenAICompatEmbeddings:
    """Shared OpenAI-compatible embeddings transport (official openai SDK).

    Owns the SDK client, the ``embeddings.create`` call, input-order
    restoration, and error mapping. :class:`OpenAIProvider` and
    :class:`OllamaProvider` are thin presets over this one code path.

    Args:
        api_key: API key, or ``None`` for keyless endpoints (a placeholder
            is sent; e.g. Ollama ignores it).
        base_url: OpenAI-compatible endpoint base URL.
        model: Embedding model name.
        label: Provider label used in error messages.
        timeout: Per-request timeout in seconds for the underlying SDK client.
    """

    def __init__(
        self,
        api_key: str | None,
        *,
        base_url: str,
        model: str,
        label: str,
        timeout: float = 30.0,
    ) -> None:
        try:
            import openai
        except ImportError as exc:
            raise ImportError(
                f"{label} requires the 'openai' SDK. "
                "Install it with: pip install 'markdown-vault-mcp[embeddings-api]'"
            ) from exc
        self._openai = openai
        self._client = openai.OpenAI(
            api_key=api_key or _PLACEHOLDER_API_KEY,
            base_url=base_url,
            timeout=timeout,
        )
        self._model = model
        self._label = label

    def embed(self, texts: list[str]) -> list[list[float]]:
        """Embed a batch of texts, returning vectors in input order.

        Args:
            texts: List of strings to embed.

        Returns:
            List of embedding vectors, one per input text.

        Raises:
            RuntimeError: If the embeddings request fails.
        """
        try:
            response = self._client.embeddings.create(model=self._model, input=texts)
        except self._openai.OpenAIError as exc:
            raise RuntimeError(
                f"{self._label} embeddings request failed: {exc}"
            ) from exc
        # Sort by index to guarantee input order is preserved.
        items = sorted(response.data, key=lambda d: d.index)
        return [item.embedding for item in items]


class EmbeddingProvider(ABC):
    """Abstract base class for embedding providers."""

    @abstractmethod
    def embed(self, texts: list[str]) -> list[list[float]]:
        """Embed a batch of texts.

        Args:
            texts: List of strings to embed.

        Returns:
            List of embedding vectors, one per input text.
        """
        ...

    @property
    @abstractmethod
    def dimension(self) -> int:
        """Embedding dimension size.

        Returns:
            Integer dimension of each embedding vector.
        """
        ...

    @property
    @abstractmethod
    def provider_name(self) -> str:
        """Stable provider identifier for index compatibility metadata."""
        ...

    @property
    @abstractmethod
    def model_name(self) -> str:
        """Stable model identifier for index compatibility metadata."""
        ...

    @property
    @abstractmethod
    def context_length(self) -> int | None:
        """Maximum input length the model accepts, in tokens.

        Returns None when the limit cannot be determined; callers fall back
        to a conservative default. Used to derive a conservative chunker char
        cap that keeps chunks comfortably under the model's token limit (a
        token-dense batch that still exceeds it is skipped at embed time).
        """
        ...


class OllamaProvider(EmbeddingProvider):
    """Embedding provider backed by an Ollama server.

    Embeds via Ollama's OpenAI-compatible endpoint (``{host}/v1``) through
    the shared :class:`_OpenAICompatEmbeddings` transport — the provider is
    a preset over one wire protocol, not a second code path (#916). Two
    capabilities have no OpenAI-API equivalent and keep the native REST API:
    CPU-only inference (``options.num_gpu``, ``embed()`` when *cpu_only*)
    and the ``/api/show`` context-length probe.

    Args:
        host: Base URL of the Ollama server.
        model: Model name to use for embeddings.
        cpu_only: When ``True``, request CPU-only inference (sets
            ``num_gpu=0`` in the Ollama options payload; native API).
        timeout: Per-request timeout in seconds for HTTP calls to Ollama.
    """

    def __init__(
        self, host: str, model: str, *, cpu_only: bool = False, timeout: float = 30.0
    ) -> None:
        """Initialise OllamaProvider with explicit parameters.

        Args:
            host: Base URL of the Ollama server.
            model: Model name to use for embeddings.
            cpu_only: When ``True``, request CPU-only inference.
            timeout: Per-request timeout in seconds for HTTP calls to Ollama.

        Raises:
            ImportError: If ``httpx`` is not installed, or the ``openai``
                SDK is not installed (unless *cpu_only*, which only needs
                the native API).
        """
        try:
            import httpx
        except ImportError as exc:
            raise ImportError(
                "OllamaProvider requires 'httpx'. "
                "Install it with: pip install 'markdown-vault-mcp[embeddings-api]'"
            ) from exc

        self._httpx = httpx
        self._host = host.rstrip("/")
        self._model = model
        self._cpu_only = cpu_only
        self._timeout = timeout
        # CPU-only requests need options.num_gpu, which the OpenAI-compat
        # endpoint cannot express — that path stays native and needs no SDK.
        self._compat = (
            None
            if cpu_only
            else _OpenAICompatEmbeddings(
                None,
                base_url=f"{self._host}/v1",
                model=model,
                label="OllamaProvider",
                timeout=timeout,
            )
        )
        self._dimension: int | None = None
        self._context_length: int | None = None
        self._context_queried = False

        logger.debug(
            "OllamaProvider initialised: host=%s model=%s cpu_only=%s",
            self._host,
            self._model,
            self._cpu_only,
        )

    def _embed_native(self, texts: list[str]) -> list[list[float]]:
        """Embed via the native ``/api/embed`` endpoint (CPU-only path).

        Args:
            texts: List of strings to embed.

        Returns:
            List of embedding vectors, one per input text.

        Raises:
            RuntimeError: If the Ollama API returns an error response.
        """
        payload: dict[str, object] = {
            "model": self._model,
            "input": texts,
            "options": {"num_gpu": 0},
        }
        url = f"{self._host}/api/embed"
        logger.debug("POST %s model=%s texts=%d", url, self._model, len(texts))

        with self._httpx.Client() as client:
            response = client.post(url, json=payload, timeout=self._timeout)

        if response.status_code != 200:
            raise RuntimeError(
                f"Ollama API error {response.status_code}: {response.text}"
            )

        data = response.json()
        embeddings: list[list[float]] = data["embeddings"]
        return embeddings

    def embed(self, texts: list[str]) -> list[list[float]]:
        """Embed a batch of texts.

        Uses the OpenAI-compatible endpoint; falls back to the native API
        only when *cpu_only* was requested.

        Args:
            texts: List of strings to embed.

        Returns:
            List of embedding vectors, one per input text.

        Raises:
            RuntimeError: If the embeddings request fails.
        """
        if self._compat is None:
            embeddings = self._embed_native(texts)
        else:
            embeddings = self._compat.embed(texts)

        # Cache dimension from first successful call.
        if self._dimension is None and embeddings:
            self._dimension = len(embeddings[0])

        return embeddings

    @property
    def dimension(self) -> int:
        """Embedding dimension size.

        Embeds a test string on first access to determine the dimension.

        Returns:
            Integer dimension of each embedding vector.
        """
        if self._dimension is None:
            self.embed(["dimension probe"])
        if self._dimension is None:
            raise RuntimeError(
                "OllamaProvider.embed() returned no embeddings; "
                "cannot determine dimension."
            )
        return self._dimension

    @property
    def provider_name(self) -> str:
        return "ollama"

    @property
    def model_name(self) -> str:
        return self._model

    @property
    def context_length(self) -> int | None:
        """Query /api/show once for the model's context length; cache it.

        Returns None if the query fails or the field is absent. The result
        (including ``None`` on failure) is cached permanently for the provider
        instance — a transiently-unreachable Ollama at startup is not retried,
        so the conservative fallback cap persists until the server restarts.
        """
        if self._context_queried:
            return self._context_length
        self._context_queried = True
        try:
            with self._httpx.Client() as client:
                resp = client.post(
                    f"{self._host}/api/show",
                    json={"model": self._model},
                    timeout=10.0,
                )
            if resp.status_code != 200:
                logger.warning(
                    "ollama_context_length_unavailable model=%s status=%s",
                    self._model,
                    resp.status_code,
                )
                return None
            data = resp.json()
            info = data.get("model_info", {}) if isinstance(data, dict) else None
            if not isinstance(info, dict):
                # A well-behaved Ollama returns an object whose model_info is an
                # object; a proxy/error page (or a malformed model_info) could
                # be a list or string, on which .get()/.items() would raise an
                # uncaught AttributeError and crash startup.
                logger.warning("ollama_context_length_absent model=%s", self._model)
                return None
            for key, value in info.items():
                if key.endswith(".context_length") and isinstance(value, int):
                    self._context_length = value
                    return value
            logger.warning("ollama_context_length_absent model=%s", self._model)
            return None
        except (self._httpx.HTTPError, ValueError) as exc:
            # httpx network/timeout errors (ConnectError, TimeoutException, ...)
            # subclass httpx.HTTPError, NOT OSError; a malformed body raises
            # JSONDecodeError (a ValueError). Catching both keeps an unreachable
            # Ollama at startup from crashing config construction (config.py
            # reads this eagerly to derive the chunk char cap).
            logger.warning(
                "ollama_context_length_query_failed model=%s err=%s",
                self._model,
                exc,
            )
            return None


class OpenAIProvider(EmbeddingProvider):
    """Embedding provider backed by the OpenAI-compatible Embeddings API.

    Args:
        api_key: OpenAI API key for authentication.
        base_url: Base URL for an OpenAI-compatible API.
        model: Embedding model name.
        timeout: Per-request timeout in seconds for the underlying SDK client.
    """

    _MODEL = "text-embedding-3-small"
    _BASE_URL = "https://api.openai.com/v1"

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = _BASE_URL,
        model: str = _MODEL,
        timeout: float = 30.0,
    ) -> None:
        """Initialise OpenAIProvider with an explicit API key.

        Args:
            api_key: OpenAI API key for authentication.
            base_url: Base URL for an OpenAI-compatible API.
            model: Embedding model name.
            timeout: Per-request timeout in seconds for the underlying SDK client.

        Raises:
            ImportError: If the ``openai`` SDK is not installed.
            RuntimeError: If ``api_key`` is empty.
        """
        if not api_key:
            raise RuntimeError("OpenAIProvider requires a non-empty api_key.")
        self._base_url = (base_url or self._BASE_URL).rstrip("/")
        self._model = model or self._MODEL
        self._compat = _OpenAICompatEmbeddings(
            api_key,
            base_url=self._base_url,
            model=self._model,
            label="OpenAIProvider",
            timeout=timeout,
        )
        self._dimension: int | None = None

        logger.debug(
            "OpenAIProvider initialised: base_url=%s model=%s",
            self._base_url,
            self._model,
        )

    def embed(self, texts: list[str]) -> list[list[float]]:
        """Embed a batch of texts via the OpenAI-compatible Embeddings API.

        Args:
            texts: List of strings to embed.

        Returns:
            List of embedding vectors in input order.

        Raises:
            RuntimeError: If the embeddings request fails.
        """
        embeddings = self._compat.embed(texts)

        # Cache dimension from first successful call.
        if self._dimension is None and embeddings:
            self._dimension = len(embeddings[0])

        return embeddings

    @property
    def dimension(self) -> int:
        """Embedding dimension size.

        Embeds a test string on first access to determine the dimension.

        Returns:
            Integer dimension of each embedding vector.
        """
        if self._dimension is None:
            self.embed(["dimension probe"])
        if self._dimension is None:
            raise RuntimeError(
                "OpenAIProvider.embed() returned no embeddings; "
                "cannot determine dimension."
            )
        return self._dimension

    @property
    def provider_name(self) -> str:
        return "openai"

    @property
    def model_name(self) -> str:
        return self._model

    @property
    def context_length(self) -> int | None:
        """Return the model's context length from the known-model table.

        Returns None for models absent from the table; callers fall back to a
        conservative chunk cap.
        """
        return _OPENAI_CONTEXT_LENGTHS.get(self._model)


class VoyageProvider(EmbeddingProvider):
    """Embedding provider backed by Voyage AI's Embeddings API.

    Voyage serves ``/v1/embeddings`` in the OpenAI request/response shape, so
    this is a preset over the shared :class:`_OpenAICompatEmbeddings`
    transport with the base URL pinned to Voyage's endpoint — the same
    relationship :class:`OllamaProvider` has to it (#916). Pointing
    :class:`OpenAIProvider` at ``https://api.voyageai.com/v1`` by hand keeps
    working; the dedicated provider name exists so the endpoint, the key
    variable and the model default are discoverable rather than folklore.

    Voyage rejects OpenAI request fields it does not implement: ``dimensions``
    and ``user`` are answered with HTTP 400, and ``encoding_format="float"``
    with "accepted values are 'base64'". The shared transport sends only
    ``model`` and ``input`` and leaves ``encoding_format`` to the ``openai``
    SDK, whose base64 default Voyage accepts — so no request shaping is needed
    here, but none of those three fields may start being sent either.

    Args:
        api_key: Voyage API key for authentication.
        model: Embedding model name.
        timeout: Per-request timeout in seconds for HTTP calls to Voyage.
    """

    # Voyage's own guidance is voyage-4-large for the best quality,
    # voyage-4-lite for the lowest latency and cost, and voyage-4 for the
    # balance between them, so the balanced member is the default — the same
    # posture as text-embedding-3-small for OpenAI. The whole voyage-4 family
    # returns 1024-dimensional vectors by default.
    _MODEL = "voyage-4"
    _BASE_URL = "https://api.voyageai.com/v1"

    def __init__(
        self, api_key: str, *, model: str = _MODEL, timeout: float = 30.0
    ) -> None:
        """Initialise VoyageProvider with an explicit API key.

        Args:
            api_key: Voyage API key for authentication.
            model: Embedding model name.
            timeout: Per-request timeout in seconds for HTTP calls to Voyage.

        Raises:
            ImportError: If the ``openai`` SDK is not installed.
            RuntimeError: If ``api_key`` is empty.
        """
        if not api_key:
            raise RuntimeError(
                "VoyageProvider requires a non-empty api_key. Set VOYAGE_API_KEY."
            )
        self._model = model or self._MODEL
        self._compat = _OpenAICompatEmbeddings(
            api_key,
            base_url=self._BASE_URL,
            model=self._model,
            label="VoyageProvider",
            timeout=timeout,
        )
        self._dimension: int | None = None

        logger.debug("VoyageProvider initialised: model=%s", self._model)

    def embed(self, texts: list[str]) -> list[list[float]]:
        """Embed a batch of texts via Voyage's Embeddings API.

        Args:
            texts: List of strings to embed.

        Returns:
            List of embedding vectors in input order.

        Raises:
            RuntimeError: If the embeddings request fails.
        """
        embeddings = self._compat.embed(texts)

        # Cache dimension from first successful call.
        if self._dimension is None and embeddings:
            self._dimension = len(embeddings[0])

        return embeddings

    @property
    def dimension(self) -> int:
        """Embedding dimension size.

        Embeds a test string on first access to determine the dimension.

        Returns:
            Integer dimension of each embedding vector.
        """
        if self._dimension is None:
            self.embed(["dimension probe"])
        if self._dimension is None:
            raise RuntimeError(
                "VoyageProvider.embed() returned no embeddings; "
                "cannot determine dimension."
            )
        return self._dimension

    @property
    def provider_name(self) -> str:
        return "voyage"

    @property
    def model_name(self) -> str:
        return self._model

    @property
    def context_length(self) -> int | None:
        """Return the model's context length from the known-model table.

        Returns None for models absent from the table; callers fall back to a
        conservative chunk cap.
        """
        return _VOYAGE_CONTEXT_LENGTHS.get(self._model)


class FastEmbedProvider(EmbeddingProvider):
    """Embedding provider backed by the local fastembed library.

    The ``fastembed`` package is imported lazily at instantiation
    time so that it does not need to be installed unless this provider is used.
    """

    def __init__(
        self,
        model_name: str = "BAAI/bge-small-en-v1.5",
        cache_dir: str | None = None,
    ) -> None:
        """Initialise FastEmbed model.

        Args:
            model_name: FastEmbed model identifier.
            cache_dir: Optional model cache directory.

        Raises:
            ImportError: If ``fastembed`` is not installed.
        """
        try:
            from fastembed import TextEmbedding
        except ImportError as exc:
            raise ImportError(
                "FastEmbedProvider requires 'fastembed'. "
                "Install it with: pip install 'markdown-vault-mcp[embeddings]'"
            ) from exc

        self._model_name = model_name
        self._cache_dir = cache_dir
        if self._cache_dir:
            self._model = TextEmbedding(
                model_name=self._model_name, cache_dir=self._cache_dir
            )
        else:
            self._model = TextEmbedding(model_name=self._model_name)
        self._dimension: int | None = None
        logger.debug(
            "FastEmbedProvider initialised: model=%s cache_dir=%s",
            self._model_name,
            self._cache_dir,
        )

    def embed(self, texts: list[str]) -> list[list[float]]:
        """Embed a batch of texts using the local fastembed model.

        Args:
            texts: List of strings to embed.

        Returns:
            List of embedding vectors, one per input text.
        """
        vectors = [
            vector.tolist()
            for vector in self._model.embed(
                texts, batch_size=_FASTEMBED_ONNX_BATCH_SIZE
            )
        ]
        if self._dimension is None and vectors:
            self._dimension = len(vectors[0])
        return vectors

    @property
    def dimension(self) -> int:
        """Embedding dimension size from the loaded model.

        Returns:
            Integer dimension of each embedding vector.
        """
        if self._dimension is None:
            self.embed(["dimension probe"])
        if self._dimension is None:
            raise RuntimeError(
                "FastEmbedProvider.embed() returned no embeddings; "
                "cannot determine dimension."
            )
        return self._dimension

    @property
    def provider_name(self) -> str:
        return "fastembed"

    @property
    def model_name(self) -> str:
        return self._model_name

    @property
    def context_length(self) -> int | None:
        """Return the model's context length from the known-model table.

        Returns None for models absent from the table; callers fall back to a
        conservative chunk cap.
        """
        return _FASTEMBED_CONTEXT_LENGTHS.get(self._model_name)


def _explicit_provider(name: str, config: ProjectConfig) -> EmbeddingProvider:
    """Build the provider named by ``EMBEDDING_PROVIDER``.

    Split out of :func:`get_embedding_provider` so the explicit dispatch and
    the auto-detect probe stay independently readable as provider names are
    added.

    Args:
        name: Normalised (stripped, lower-cased) provider name; never empty.
        config: Vault configuration containing embedding settings.

    Returns:
        An initialised :class:`EmbeddingProvider` instance.

    Raises:
        ConfigurationError: If *name* is not a recognised provider.
    """
    if name == "openai":
        logger.info("Using OpenAIProvider (embedding_provider=openai)")
        return OpenAIProvider(
            api_key=config.embeddings.openai_api_key or "",
            base_url=config.embeddings.openai_base_url,
            model=config.embeddings.openai_embedding_model,
            timeout=config.embeddings.embed_timeout_s,
        )

    if name == "voyage":
        logger.info("Using VoyageProvider (embedding_provider=voyage)")
        return VoyageProvider(
            api_key=config.embeddings.voyage_api_key or "",
            model=config.embeddings.voyage_model,
            timeout=config.embeddings.embed_timeout_s,
        )

    if name == "ollama":
        logger.info("Using OllamaProvider (embedding_provider=ollama)")
        return OllamaProvider(
            host=config.embeddings.ollama_host,
            model=config.embeddings.ollama_model,
            cpu_only=config.embeddings.ollama_cpu_only,
            timeout=config.embeddings.embed_timeout_s,
        )

    if name == "fastembed":
        logger.info("Using FastEmbedProvider (embedding_provider=%s)", name)
        return FastEmbedProvider(
            model_name=config.embeddings.fastembed_model,
            cache_dir=config.embeddings.fastembed_cache_dir,
        )

    raise ConfigurationError(
        f"Unrecognised embedding_provider value: {name!r}. "
        "Valid values: 'openai', 'voyage', 'ollama', 'fastembed'."
    )


def get_embedding_provider(config: ProjectConfig) -> EmbeddingProvider:
    """Auto-detect and return an embedding provider from config.

    Checks ``config.embeddings.provider`` for an explicit selection. When
    that field is ``None``, probes for available providers in this order:

    1. If ``config.embeddings.openai_api_key`` is set → :class:`OpenAIProvider`.
    2. If Ollama is reachable at ``config.embeddings.ollama_host`` →
       :class:`OllamaProvider`.
    3. If ``fastembed`` can be imported →
       :class:`FastEmbedProvider`.
    4. Raises :class:`RuntimeError` with installation instructions.

    :class:`VoyageProvider` is deliberately absent from that probe: a
    ``VOYAGE_API_KEY`` exported for some other tool must not silently take over
    an existing index. Select it explicitly with ``EMBEDDING_PROVIDER=voyage``.

    Args:
        config: Vault configuration containing embedding settings.

    Returns:
        An initialised :class:`EmbeddingProvider` instance.

    Raises:
        RuntimeError: If no provider is available and
            ``config.embeddings.provider`` is not set, or if the explicitly
            requested provider cannot be initialised.
        ConfigurationError: If ``config.embeddings.provider`` is set to an
            unrecognised value.
    """
    explicit = (config.embeddings.provider or "").strip().lower()

    if explicit:
        return _explicit_provider(explicit, config)

    # Auto-detect: OpenAI API key present?
    if config.embeddings.openai_api_key:
        logger.info("Auto-detected OpenAIProvider (openai_api_key is set)")
        return OpenAIProvider(
            api_key=config.embeddings.openai_api_key,
            base_url=config.embeddings.openai_base_url,
            model=config.embeddings.openai_embedding_model,
            timeout=config.embeddings.embed_timeout_s,
        )

    # Auto-detect: Ollama reachable? (EmbeddingsConfig.__post_init__ already
    # guarantees ollama_host is non-empty with no trailing slash.)
    host = config.embeddings.ollama_host
    try:
        import httpx

        with httpx.Client(timeout=2.0) as client:
            response = client.get(f"{host}/api/tags")
        if response.status_code == 200:
            logger.info("Auto-detected OllamaProvider (Ollama reachable at %s)", host)
            return OllamaProvider(
                host=host,
                model=config.embeddings.ollama_model,
                cpu_only=config.embeddings.ollama_cpu_only,
                timeout=config.embeddings.embed_timeout_s,
            )
    except Exception:
        logger.debug("Ollama not reachable at %s, skipping", host)

    # Auto-detect: fastembed importable?
    try:
        import fastembed  # noqa: F401

        logger.info("Auto-detected FastEmbedProvider")
        return FastEmbedProvider(
            model_name=config.embeddings.fastembed_model,
            cache_dir=config.embeddings.fastembed_cache_dir,
        )
    except ImportError:
        logger.debug("fastembed not available, skipping")

    raise RuntimeError(
        "No embedding provider is available. Install one of:\n"
        "  pip install 'markdown-vault-mcp[embeddings-api]'  # OpenAI or Ollama (API)\n"
        "  pip install 'markdown-vault-mcp[embeddings]'       # fastembed (local)\n"
        "Or set OPENAI_API_KEY for the OpenAI provider, "
        "or start an Ollama server for the Ollama provider."
    )
