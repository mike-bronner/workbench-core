"""Data types for markdown-vault-mcp."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal, Protocol

# The four deterministic, non-excluded skip categories surfaced via
# get_index_status.skipped_files. A plain frozenset (not an enum) keeps the
# tool payload JSON-trivial; tests/test_types.py pins the legal values and
# the producer tests assert each category is emitted for the right failure.
# ``internal_error`` covers a genuinely-unexpected exception from parse_note
# (a code/chunker bug), as opposed to ``parse_error`` for malformed content.
SKIP_CATEGORIES: frozenset[str] = frozenset(
    {"parse_error", "encoding_error", "missing_frontmatter", "internal_error"}
)


@dataclass(frozen=True)
class SkippedFile:
    """A file deliberately dropped from the index for a surfaced reason.

    Attributes:
        path: Source-dir-relative POSIX path of the skipped file.
        category: One of :data:`SKIP_CATEGORIES` — ``"parse_error"``,
            ``"encoding_error"``, ``"missing_frontmatter"``, or
            ``"internal_error"``.
        detail: Human-readable reason (a YAML/decode error message, or
            ``"missing: [field, ...]"`` for missing frontmatter).
    """

    path: str
    category: str
    detail: str


@dataclass
class Chunk:
    """A chunk of a document, typically a section under a heading.

    Attributes:
        heading: Section heading text, or ``None`` for the document intro.
        heading_level: Markdown heading level (1-6); 0 for intro chunks.
        content: Plain text content of this chunk.
        start_line: 1-based line number where this chunk begins in the source.
    """

    heading: str | None
    heading_level: int
    content: str
    start_line: int


@dataclass
class LinkInfo:
    """A link extracted from a markdown document.

    Attributes:
        target_path: Resolved relative path of the link target.
        link_text: Display text of the link.
        link_type: Link syntax: ``"markdown"`` (``[text](path)``), ``"wikilink"`` (``[[path]]``), or ``"reference"`` (``[text][ref]``).
        fragment: Heading anchor (``#section``) if present in the link target.
        raw_target: The unresolved link target exactly as written in the source.
    """

    target_path: str
    link_text: str
    link_type: Literal["markdown", "wikilink", "reference"]
    fragment: str | None = None
    raw_target: str = ""


@dataclass
class ParsedNote:
    """A parsed markdown document with extracted structure.

    Attributes:
        path: Relative path from the vault root.
        frontmatter: Parsed YAML frontmatter as a dict.
        title: Document title derived from the first H1 heading or filename.
        chunks: Ordered list of content chunks split by heading.
        content_hash: SHA-256 hash of the raw file content for change detection.
        modified_at: Last-modified time as a Unix timestamp float.
        links: All links extracted from the document body.
        content_chars: Character count of the document body as parsed:
            frontmatter removed and surrounding whitespace normalised by the
            frontmatter parser. Measured before chunking, because
            ``chunk_overlap_words`` duplicates text across chunks and would
            inflate any count summed from :attr:`chunks`.
    """

    path: str
    frontmatter: dict[str, Any]
    title: str
    chunks: list[Chunk]
    content_hash: str
    modified_at: float
    links: list[LinkInfo] = field(default_factory=list)
    content_chars: int = 0


@dataclass
class DocumentMeta:
    """Lightweight document metadata from the index, without loading content.

    Returned by :meth:`~markdown_vault_mcp.facets.reader.ReaderFacet.get_metadata`.
    Sourced from the FTS ``documents`` row, so callers that need only a title /
    folder / frontmatter (e.g. graph node labels) avoid the full, size-capped
    :meth:`~markdown_vault_mcp.facets.reader.ReaderFacet.read`. Like
    :class:`NoteInfo` but without ``modified_at`` / ``kind`` — a pure label
    source, not a directory-listing entry.

    Attributes:
        path: Relative document path.
        title: Document title (frontmatter title, first H1, or filename).
        folder: Parent folder path.
        frontmatter: Parsed YAML frontmatter.
    """

    path: str
    title: str
    folder: str
    frontmatter: dict[str, Any]


@dataclass
class SearchResult:
    """A search result from :meth:`~markdown_vault_mcp.facets.reader.ReaderFacet.search`.

    Attributes:
        path: Relative path of the document containing this chunk.
        title: Document title.
        folder: Parent folder path.
        heading: Section heading this chunk falls under, or ``None`` for the intro.
        content: Matched chunk text — a query-relevant snippet by default
            (approximately ``snippet_words`` words plus optional leading/trailing
            ellipsis markers, centred on matched terms). Pass
            ``snippet_words=0`` to ``search`` for the full chunk verbatim,
            or recover the full chunk after seeing a snippet via
            ``read(path, section=heading)``.
        score: Relevance score. Higher is better; not comparable across search types.
        search_type: ``"keyword"`` (BM25), ``"semantic"`` (cosine similarity),
            or ``"hybrid"`` (chunk appeared in both keyword and semantic channels).
        frontmatter: Parsed YAML frontmatter of the parent document.
    """

    path: str
    title: str
    folder: str
    heading: str | None
    content: str
    score: float
    search_type: Literal["keyword", "semantic", "hybrid"]
    frontmatter: dict[str, Any]


@dataclass
class SectionHit:
    """One section's contribution to a :class:`GroupedResult`.

    Attributes:
        heading: Section heading text, or ``None`` for the document intro.
        content: Matched snippet — query-relevant window by default, or full
            chunk if ``snippet_words=0`` was passed.
        score: Chunk-level relevance score after length-downweight.  Not
            comparable across search modes.
    """

    heading: str | None
    content: str
    score: float


@dataclass
class GroupedResult:
    """A file-grouped search result.

    Replaces the flat per-chunk :class:`SearchResult` across ``search``,
    ``get_similar``, and ``get_context.similar``.  See issue #469.

    Attributes:
        path: Relative path of the document.
        title: Document title.
        folder: Parent folder path.
        score: File-level score = ``max(section.score for section in sections)``.
        search_type: ``"keyword"``, ``"semantic"``, or ``"hybrid"``.
        frontmatter: Parsed YAML frontmatter.
        sections: Up to the per-file cap best-matching sections, sorted by
            ``(score DESC, start_line ASC, section_id ASC)`` so ties surface
            in document order — the ``section_id`` key gives a fully
            deterministic order even when chunks share a ``start_line``
            (e.g. word-split fragments of one oversize source line).
    """

    path: str
    title: str
    folder: str
    score: float
    search_type: Literal["keyword", "semantic", "hybrid"]
    frontmatter: dict[str, Any]
    sections: list[SectionHit]


@dataclass
class FTSResult:
    """A raw search result from the FTS5 index layer.

    Attributes:
        path: Relative path of the document containing this chunk.
        title: Document title.
        folder: Parent folder path.
        heading: Section heading this chunk falls under, or ``None``.
        content: Matched chunk text — full chunk by default; truncated to a
            tokenizer-aware snippet when ``snippet_words`` is passed to the
            search call.
        score: BM25 relevance score (higher is better).
        chunk_count: Total number of chunks belonging to the parent document.
        start_line: Line number of the chunk's first line in the source
            document.  Defaults to ``0`` for the document intro chunk and as
            a fallback when the underlying section row cannot be resolved.
        section_id: ``sections`` table rowid of the matched chunk, used as
            the final deterministic tie-break when chunks share both
            ``score`` and ``start_line`` (e.g. word-split fragments of one
            oversize source line).  Defaults to ``0`` when the section row
            cannot be resolved (legacy index) or for non-keyword channels.
    """

    path: str
    title: str
    folder: str
    heading: str | None
    content: str
    score: float
    chunk_count: int = 1
    start_line: int = 0
    section_id: int = 0


@dataclass
class NoteContent:
    """Full content of a document, returned by :meth:`~markdown_vault_mcp.facets.reader.ReaderFacet.read`.

    Attributes:
        path: Relative path from the vault root (e.g. ``Journal/note.md``).
        title: Document title derived from the first H1 heading or filename.
        folder: Parent folder path (empty string for root-level documents).
        content: Raw markdown body including frontmatter.
        frontmatter: Parsed YAML frontmatter as a dict.
        modified_at: Last-modified time as a Unix timestamp float.
        etag: Opaque hash of file content for optimistic concurrency checks.
    """

    path: str
    title: str
    folder: str
    content: str
    frontmatter: dict[str, Any]
    modified_at: float
    etag: str | None = None


@dataclass
class NoteInfo:
    """Summary info for a document, returned by :meth:`~markdown_vault_mcp.facets.reader.ReaderFacet.list_documents`.

    Attributes:
        path: Relative path from the vault root.
        title: Document title.
        folder: Parent folder path.
        frontmatter: Parsed YAML frontmatter.
        modified_at: Last-modified time as a Unix timestamp float.
        kind: Always ``"note"`` for markdown documents; distinguishes from :class:`AttachmentInfo`.
        content_chars: Character count of the note body, frontmatter excluded,
            so a caller can budget batches without reading the note (#1039).
            ``0`` for a row indexed before this field existed, and for rows
            from queries that select a narrower column set.
    """

    path: str
    title: str
    folder: str
    frontmatter: dict[str, Any]
    modified_at: float
    kind: str = "note"
    content_chars: int = 0


@dataclass
class WriteResult:
    """Result of a write operation.

    Attributes:
        path: Relative path of the document that was written.
        created: ``True`` if the document was newly created; ``False`` if overwritten.
    """

    path: str
    created: bool


@dataclass
class EditResult:
    """Result of an edit operation.

    Attributes:
        path: Relative path of the document that was edited.
        replacements: Number of text replacements made (always 1 for exact match).
        match_type: How the replacement was found: ``"exact"`` (verbatim match) or ``"normalized"`` (whitespace-normalised match).
    """

    path: str
    replacements: int
    match_type: str = "exact"


@dataclass
class DeleteResult:
    """Result of a delete operation.

    Attributes:
        path: Relative path of the document that was deleted.
    """

    path: str


@dataclass
class RenameResult:
    """Result of a rename operation.

    Attributes:
        old_path: Original relative path.
        new_path: New relative path after the rename.
        updated_links: Number of backlinks in other documents that were rewritten.
    """

    old_path: str
    new_path: str
    updated_links: int = 0


@dataclass
class MoveFolderResult:
    """Result of a folder-level move operation.

    Not frozen — ``failed_links`` is a mutable list (matching the other
    result dataclasses such as :class:`RenameResult` and :class:`IndexStats`),
    and a frozen dataclass holding a list neither prevents in-place mutation
    nor stays hashable.

    Attributes:
        old_dir: Original relative folder prefix that was moved.
        new_dir: New relative folder prefix after the move.
        files_moved: Total number of files moved (notes + attachments +
            other files).
        updated_links: Number of source documents whose links were
            successfully rewritten to point into the new prefix.
        failed_links: Relative paths of source documents whose link rewrite
            failed (best-effort; logged and skipped, not aborted).
    """

    old_dir: str
    new_dir: str
    files_moved: int
    updated_links: int = 0
    failed_links: list[str] = field(default_factory=list)


@dataclass
class IndexStats:
    """Statistics from :meth:`~markdown_vault_mcp.facets.index.IndexFacet.build_index`.

    Attributes:
        documents_indexed: Number of documents successfully indexed.
        chunks_indexed: Total number of chunks indexed.
        skipped: Number of documents skipped due to parse errors.
    """

    documents_indexed: int
    chunks_indexed: int
    skipped: int


@dataclass
class ReindexResult:
    """Result of :meth:`~markdown_vault_mcp.facets.index.IndexFacet.reindex`.

    Attributes:
        added: Documents added since the last index.
        modified: Documents that changed since the last index.
        deleted: Documents removed since the last index.
        unchanged: Documents with no changes.
        skipped: Files present on disk that were deliberately not indexed
            (missing required frontmatter, matching an exclude pattern, or
            unparseable), whether newly skipped this scan or unchanged since
            they were last skipped (#665).
    """

    added: int
    modified: int
    deleted: int
    unchanged: int
    skipped: int = 0


@dataclass
class AttachmentContent:
    """Full content of an attachment, returned by :meth:`~markdown_vault_mcp.facets.reader.ReaderFacet.read_attachment` for non-.md files.

    Attributes:
        path: Relative path from the vault root.
        mime_type: Detected MIME type, or ``None`` if unknown.
        size_bytes: File size in bytes.
        content_base64: Base64-encoded file content.
        modified_at: Last-modified time as a Unix timestamp float.
        etag: Opaque hash for optimistic concurrency checks.
    """

    path: str
    mime_type: str | None
    size_bytes: int
    content_base64: str
    modified_at: float
    etag: str | None = None


@dataclass
class AttachmentInfo:
    """Summary info for an attachment, returned by :meth:`~markdown_vault_mcp.facets.reader.ReaderFacet.list_documents` when ``include_attachments=True``.

    Attributes:
        path: Relative path from the vault root.
        folder: Parent folder path.
        mime_type: Detected MIME type, or ``None`` if unknown.
        size_bytes: File size in bytes.
        modified_at: Last-modified time as a Unix timestamp float.
        kind: Always ``"attachment"``; distinguishes from :class:`NoteInfo`.
    """

    path: str
    folder: str
    mime_type: str | None
    size_bytes: int
    modified_at: float
    kind: str = "attachment"


@dataclass
class VaultStats:
    """Vault-wide statistics, returned by :meth:`~markdown_vault_mcp.facets.reader.ReaderFacet.stats`.

    Attributes:
        document_count: Number of indexed markdown documents.
        chunk_count: Total number of indexed sections (chunks).
        folder_count: Number of distinct folder paths.
        semantic_search_available: ``True`` if a vector index is loaded and ready.
        indexed_frontmatter_fields: Frontmatter fields configured for tag indexing.
        attachment_extensions: File extensions recognised as attachments.
        link_count: Total number of links extracted from all documents.
        broken_link_count: Number of links whose target does not exist.
        orphan_count: Number of documents with no inbound or outbound links.
    """

    document_count: int
    chunk_count: int
    folder_count: int
    semantic_search_available: bool
    indexed_frontmatter_fields: list[str] = field(default_factory=list)
    attachment_extensions: list[str] = field(default_factory=list)
    link_count: int = 0
    broken_link_count: int = 0
    orphan_count: int = 0


@dataclass
class ChangeSet:
    """Documents that changed since the last index build.

    Attributes:
        added: Paths of newly discovered documents.
        modified: Paths of documents whose content changed.
        deleted: Paths of documents that no longer exist on disk.
        unchanged: Count of documents with no changes (not listed individually).
        skipped_unchanged: Count of files previously recorded as skipped
            (never indexed) whose content has not changed since; they appear
            in no other bucket and need no re-evaluation (#665).
    """

    added: list[str]
    modified: list[str]
    deleted: list[str]
    unchanged: int
    skipped_unchanged: int = 0


@dataclass
class BacklinkInfo:
    """A document that links to a given path, returned by :meth:`~markdown_vault_mcp.facets.graph.GraphFacet.get_backlinks`.

    Attributes:
        source_path: Relative path of the document containing the link.
        source_title: Title of the linking document.
        link_text: Display text of the link.
        link_type: Link syntax: ``"markdown"`` (``[text](path)``), ``"wikilink"`` (``[[path]]``), or ``"reference"`` (``[text][ref]``).
        fragment: Heading anchor (``#section``) if present in the link target.
        raw_target: The unresolved link target exactly as written in the source.
    """

    source_path: str
    source_title: str
    link_text: str
    link_type: Literal["markdown", "wikilink", "reference"]
    fragment: str | None = None
    raw_target: str = ""


@dataclass
class OutlinkInfo:
    """A link from a document to another path, returned by :meth:`~markdown_vault_mcp.facets.graph.GraphFacet.get_outlinks`.

    Attributes:
        target_path: Resolved relative path of the link target.
        link_text: Display text of the link.
        link_type: Link syntax: ``"markdown"``, ``"wikilink"``, or ``"reference"``.
        fragment: Heading anchor if present.
        raw_target: The unresolved link target exactly as written.
        exists: ``True`` if the target document exists in the vault.
    """

    target_path: str
    link_text: str
    link_type: Literal["markdown", "wikilink", "reference"]
    fragment: str | None = None
    raw_target: str = ""
    exists: bool = False


@dataclass
class BrokenLinkInfo:
    """A link whose target does not exist, returned by :meth:`~markdown_vault_mcp.facets.graph.GraphFacet.get_broken_links`.

    Attributes:
        source_path: Relative path of the document containing the broken link.
        source_title: Title of the linking document.
        target_path: Resolved path the link points to (does not exist).
        link_text: Display text of the link.
        link_type: Link syntax: ``"markdown"``, ``"wikilink"``, or ``"reference"``.
        fragment: Heading anchor if present.
        raw_target: The unresolved link target exactly as written.
    """

    source_path: str
    source_title: str
    target_path: str
    link_text: str
    link_type: Literal["markdown", "wikilink", "reference"]
    fragment: str | None = None
    raw_target: str = ""


@dataclass
class MostLinkedNote:
    """A document with its inbound backlink count, returned by :meth:`~markdown_vault_mcp.facets.graph.GraphFacet.get_most_linked`.

    Attributes:
        path: Relative path from the vault root.
        title: Document title.
        folder: Parent folder path (empty string for root-level documents).
        backlink_count: Number of other documents that link to this document.
    """

    path: str
    title: str
    folder: str
    backlink_count: int


@dataclass
class GraphNode:
    """One node in a link-graph view (#880).

    Attributes:
        id: Vault-relative document path (unique node identifier).
        label: Display name — the indexed title, falling back to the
            filename stem when the document is not indexed.
        group: Rendering group — ``"note"``, ``"orphan"``, or ``"hub"``.
        folder: Parent folder path (empty string for root-level documents).
        backlink_count: Inbound-link count, ``0`` for boundary nodes whose
            links were not expanded.
    """

    id: str
    label: str
    group: str
    folder: str
    backlink_count: int
    note_type: str | None = None


@dataclass
class GraphEdge:
    """One directed edge in a link-graph view (#880).

    Attributes:
        source: Path of the linking document.
        target: Path of the linked document.
        link_type: ``"markdown"``, ``"wikilink"``, ``"reference"``, or
            ``"semantic"`` (similarity edges from
            :meth:`~markdown_vault_mcp.facets.graph.GraphFacet.get_neighborhood`).
    """

    source: str
    target: str
    link_type: Literal["markdown", "wikilink", "reference", "semantic"]


@dataclass
class GraphView:
    """A node/edge graph assembled by the graph facet (#880).

    Attributes:
        nodes: Graph nodes, in first-seen traversal order.
        edges: Directed edges, deduplicated per ``(source, target)`` for
            explicit links.
        truncated: ``True`` when assembly stopped at the node cap.
    """

    nodes: list[GraphNode]
    edges: list[GraphEdge]
    truncated: bool = False


@dataclass
class NoteContext:
    """Consolidated context for a document, returned by :meth:`~markdown_vault_mcp.facets.reader.ReaderFacet.get_context`.

    Attributes:
        path: Relative path from the vault root.
        title: Document title.
        folder: Parent folder path.
        frontmatter: Parsed YAML frontmatter.
        modified_at: Last-modified time as a Unix timestamp float.
        backlinks: Documents that link to this document.
        outlinks: Links from this document with existence flags.
        similar: Up to ``similar_limit`` semantically similar notes,
            field-collapsed.  Each entry is a :class:`GroupedResult` with
            exactly one section (chunks_per_file=1 by default).
        folder_notes: Paths of other notes in the same folder (up to 20).
        tags: Tag values for each indexed frontmatter field.
    """

    path: str
    title: str
    folder: str
    frontmatter: dict[str, Any]
    modified_at: float
    backlinks: list[BacklinkInfo]
    outlinks: list[OutlinkInfo]
    similar: list[GroupedResult]
    folder_notes: list[str]
    tags: dict[str, list[str]]


@dataclass
class HistoryEntry:
    """A commit that touched a note or the vault, returned by :meth:`~markdown_vault_mcp.facets.reader.ReaderFacet.get_history`.

    Attributes:
        sha: Full 40-character commit SHA.
        short_sha: Abbreviated 7-character SHA.
        timestamp: ISO 8601 commit timestamp.
        author: Commit author name and email.
        message: First line of the commit message.
        paths_changed: Files touched by the commit.  Populated for vault-wide
            queries (``path=None``).  Always empty for single-note queries,
            since the path is already determined by the query arguments —
            callers know which file the commit touched without needing it
            echoed back.
    """

    sha: str
    short_sha: str
    timestamp: str
    author: str
    message: str
    paths_changed: list[str]


@dataclass
class CommitDiff:
    """A per-commit diff entry, returned by :meth:`~markdown_vault_mcp.facets.reader.ReaderFacet.get_diff` when ``per_commit=True``.

    Attributes:
        sha: Full 40-character commit SHA.
        short_sha: Abbreviated 7-character SHA.
        timestamp: ISO 8601 commit timestamp.
        message: First line of the commit message.
        diff: Unified diff text for the commit.
    """

    sha: str
    short_sha: str
    timestamp: str
    message: str
    diff: str


@dataclass
class TocEntry:
    """A single heading in a table of contents.

    Attributes:
        heading: Section heading text; non-empty (NULL headings are filtered
            at the DB layer).
        level: Markdown heading depth, 1 (H1) through 6 (H6).
    """

    heading: str
    level: int


@dataclass
class SubtreeNote:
    """One note's TOC within a folder-subtree table of contents.

    Attributes:
        path: Relative note path (ends in ``.md``).
        title: Document title.
        headings: Ordered list of headings. As returned by the public
            ``DocumentManager.get_toc`` / ``ReaderFacet.get_toc`` the first
            entry is the synthetic H1 title; the raw ``FTSIndex.get_subtree_toc``
            result omits it (the manager layer prepends it).
        content_chars: Character count of the note body, frontmatter excluded,
            so a caller can budget batches without reading the note (#1039).
            ``0`` for a row indexed before this field existed.
    """

    path: str
    title: str
    headings: list[TocEntry]
    content_chars: int = 0


@dataclass
class SubtreeToc:
    """A folder-subtree table of contents: per-note headings under a prefix.

    Attributes:
        path: Folder prefix (no trailing slash, no ``.md`` extension).
        notes: Per-note TOCs, ordered by path ascending.
        truncated: True when more notes matched than ``max_notes`` (the count
            strictly exceeded the cap) and the list was capped.
    """

    path: str
    notes: list[SubtreeNote]
    truncated: bool


@dataclass
class SummarySource:
    """One note that contributed to a summary.

    Attributes:
        path: Relative note path (ends in ``.md``).
        title: Document title.
    """

    path: str
    title: str


@dataclass
class SummaryResult:
    """Result of the ``summarize`` tool.

    Attributes:
        summary: The generated summary text. In ``"synthesis"`` mode this is a
            single cross-note summary that references the source notes by path;
            in ``"per_note"`` mode it concatenates per-note summaries, each
            headed by its note path.
        sources: The notes that were summarised, in the order they were fed to
            the model — always populated so individual notes are attributable
            even when the prose does not name every one.
        mode: ``"synthesis"`` or ``"per_note"``.
        truncated: True when content was lost to a cap — more notes matched
            than ``max_notes``, a single note body exceeded the per-request
            character budget (``max_input_chars``) and was cut, or a partial
            summary was clipped during the reduce phase.
        notes_included: Number of notes whose content reached the model.
        notes_omitted: Number of matched notes that were dropped by the
            note limit (or skipped as unreadable). Callers should surface a
            warning when this is non-zero (#922).
        notes_limit: The note limit in effect for this call: the per-call
            ``max_notes`` argument clamped to the server's configured cap
            (#925).
        hint: Recovery guidance for the caller, set when notes were omitted;
            ``None`` when the selection was fully covered. Guidance in the
            result is acted on more reliably than schema docs (#925).
    """

    summary: str
    sources: list[SummarySource]
    mode: str
    truncated: bool
    notes_included: int = 0
    notes_omitted: int = 0
    notes_limit: int = 0
    hint: str | None = None


WriteOperation = Literal["write", "edit", "delete", "rename"]

WriteCallback = Callable[[Path, str, WriteOperation], None]

#: Attribute name a :data:`WriteCallback` sets to ``True`` to opt into
#: receiving the ``old_path=`` keyword on ``rename`` dispatches (#894).
#:
#: A rename has two sides — the vanished old path and the new one — but the
#: callback signature carries a single path, which left the git strategy
#: staging the old side with a pathspec-less ``git add -u`` that swept every
#: unrelated tracked modification in the repository into the auto-commit.
#: The extra argument is an opt-in rather than a signature change so a
#: third-party three-argument callback keeps working untouched:
#: :class:`~markdown_vault_mcp.write_callback.WriteCallbackDispatcher` reads
#: this attribute once and passes ``old_path`` only to callbacks that
#: advertise it.
ACCEPTS_OLD_PATH_ATTR = "accepts_old_path"


class RenameAwareWriteCallback(Protocol):
    """A :data:`WriteCallback` that also accepts a rename's old path.

    Structural type for the opt-in described at
    :data:`ACCEPTS_OLD_PATH_ATTR`. It exists so the dispatcher can express
    the widened call in the type system instead of reaching for ``Any``;
    ``WriteCallback`` itself deliberately stays three-argument so an
    existing third-party callback is neither a type error nor a runtime one.
    """

    accepts_old_path: bool

    def __call__(
        self,
        path: Path,
        content: str,
        operation: WriteOperation,
        *,
        old_path: Path | None = None,
    ) -> None:
        """Handle one write, optionally told where a rename moved from."""
        ...


# Default set of allowed attachment extensions (without leading dot, lower-case).
# .md is always excluded — it is always handled as a markdown note.
DEFAULT_ATTACHMENT_EXTENSIONS: frozenset[str] = frozenset(
    [
        # Documents
        "pdf",
        "docx",
        "xlsx",
        "pptx",
        "odt",
        "ods",
        "odp",
        # Images
        "png",
        "jpg",
        "jpeg",
        "gif",
        "webp",
        "svg",
        "bmp",
        "tiff",
        # Archives
        "zip",
        "tar",
        "gz",
        # Audio / Video
        "mp3",
        "mp4",
        "wav",
        "ogg",
        # Text and data
        "txt",
        "csv",
        "tsv",
        "json",
        "yaml",
        "toml",
        "xml",
        "html",
        "css",
        "js",
        "ts",
    ]
)
