"""Domain helpers backing the vault MCP Apps UI (#905).

Holds the vault-specific logic that fills ``_server_apps.register_apps``'s
sentinel blocks, kept out of ``_server_apps.py`` so that file conforms to the
template skeleton (only its sentinel blocks and imports diverge):

- :func:`_compute_claude_app_domain` and :data:`_CDN_RESOURCE_DOMAINS`
  configure the app-shell resource's ``AppConfig`` (sandbox ``domain`` + CSP)
  in the ``DOMAIN-APP-RESOURCE`` block.
- :func:`_graph_view_payload` serializes a :class:`GraphView` into the SPA
  graph-tool wire shape for the ``DOMAIN-APP-TOOLS`` graph app-tools.
- :func:`vault_app_resource_config` builds that ``AppConfig`` and logs the
  resolved domain.
"""

from __future__ import annotations

import hashlib
import logging
import os
from typing import TYPE_CHECKING, Any

from fastmcp.apps import AppConfig, ResourceCSP

from markdown_vault_mcp.config import _ENV_PREFIX

if TYPE_CHECKING:
    from markdown_vault_mcp.types import GraphView

logger = logging.getLogger(__name__)

#: Origins the served SPA loads sub-resources from, declared so a host that
#: builds its iframe CSP from ``resourceDomains`` permits them (#1181). Every
#: script dependency is vendored inline (see scripts/vendor_spa.py), but the
#: three typefaces are still fetched: the stylesheet from ``fonts.googleapis``
#: and the font files it references from ``fonts.gstatic``. Keep this list and
#: what ``static/app.html`` actually requests in step — a declaration that
#: omits an origin fails silently, with the host simply dropping the request.
#: ``tests/test_apps_vendoring.py`` asserts the two agree in both directions.
_CDN_RESOURCE_DOMAINS: list[str] = [
    "https://fonts.googleapis.com",
    "https://fonts.gstatic.com",
]


def _compute_claude_app_domain() -> str | None:
    """Auto-compute Claude's MCP Apps sandbox domain from BASE_URL.

    Claude requires ``{sha256_prefix}.claudemcpcontent.com`` where the hash
    is derived from the full MCP endpoint URL the client connects to.

    Returns:
        The computed domain string, or ``None`` when ``BASE_URL`` is not set
        (e.g. stdio transport or local development).
    """
    base_url = os.environ.get(f"{_ENV_PREFIX}_BASE_URL", "").strip().rstrip("/")
    if not base_url:
        return None
    http_path = os.environ.get(f"{_ENV_PREFIX}_HTTP_PATH", "/mcp").strip() or "/mcp"
    if not http_path.startswith("/"):
        http_path = f"/{http_path}"
    if len(http_path) > 1:
        http_path = http_path.rstrip("/")
    mcp_url = f"{base_url}{http_path}"
    hash_prefix = hashlib.sha256(mcp_url.encode()).hexdigest()[:32]
    return f"{hash_prefix}.claudemcpcontent.com"


def vault_app_resource_config() -> AppConfig:
    """Build the app-shell resource's ``AppConfig``: sandbox domain and CSP.

    The domain is ``APP_DOMAIN`` when set, else computed from ``BASE_URL``
    (see :func:`_compute_claude_app_domain`); it is logged so it is visible
    at boot.

    Returns:
        The ``AppConfig`` for the ``DOMAIN-APP-RESOURCE`` block.
    """
    app_domain: str | None = (
        os.environ.get(f"{_ENV_PREFIX}_APP_DOMAIN", "").strip()
        or _compute_claude_app_domain()
    )
    if app_domain:
        logger.info("apps_domain_resolved domain=%s", app_domain)
    else:
        # No sandbox iframe domain: either running under stdio (no HTTP
        # server to derive it from) or BASE_URL/APP_DOMAIN is unset.
        logger.debug("apps_domain_unconfigured reason=stdio_or_no_base_url")
    return AppConfig(
        domain=app_domain,
        csp=ResourceCSP(resource_domains=_CDN_RESOURCE_DOMAINS),
    )


def _graph_view_payload(view: GraphView, *, include_truncated: bool) -> dict[str, Any]:
    """Serialize a :class:`GraphView` into the SPA graph-tool wire shape.

    Edge endpoints map to ``from``/``to`` (vis-network's field names;
    ``from`` is a Python keyword, so the dataclass uses source/target).
    """
    payload: dict[str, Any] = {
        "nodes": [
            {
                "id": n.id,
                "label": n.label,
                "group": n.group,
                "folder": n.folder,
                "backlink_count": n.backlink_count,
                # OKF type (phase 2, #961): present only on an active OKF
                # bundle for notes that declare one, so non-OKF payloads
                # keep their exact prior shape.
                **({"note_type": n.note_type} if n.note_type is not None else {}),
            }
            for n in view.nodes
        ],
        "edges": [
            {"from": e.source, "to": e.target, "type": e.link_type} for e in view.edges
        ],
    }
    if include_truncated:
        payload["truncated"] = view.truncated
    return payload
