"""Domain service that owns the Vault lifecycle for the MCP server.

The template-owned ``_server_deps`` scaffold constructs a domain :class:`Service`
(``start``/``stop``) and yields it to the request context. MVM's ``Service`` builds
the :class:`~markdown_vault_mcp.vault.Vault`, submits the boot index/reindex/embeddings
jobs, and runs the file watcher — the lifecycle that used to live inline in
``_server_deps.make_vault_lifespan`` (#902, epic #898). ``get_vault`` / ``get_config``
resolve the running service's vault/config for ``Depends``-injected handlers, and the
module-level singleton reaches the live Vault from HTTP routes outside DI.
"""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING

from fastmcp.dependencies import CurrentContext
from fastmcp.server.context import Context

from markdown_vault_mcp.config import ProjectConfig
from markdown_vault_mcp.config_sections._assembly import (
    source_dir_problem,
    to_vault_instances,
    to_vault_settings,
)
from markdown_vault_mcp.exceptions import ConfigurationError
from markdown_vault_mcp.vault import Vault

if TYPE_CHECKING:
    from markdown_vault_mcp._file_watcher import VaultFileWatcher

logger = logging.getLogger(__name__)


_vault_singleton: Vault | None = None
# Why there is no singleton although the lifespan ran: the message every
# out-of-context accessor (transfer sink, webhook routes) raises with.
_vault_unavailable: str | None = None

# Config handoff: make_server sets the config it already loaded so the no-arg
# ``Service()`` the template's server_lifespan constructs builds the vault from
# that same config — the caller-supplied config stays authoritative and the
# environment is not parsed a second time (#609). NOT cleared on read: FastMCP's
# lifespan is ref-counted and re-enters (constructs a fresh ``Service()``) each
# time a new session opens after all sessions closed, so the value must survive
# to rebuild the vault from the same config on every re-entry. Single-server-
# per-process (last make_server wins), like the vault singleton above.
_pending_config: ProjectConfig | None = None


# Transport handoff: the transport is a make_server() argument, not a config
# field — the CLI's ``--transport`` flag is authoritative and shadows any env
# value — so the no-arg ``Service()`` cannot recover it from ProjectConfig.
# Staged the same way as _pending_config above, and NOT cleared on read for the
# same ref-counted-lifespan-re-entry reason. Service.start needs it to ask
# whether a configured webhook can actually deliver on this transport before
# standing the file watcher down (#1263); the default matches make_server's.
_pending_transport: str = "stdio"


def set_pending_config(config: ProjectConfig | None) -> None:
    """Stage the config for the no-arg :class:`Service` construction (#609)."""
    global _pending_config
    _pending_config = config


def set_pending_transport(transport: str) -> None:
    """Stage the transport for the no-arg :class:`Service` construction (#1263).

    Args:
        transport: The resolved transport name ``make_server`` was called with
            (``"stdio"`` / ``"http"`` / ``"sse"``).
    """
    global _pending_transport
    _pending_transport = transport


def set_vault_singleton(vault: Vault | None, *, unavailable: str | None = None) -> None:
    """Set the module-level :class:`Vault` singleton.

    Set by :meth:`Service.start` with the live Vault, and cleared to ``None`` by
    :meth:`Service.stop` so a subsequent server in the same process starts clean.

    Args:
        vault: The live :class:`Vault`, or ``None`` to clear.
        unavailable: With ``vault=None``, why the lifespan built no vault;
            :func:`get_vault_singleton` then raises
            :class:`~markdown_vault_mcp.exceptions.ConfigurationError` with it
            instead of the not-started ``RuntimeError``.
    """
    global _vault_singleton, _vault_unavailable
    _vault_singleton = vault
    _vault_unavailable = unavailable if vault is None else None


def get_vault_singleton() -> Vault:
    """Return the module-level :class:`Vault` singleton.

    Used by HTTP route handlers (e.g. the GitHub webhook route) that run outside
    FastMCP's ``Depends(get_vault)`` injection and cannot resolve the Vault from
    the lifespan context.

    Returns:
        The live :class:`Vault` set by :meth:`Service.start`.

    Raises:
        ConfigurationError: If the lifespan ran but built no vault because
            the configured directory does not exist.
        RuntimeError: If the singleton has not been set yet.
    """
    if _vault_singleton is None:
        if _vault_unavailable is not None:
            raise ConfigurationError(_vault_unavailable)
        msg = (
            "Vault not initialised — Service.start was never called.  In normal "
            "operation the server lifespan starts it; in tests, set explicitly "
            "via set_vault_singleton(col)."
        )
        raise RuntimeError(msg)
    return _vault_singleton


class Service:
    """Owns the Vault lifecycle: build, boot index/embeddings jobs, file watcher.

    Constructed no-args by the template's ``server_lifespan``; resolves config
    from the config make_server staged (#609) and the transport it staged
    (#1263), falling back to an env read only if no config was staged. Tests
    may pass a pre-built ``config`` and an explicit ``transport``.
    """

    def __init__(
        self,
        config: ProjectConfig | None = None,
        transport: str | None = None,
    ) -> None:
        # Prefer an explicit config, then the one make_server staged (#609), then
        # a fresh env read. The staged config is NOT cleared: a ref-counted
        # lifespan re-entry constructs a new Service() and must rebuild from the
        # same config, not re-read env.
        self._config = config or _pending_config or ProjectConfig.from_env()
        self._transport = transport if transport is not None else _pending_transport
        self._vault: Vault | None = None
        self._file_watcher: VaultFileWatcher | None = None
        # Why start() built no vault: the message every accessor raises with
        # until the operator fixes the deployment and restarts.
        self._startup_error: str | None = None

    @property
    def vault(self) -> Vault:
        """The live :class:`Vault`.

        Raises:
            ConfigurationError: If :meth:`start` ran but built no vault
                because the directory does not exist; the message names the
                variable to set.
            RuntimeError: If :meth:`start` has not run.
        """
        if self._vault is None:
            if self._startup_error is not None:
                raise ConfigurationError(self._startup_error)
            msg = "Service not started — call start() first"
            raise RuntimeError(msg)
        return self._vault

    @property
    def startup_error(self) -> str | None:
        """Why :meth:`start` built no vault, or ``None`` when it did."""
        return self._startup_error

    @property
    def config(self) -> ProjectConfig:
        """The :class:`ProjectConfig` this service was built from."""
        return self._config

    async def start(self) -> None:
        """Build the Vault and submit the boot jobs; start background tasks."""
        config = self._config
        # No vault directory, no vault: the index writer and the file watcher
        # cannot run over an absent path (a wrong path used to crash the
        # lifespan here with a raw FileNotFoundError). The server still
        # starts, so its tool listing and instructions are reachable, and
        # every tool fails with the variable to set until the operator fixes
        # the deployment and restarts.
        problem = source_dir_problem(config)
        if problem is not None:
            reason, self._startup_error = problem
            if reason == "missing":
                logger.error(
                    "vault_directory_missing path=%s var=MARKDOWN_VAULT_MCP_SOURCE_DIR",
                    config.source_dir,
                )
            else:
                logger.error(
                    "vault_directory_unreadable path=%s problem=%s",
                    config.source_dir,
                    self._startup_error,
                )
            set_vault_singleton(None, unavailable=self._startup_error)
            return
        logger.info("vault_initialising source_dir=%s", config.source_dir)

        # Settings-first construction (#1158): the config-derived knobs
        # travel as one VaultSettings; the constructed collaborators stay
        # explicit keywords, resolved once into VaultInstances.
        instances = to_vault_instances(config)
        settings = to_vault_settings(config, instances=instances)
        if instances.embedding_provider is not None:
            logger.info(
                "embedding_provider_resolved provider=%s",
                type(instances.embedding_provider).__name__,
            )
        vault = Vault(
            source_dir=config.source_dir,
            settings=settings,
            embedding_provider=instances.embedding_provider,
            summarizer=instances.summarizer,
            git_strategy=instances.git_strategy,
            on_write=instances.on_write,
        )
        self._vault = vault
        set_vault_singleton(vault)

        # If periodic git pull is enabled, sync before submitting the
        # initial index build so the scan sees the latest working tree.
        await asyncio.to_thread(vault.sync_from_remote_before_index)

        # Submit the initial build jobs to the IndexWriter and yield
        # immediately (#559). build_index_async() short-circuits in
        # O(1) on warm restarts (existing FTS sentinel from PR #526);
        # cold restarts submit a BuildIndex job that the writer
        # processes asynchronously while the lifespan yields.
        # Bucket-3 tools block on @needs_queryable until the build
        # completes; bucket-2 tools return whatever is currently in
        # the index per #526.
        vault.index.build_index_async()
        logger.info("build_index_job_submitted")

        # Reconcile offline changes (#665): files added, modified, or
        # deleted while no server was running are invisible to both the
        # warm-restart short-circuit above (O(1), no filesystem scan) and
        # the file watcher below (future events only).  Enqueue an
        # incremental reindex behind the build: the writer's FIFO ordering
        # guarantees build-before-reindex, and on a cold boot the full
        # build has just recorded tracker state (including skipped files),
        # so the reindex degenerates to a cheap hash scan instead of a
        # second full parse.  While this job is pending, the writer is
        # non-drained, so #646's out-of-band `index_stale` meta signal
        # honestly reports True until the boot reconciliation completes.
        # This job is now conditional on config.boot_reindex (#1535);
        # index_stale consequently reports drained sooner without implying
        # the index agrees with disk.
        # The HEAD the startup sync left behind is what the boot reindex
        # covers; recording it lets later reconciles (#1532) skip a redundant
        # full scan and reindex only once HEAD moves past it.
        head_at_boot = await asyncio.to_thread(vault.git_head)
        if config.boot_reindex:
            vault.adopt_boot_reindex(vault.index.reindex_async(), head_at_boot)
            logger.info("boot_reindex_job_submitted")
        else:
            # Offline changes (files added/modified/deleted while no server
            # was running) stay invisible to the index until an explicit
            # reindex runs — either the `reindex` tool or the
            # `markdown-vault-mcp reindex` CLI command.  Accepting the index
            # at the boot HEAD keeps that trade: later pulls that move HEAD
            # still reindex.
            vault.mark_index_reconciled(head_at_boot)
            logger.info("boot_reindex_disabled reason=config")

        if instances.embedding_provider is not None:
            vault.index.build_embeddings_async()
            logger.info("build_embeddings_job_submitted")

        # Start any other background tasks (e.g. git pull loop).
        vault.start()

        # File watcher — only when git pull and webhook are both inactive so the
        # watcher and git checkout don't race to trigger reindex (#558).
        from markdown_vault_mcp._file_watcher import (
            VaultFileWatcher,
            should_start_file_watcher,
        )
        from markdown_vault_mcp._webhooks import webhook_routes_active
        from markdown_vault_mcp.exceptions import IndexUnavailableError

        # Use the *resolved* pull interval from the git assembly, not
        # config.git.pull_interval_s: the config default is 600 even on
        # non-git vaults, but to_vault_instances() only resolves a non-zero
        # interval when a sync-enabled git strategy is configured.
        git_pull_active = instances.git_pull_interval_s > 0

        # Ask whether a webhook can actually deliver, not merely whether its
        # credentials are set: under stdio no route is mounted, so standing the
        # watcher down for it would leave no external-change detection at all
        # (#1263). Same predicate register_webhook_routes mounts on, fed the
        # same transport make_server was called with.
        webhook_active = webhook_routes_active(config, self._transport)

        if should_start_file_watcher(
            config.sync.file_watcher_enabled,
            git_pull_active,
            webhook_active,
        ):

            def _on_file_change() -> None:
                try:
                    with vault.pause_writes():
                        vault.index.reindex()
                except IndexUnavailableError:
                    logger.info(
                        "file_watcher_reindex_skipped reason=index_not_queryable"
                    )
                except Exception:
                    logger.error("file_watcher_reindex_failed", exc_info=True)

            # Never watch the vault's own write targets: reindex() rewrites the
            # state file on every run, and a watch on its dir would re-trigger
            # the watcher into a self-feedback loop (#830). .git is protected
            # too so local git-write commits don't storm reindexes.
            from markdown_vault_mcp.vault import _DEFAULT_STATE_SUBDIR

            state_dir = (
                config.indexing.state_path.parent
                if config.indexing.state_path is not None
                else config.source_dir / _DEFAULT_STATE_SUBDIR
            )
            internal_dirs = [config.source_dir / ".git", state_dir]
            for extra in (
                config.indexing.index_path,
                config.indexing.embeddings_path,
            ):
                if extra is not None:
                    internal_dirs.append(extra.parent)

            self._file_watcher = VaultFileWatcher(
                config.source_dir,
                _on_file_change,
                debounce_s=config.sync.file_watcher_debounce_s,
                exclude_patterns=config.indexing.exclude_patterns,
                root_floor=config.sync.file_watcher_root_floor,
                internal_dirs=internal_dirs,
            )
            self._file_watcher.start()
        elif not config.sync.file_watcher_enabled:
            logger.debug("file_watcher_disabled reason=file_watcher_false")
        else:
            logger.info("file_watcher_disabled reason=other_cadence_source_active")

    async def stop(self) -> None:
        """Stop the file watcher and close the Vault."""
        if self._file_watcher is not None:
            self._file_watcher.stop()
        # Clear the singleton before closing so any in-flight HTTP handler gets a
        # clean RuntimeError instead of touching a Vault mid-close().
        set_vault_singleton(None)
        if self._vault is not None:
            self._vault.close()
        logger.info("vault_shut_down")


def get_vault(ctx: Context = CurrentContext()) -> Vault:
    """Resolve the live Vault from the request context.

    Used as a ``Depends()`` default in tool/resource/prompt signatures.

    Raises:
        RuntimeError: If the server lifespan has not run.
        ConfigurationError: If the lifespan ran but built no vault because
            the configured directory does not exist (see
            :attr:`Service.startup_error`).
    """
    service: Service | None = ctx.lifespan_context.get("service")
    if service is None:
        msg = "Vault not initialised — server lifespan has not run"
        raise RuntimeError(msg)
    return service.vault


def get_config(ctx: Context = CurrentContext()) -> ProjectConfig:
    """Resolve the :class:`ProjectConfig` from the request context.

    Raises:
        RuntimeError: If the server lifespan has not run.
    """
    service: Service | None = ctx.lifespan_context.get("service")
    if service is None:
        msg = "Config not initialised — server lifespan has not run"
        raise RuntimeError(msg)
    return service.config
