"""SQLite FTS5 index for full-text search and tag filtering.

**Skip tombstones (#1129):** files that a scan deliberately skipped for one
of the four surfaced :data:`~markdown_vault_mcp.types.SKIP_CATEGORIES` are
kept PRESENT in the ``documents`` table as *tombstone* rows — ``skip_category``
non-NULL, ``chunk_count = 0``, and no child rows (no ``sections``,
``notes_fts``, ``links``, ``document_tags``, or ``document_aliases`` entries).
Absence of a ``documents`` row therefore means exactly one thing: the path is
not an index candidate at all (deleted, non-markdown, or excluded by
pattern). Every reader query goes through the ``documents_live`` view
(``WHERE skip_category IS NULL``), so tombstones are invisible to all
existing consumers. Queries that join ``documents`` through child tables —
the FTS5 MATCH search join, :meth:`FTSIndex.list_chunks`,
:meth:`FTSIndex.get_toc`, :meth:`FTSIndex.get_backlinks`, and
:meth:`FTSIndex.list_field_values` — are naturally tombstone-safe because a
tombstone has no child rows, and deliberately keep reading ``documents``.
Links pointing at a tombstoned file intentionally stay *broken* (and
vault-wide wikilinks never resolve to a tombstone): the file contributes no
readable content, so pretending its link target exists would only hide the
problem the tombstone records.

Delete cost: ``notes_fts`` is content-carrying FTS5, so an ordinary-column
filter has no index and forces a full scan of its shadow content table.
``_delete_document`` avoids this via the ``notes_fts_rowid_map`` bridge
table instead (#1535). See ``docs/design/reference/sqlite-fts5.md`` before
changing any ``notes_fts`` INSERT/DELETE statement.
"""

from __future__ import annotations

import datetime
import json
import logging
import sqlite3
from collections import deque
from pathlib import Path
from typing import TYPE_CHECKING, Any, NamedTuple

from markdown_vault_mcp._fts_connection import (
    SqliteConnectionRegistry,
)
from markdown_vault_mcp._fts_connection import (
    retry_on_locked as _retry_on_locked,
)
from markdown_vault_mcp._fts_connection import (
    retry_on_sqlite_locked as _retry_on_sqlite_locked,
)
from markdown_vault_mcp.embed_text import fields_text as _fields_text
from markdown_vault_mcp.exceptions import DocumentNotFoundError
from markdown_vault_mcp.types import (
    FTSResult,
    ParsedNote,
    SkippedFile,
    SubtreeNote,
    TocEntry,
)

if TYPE_CHECKING:
    from collections.abc import Iterable

logger = logging.getLogger(__name__)


# Thresholds for running FTS5 'optimize' after a bulk purge.  Deleting rows
# from an FTS5 table only marks their tokens as deleted inside the inverted
# index — the dead entries stay in the on-disk segment b-trees until segments
# are merged, which FTS5 does lazily and may never get around to.  A purge
# pass that removes many documents (e.g. newly-configured exclude patterns
# expelling previously indexed files at boot, issue #255) can therefore leave
# hundreds of megabytes of dead segments that bloat the database file and
# slow keyword queries.  'optimize' merges everything into one clean segment.
# An optimize pass is cheap relative to the bloat it removes, so the
# thresholds err toward running it: a purge of at least
# ``OPTIMIZE_MIN_PURGED_DOCS`` documents, or at least
# ``OPTIMIZE_MIN_PURGED_FRACTION`` of the pre-purge corpus, qualifies.
OPTIMIZE_MIN_PURGED_DOCS = 25
OPTIMIZE_MIN_PURGED_FRACTION = 0.10


def should_optimize(purged: int, total_before: int) -> bool:
    """Decide whether a bulk purge warrants an FTS5 'optimize' pass.

    Args:
        purged: Number of documents removed in a single purge pass.
        total_before: Number of indexed documents before the purge.

    Returns:
        ``True`` when ``purged`` is at least :data:`OPTIMIZE_MIN_PURGED_DOCS`
        or at least :data:`OPTIMIZE_MIN_PURGED_FRACTION` of ``total_before``.
    """
    if purged <= 0 or total_before <= 0:
        return False
    if purged >= OPTIMIZE_MIN_PURGED_DOCS:
        return True
    return purged / total_before >= OPTIMIZE_MIN_PURGED_FRACTION


def _json_default(obj: Any) -> str:
    """Handle non-JSON-native types from YAML frontmatter.

    YAML parsers auto-detect date-like strings (e.g. ``2024-01-15``) as
    ``datetime.date`` or ``datetime.datetime`` objects, and bare time
    strings (e.g. ``15:30:00``) as ``datetime.time``.  This handler
    converts them to ISO-format strings so ``json.dumps()`` can
    serialise frontmatter without crashing.
    """
    if isinstance(obj, (datetime.datetime, datetime.date, datetime.time)):
        return obj.isoformat()
    raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")


# DDL executed once on connection open. `foreign_keys` is intentionally NOT
# set here — `SqliteConnectionRegistry.apply_pragmas` sets it on every
# connection (primary and per-thread) before `_init_schema` runs.
_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS documents (
    id INTEGER PRIMARY KEY,
    path TEXT UNIQUE NOT NULL,
    title TEXT NOT NULL,
    folder TEXT NOT NULL DEFAULT '',
    frontmatter_json TEXT,
    content_hash TEXT NOT NULL,
    modified_at REAL NOT NULL,
    chunk_count INTEGER NOT NULL DEFAULT 1,
    content_chars INTEGER NOT NULL DEFAULT 0,
    skip_category TEXT,
    skip_detail TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS sections (
    id INTEGER PRIMARY KEY,
    document_id INTEGER NOT NULL,
    heading TEXT,
    heading_level INTEGER NOT NULL,
    content TEXT NOT NULL,
    start_line INTEGER NOT NULL,
    FOREIGN KEY (document_id) REFERENCES documents(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_sections_docid ON sections(document_id);

CREATE TABLE IF NOT EXISTS document_tags (
    id INTEGER PRIMARY KEY,
    document_id INTEGER NOT NULL,
    tag_key TEXT NOT NULL,
    tag_value TEXT NOT NULL,
    UNIQUE(document_id, tag_key, tag_value),
    FOREIGN KEY (document_id) REFERENCES documents(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_tags_kv ON document_tags(tag_key, tag_value);
CREATE INDEX IF NOT EXISTS idx_tags_docid ON document_tags(document_id);

CREATE TABLE IF NOT EXISTS links (
    id INTEGER PRIMARY KEY,
    source_id INTEGER NOT NULL,
    target_path TEXT NOT NULL,
    link_text TEXT NOT NULL DEFAULT '',
    link_type TEXT NOT NULL,
    fragment TEXT,
    raw_target TEXT NOT NULL DEFAULT '',
    FOREIGN KEY (source_id) REFERENCES documents(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_links_target ON links(target_path);
CREATE INDEX IF NOT EXISTS idx_links_source ON links(source_id);

CREATE TABLE IF NOT EXISTS document_aliases (
    id INTEGER PRIMARY KEY,
    document_id INTEGER NOT NULL,
    alias TEXT NOT NULL,
    UNIQUE(document_id, alias),
    FOREIGN KEY (document_id) REFERENCES documents(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_aliases_alias ON document_aliases(alias);
CREATE INDEX IF NOT EXISTS idx_aliases_docid ON document_aliases(document_id);

CREATE INDEX IF NOT EXISTS idx_documents_modified_at
    ON documents(modified_at DESC);

CREATE VIRTUAL TABLE IF NOT EXISTS notes_fts USING fts5(
    path, title, folder, heading, content, summary,
    tokenize='porter unicode61'
);

-- Bridge table: notes_fts is content-carrying, so an ordinary-column
-- filter (WHERE path = ?) has no index and forces a full scan of the
-- shadow content table (#1535, docs/design/reference/sqlite-fts5.md).
-- notes_fts holds one row per CHUNK, not one per document, so its rowid
-- cannot be documents.id directly; this table maps each chunk's fts
-- rowid back to its owning document so deletes can go through an
-- indexed lookup instead.
CREATE TABLE IF NOT EXISTS notes_fts_rowid_map (
    document_id INTEGER NOT NULL,
    fts_rowid INTEGER NOT NULL,
    PRIMARY KEY (document_id, fts_rowid),
    FOREIGN KEY (document_id) REFERENCES documents(id) ON DELETE CASCADE
) WITHOUT ROWID;

CREATE TABLE IF NOT EXISTS meta (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
"""

# Extracted so tests/test_fts_index.py can EXPLAIN QUERY PLAN the exact
# statement _delete_document executes, instead of a copy that could drift.
_DELETE_NOTES_FTS_BY_DOCUMENT_SQL = (
    "DELETE FROM notes_fts WHERE rowid IN "
    "(SELECT fts_rowid FROM notes_fts_rowid_map WHERE document_id = ?)"
)

# Key written into ``meta`` after :meth:`IndexFacet.build_index` completes
# a full scan successfully. Warm-restart short-circuits keyed solely on
# ``documents`` row presence would otherwise treat a partial index (left
# by a crash mid-build, since per-document upserts each commit in their
# own transaction) as ready — see issue #525.
_META_BUILD_COMPLETED_KEY = "build_completed_at"

# Keys recording the embedding provenance that determines FTS chunk
# boundaries at build time (#649). The chunker is shared by FTS and
# embeddings; its char cap is derived from the embedding model's context
# unless an explicit override is set. We record the two STABLE inputs to that
# derivation — the model name and the explicit ``MAX_CHUNK_CHARS`` override —
# rather than the derived cap itself. Comparing the stable inputs on warm
# restart rejects the short-circuit on a genuine model or override change,
# while NOT flapping when the derived cap merely differs because the model's
# context length was read transiently differently (e.g. an Ollama instance
# briefly unreachable). A ``None`` value is stored as the empty string and
# read back as ``None``.
_META_EMBED_MODEL_KEY = "embed_model_name"
_META_MAX_CHUNK_CHARS_OVERRIDE_KEY = "max_chunk_chars_override"
# Curated-ranking provenance: the title field and searchable frontmatter
# fields in force at build time. Stored as "" when equal to the default so a
# pre-upgrade index (absent keys) reads back as defaults and keeps the
# warm-restart short-circuit intact.
_META_TITLE_FIELD_KEY = "title_field"
_META_SEARCHABLE_FIELDS_KEY = "searchable_fields"
# Structured-filter provenance: the frontmatter fields promoted to
# document_tags at build time. Tracked separately from searchable_fields
# (#927) because indexed_frontmatter_fields feeds document_tags only, never
# FTS summary/embedding text, so a change must reject the warm-restart
# short-circuit on its own trigger rather than piggybacking on
# searchable_fields (which only shares its value when SEARCHABLE_FIELDS is
# left to default to INDEXED_FIELDS).
_META_INDEXED_FIELDS_KEY = "indexed_frontmatter_fields"
# Link-extraction provenance: the attachment allowlist in force at build
# time (#1333). The link graph is notes-only, so a reference whose target
# carries an allowlisted extension stores no link row — which makes the
# allowlist an input to row derivation, like the keys above. Canonical form
# from ``utils.canonical_attachment_extensions``: "" for the default set (an
# index predating the key reads back as the default), else the sorted
# members as a JSON list ("[]" for an explicitly empty allowlist).
_META_ATTACHMENT_EXTENSIONS_KEY = "attachment_extensions"

# Derived-content provenance: the version of this server's own parse-to-row
# pipeline (#1124). Unlike every key above it, this records no operator input
# at all — it is a source constant, bumped whenever a code change alters the
# rows derived from unchanged file bytes. Indexing is hash-based, so an
# unchanged file is never re-parsed after an upgrade and its stale rows would
# be served indefinitely; recording the version lets the warm-restart
# short-circuit reject an index built by an older pipeline and cold-rebuild
# it once. An index written before this key existed reads back as 0, so the
# first start after the upgrade rebuilds — which is the repair #1124 found
# missing after the link-extraction fixes in #1104 / #1107.
_META_INDEX_SEMANTICS_KEY = "index_semantics_version"

# Sentinel: the ``notes_fts_rowid_map`` bridge table has been backfilled for a
# pre-#1535 database. Written once by :meth:`_migrate_fts_rowid_map` and read
# on every boot to short-circuit a redundant backfill pass.
_META_FTS_ROWID_MAP_BACKFILLED_KEY = "fts_rowid_map_backfilled"

#: Current version of the parse-to-row pipeline whose output is stored in the
#: index (link extraction, chunk boundaries, tag/alias/heading derivation).
#:
#: Any change that makes an unchanged file yield different stored rows must
#: be covered by a bump of this value — landed in the same commit, since the
#: bump is what converts such a fix into a fix operators actually receive:
#: on the next start, the warm-restart short-circuit is rejected and every
#: file is re-parsed once. Changes that only affect how stored rows are
#: *queried* or *rendered* (ranking, snippets, response shaping) need no
#: bump — nothing on disk went stale.
#:
#: **One bump per release** (#1365). A deployment can only ever hold a value
#: that shipped in a stable or rc release, so bumping on every merged fix
#: manufactures values nobody can be at (4 through 8 below never shipped;
#: they are kept as history). Before bumping, check whether the commit that
#: set the current value is contained in a stable or rc tag
#: (``git tag --contains <sha>``): if it is not, the current value already
#: covers the next release — add the change to that version's note instead.
#: The edge channel does not count as a release here. A redundant bump is
#: harmless (one extra rebuild that would have happened anyway), so this is
#: a should, not a must.
#:
#: Version 3 (#1129): skipped files became part of the stored row set —
#: every surfaced deterministic skip now writes a tombstone row into
#: ``documents``. An index built by an older pipeline has no tombstones, so
#: its row absences are ambiguous (skipped vs. deleted); the bump forces the
#: one cold rebuild that materialises tombstones for existing skips.
#:
#: Version 4 (#1335): a destination carrying any URI scheme is external.
#: The filter was an allowlist of four prefixes, so ``file:``, ``ftp:``,
#: ``obsidian:`` and the like were stored as vault-relative link rows, and a
#: schemed wikilink gained a ``.md`` suffix. Those rows are gone from a fresh
#: parse; the bump rebuilds notes whose bytes never changed.
#:
#: Version 5 (#1332): a markdown or reference-link destination is
#: percent-decoded before it is resolved, so ``b%5B1%5D.md`` and ``b[1].md``
#: store the same ``target_path`` row. Encoded links previously stored their
#: spelling verbatim and never resolved; the bump rebuilds notes whose bytes
#: never changed so those rows gain their targets.
#:
#: Version 6 (#1333): a reference whose target names an attachment (an
#: allowlisted extension) is not a link, at any of the three extraction
#: sites. ``![[pic.png]]`` previously stored a ``pic.png.md`` row and
#: ``[img](pic.png)`` a ``pic.png`` row, both broken by construction since
#: attachments are never indexed; the bump drops those rows from notes whose
#: bytes never changed.
#:
#: Version 7 (#1334): a link is matched inside one paragraph region and a
#: destination never contains a line ending. A stray ``[`` used to pair with
#: a ``](`` paragraphs later, storing pages of prose as ``link_text`` and
#: whatever followed as a broken target; the bump drops those rows, and
#: records the links on heading, quote and list lines that the regions now
#: bound correctly, for notes whose bytes never changed.
#:
#: Version 8 (#1353): a markdown destination is read by CommonMark's grammar
#: — the ``<…>`` form, backslash escapes, balanced parentheses, a trailing
#: title, entity references — and decoded before it is resolved. Such links
#: previously stored a target no file can have (``sub/<my note.md>``,
#: ``note.md "title"``) and never resolved; the bump rebuilds notes whose
#: bytes never changed so those rows gain their targets, and drops the ones
#: that turn out to name attachments (#1333).
#:
#: Version 9 (#1350): the wikilink tie-break is Obsidian's, observed — an
#: exact vault path, else the source note's own folder, else the shortest
#: path string. A vault holding duplicate note names resolved a bare
#: ``[[Note]]`` to the shortest path everywhere; the bump re-resolves the
#: rows whose source sits beside a same-named note, which now win.
#:
#: Version 10 (#1517): an inline link's text is read with escapes honoured,
#: so a ``\]`` no longer closes it. ``[a\]b](x.md)`` is a valid CommonMark
#: link that previously produced no row at all — the note's own outlink and
#: the target's backlink both missing — and the bump records those links
#: for notes whose bytes never changed. It also drops the rows behind the
#: opposite spelling: ``[a\](x.md)``, whose text ends at an escaped ``]``,
#: closes no link for CommonMark either and no longer stores one. Only
#: notes whose link text carries a backslash are affected; the scan and
#: the class it replaces agree on every other note (pinned by
#: ``tests/test_links_escaped_text.py``).
#:
#: Version 10 also covers the reference family (#1519), which the first
#: change left on the plain class. A reference usage's two labels and a
#: definition's one are read by the same scan, so ``[Bra\]cket][ref]``
#: and ``[r\]ef]: x.md`` store the rows they always should have, and the
#: mirror spelling — a label ending at an escaped ``]``, ``[a\][ref]`` —
#: no longer stores one. This extends the note rather than bumping to 11
#: because no tag contains the commit that set 10 (``AGENTS.md``, once per
#: release): a deployed vault rebuilding to 10 gets both changes at once.
#: The same "nothing else moved" property backs it, pinned by
#: ``tests/test_links_escaped_reference_labels.py``.
#:
#: Version 10 also adopts CommonMark's opener rule (#1526), and this part
#: moves rows on purpose, so "nothing else moved" is precisely what it does
#: *not* claim. A ``]`` closes the **nearest unmatched** ``[`` rather than
#: the first one since the last ``]``, which was three recorded departures
#: at once: ``[a[b](x.md)`` stored its text as ``a[b`` where it is ``b``;
#: ``[a [b] c](x.md)`` stored no row at all, though its text merely holds a
#: balanced pair; and ``![a[b](x.md)`` was read as an image, because the
#: ``!`` sits before the outer ``[`` while the link opens at the inner one.
#: So the bump adds rows for balanced and image-prefixed spellings, and
#: rewrites ``link_text`` for any link whose text held an unmatched ``[``;
#: no ``target_path`` changes for a link that already had a row. Agreement
#: with a CommonMark reader is pinned over every short bracket arrangement
#: (``tests/test_links_commonmark_openers.py``) — the claim that matters
#: once "unchanged" is no longer one.
#:
#: Version 10 also carries that opener rule across to the reference family
#: (#1528), which #1526 left on the old one because its shape is two
#: adjacent bracket spans rather than one followed by ``(``. Sharing the
#: *walk* rather than the whole scan is what let the rule move: both
#: families now step through ``iter_bracket_links`` and differ only in what
#: must follow a closed span. This moves rows on purpose too.
#: ``[a[b][r]`` stores its text as ``b`` and not ``a[b``; ``[a [b] c][r]``
#: gains the row it never had; and ``![alt][r]`` loses one, because it is
#: an image and the inline family has always skipped those. That last is
#: the only part that *removes* a row a real vault is likely to hold, and
#: it removes only image references naming a **note**: one naming an image
#: already stored nothing, dropped by the attachment filter. Agreement with
#: a CommonMark reader is pinned in
#: ``tests/test_links_reference_openers.py``, and measured over every
#: bracket arrangement up to seven characters with two single-letter
#: labels defined: 5682 inputs disagreed before and 5574 after, so 108
#: were fixed and **none** that agreed now disagree. The before half of
#: that comparison needs the pre-change code and so cannot live in CI;
#: the after half was pinned by that module's wider-corpus property,
#: which #1531 then tightened from a recorded shortfall to exact
#: agreement.
#:
#: What that left was the shortcut form (``[label]`` with no second
#: span), the whole of the remaining disagreement with a CommonMark
#: reader. It was never a shape test away: a reader falls back from the
#: full form to the shortcut one when the label lookup *fails*, so the
#: scan had to consult a definition table it knew nothing about.
#:
#: #1531 supplied exactly that, so version 10 covers the shortcut form
#: too — ``[label]`` standing alone, which no version had ever stored.
#: It is the largest of these in rows added: every bare label in a vault
#: that matches a definition gains an outlink and gives its target a
#: backlink. A label with no definition stores nothing, which is what
#: keeps a bracketed aside from becoming a link.
#:
#: Two corrections to the *definition* side ride with it, and they change
#: which rows every form produces, not just the new one. A definition's
#: destination may sit on the next line but not across a blank one, and
#: its label may not contain a blank line either; the scan allowed both,
#: so ``[:]:`` followed by a blank line and an unrelated ``[ar]: x.md``
#: defined the label ``:`` with that whole line as its target, and a stray
#: ``[`` could swallow a real definition into a label. Neither produced a
#: wrong row before, because nothing resolved against those entries — the
#: two-span usage shape could not reference them. The shortcut form can,
#: which is how they surfaced.
#:
#: With this the reference family agrees with a CommonMark reader on the
#: whole generated corpus: 462 disagreements before and 0 after on the
#: narrow corpus, 5574 and 0 on the wide one
#: (``tests/test_links_reference_openers.py``, now asserted as equality
#: rather than containment, and ``tests/test_links_shortcut_references.py``).
#:
#: Still one bump: no tag contains the commit that set 10, so all five
#: changes reach a deployed vault as a single rebuild (``AGENTS.md``, once
#: per release).
INDEX_SEMANTICS_VERSION = 10


class ChunkingMeta(NamedTuple):
    """Embedding/indexing provenance recorded with an FTS build (#649).

    Attributes:
        model: Embedding model name, or ``None`` when no provider is
            configured.
        max_chunk_chars_override: The explicit operator ``MAX_CHUNK_CHARS``
            override in force, or ``None`` when the cap was derived from the
            model context.
        title_field: Frontmatter key used for title resolution at build time
            (default ``"title"``).
        searchable_fields: Comma-joined canonical form of the searchable
            frontmatter fields feeding the FTS ``summary`` column (default
            ``""`` — none configured).
        indexed_frontmatter_fields: Comma-joined canonical form of the
            frontmatter fields promoted to ``document_tags`` for structured
            filtering (default ``""`` — none configured).
        attachment_extensions: Canonical form of the attachment allowlist
            link extraction consulted (default ``""`` — the built-in set;
            see :data:`_META_ATTACHMENT_EXTENSIONS_KEY`).
        semantics_version: :data:`INDEX_SEMANTICS_VERSION` in force when the
            build ran (``0`` for an index written before the key existed).
    """

    model: str | None
    max_chunk_chars_override: int | None
    title_field: str = "title"
    searchable_fields: str = ""
    indexed_frontmatter_fields: str = ""
    attachment_extensions: str = ""
    semantics_version: int = 0


def _escape_like(value: str) -> str:
    """Escape SQLite LIKE special characters in ``value``.

    SQLite LIKE treats ``%`` and ``_`` as wildcards and ``\\`` as the escape
    character (when ``ESCAPE '\\'`` is declared).  This function escapes all
    three so that a user-supplied folder name is matched literally.

    Args:
        value: Raw string that will be embedded in a LIKE pattern.

    Returns:
        String with ``\\``, ``%``, and ``_`` replaced by their escaped forms.
    """
    return value.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


def _is_fts5_query_error(exc: sqlite3.OperationalError) -> bool:
    """True when an ``OperationalError`` is an FTS5 *query-syntax* error.

    Distinguishes a malformed MATCH expression (user input problem, safe to
    recover from) from an environmental error such as a database lock (must
    propagate). Matches the error strings SQLite emits for FTS5 query
    problems: ``fts5: syntax error``, ``no such column`` (a bareword parsed as
    a column filter), and ``unterminated string``.
    """
    msg = str(exc).lower()
    return (
        "fts5" in msg
        or "syntax error" in msg
        or "no such column" in msg
        or "unterminated" in msg
    )


def _quote_fts_query(query: str) -> str:
    """Quote each whitespace-separated token as an FTS5 string literal.

    FTS5 query syntax treats characters like ``-`` and ``:`` between barewords
    as operators/column filters, so a natural-language query such as
    ``File-back Ingest Lint`` or a slug like ``vault-mcp`` is rejected with an
    ``OperationalError`` (#866). Wrapping each token in a string literal
    (``"File-back" "Ingest" "Lint"`` — case is preserved; FTS5's tokenizer
    handles case-folding) turns the query into an implicit-AND of phrase
    literals: the special characters are matched literally, a compound
    like ``File-back`` becomes an adjacency phrase over its tokens, and no
    token can be mistaken for an operator or column reference. Internal quotes
    are escaped by doubling, per FTS5's literal grammar.

    Args:
        query: The raw user query that FTS5 rejected.

    Returns:
        A space-joined string of quoted literals, or ``""`` when *query* has
        no tokens (the caller then returns no results).
    """
    tokens = query.split()
    return " ".join(f'"{token.replace(chr(34), chr(34) * 2)}"' for token in tokens)


def _derive_folder(path: str) -> str:
    """Derive the folder from a document's relative path.

    Args:
        path: Document relative path including ``.md`` extension,
            e.g. ``"Journal/2024-01-15.md"`` or ``"README.md"``.

    Returns:
        The parent directory as a forward-slash string, or ``""`` for
        documents at the vault root. Examples::

            "Journal/note.md"             -> "Journal"
            "Journal/2024/January/a.md"   -> "Journal/2024/January"
            "README.md"                   -> ""
    """
    parent = Path(path).parent
    # PurePosixPath('.') means no parent directory.
    folder = parent.as_posix()
    return "" if folder == "." else folder


def _pick_wikilink_candidate(candidates: list[str], source_path: str) -> str:
    """Tie-break among several documents matching one wikilink.

    Observed on Obsidian 1.13.7 (#1350): once no exact vault path matches,
    a candidate in the source note's own folder wins — an ancestor folder
    counts for nothing — and otherwise the shortest path *string* does (not
    fewest components, not file-tree order). Two candidates of equal length
    and standing were not observed; the lexicographically first is taken so
    the answer does not depend on index history.

    Args:
        candidates: Vault-relative paths of the matching documents.
        source_path: Vault-relative path of the note holding the link.

    Returns:
        The chosen candidate.
    """
    source_dir = source_path.rpartition("/")[0]
    own_folder = [p for p in candidates if p.rpartition("/")[0] == source_dir]
    return min(own_folder or candidates, key=lambda p: (len(p), p))


class FTSIndex:
    """SQLite FTS5 index providing BM25 search and tag filtering.

    Wraps a SQLite database file (or in-memory database) and exposes CRUD
    operations and full-text search over a vault of markdown documents.

    **Thread safety (issue #519):** every public method is safe to call from
    any thread. Each thread that touches the index opens its own
    ``sqlite3.Connection`` on first use via :meth:`_conn`; a side registry
    (``SqliteConnectionRegistry.all_conns`` in ``_fts_connection.py``,
    guarded by ``reg_lock``) holds strong refs so
    :meth:`close` can close every connection — including those opened by
    threads that have since exited. Concurrent index mutations are
    serialised by the single-owner :class:`IndexWriter` thread (#559),
    not by this class. After :meth:`close`,
    every public method raises ``sqlite3.ProgrammingError``. See
    ``docs/design/design.md`` "Vault thread-safety contract" for the full
    contract.

    Tag indexing behaviour is controlled by ``indexed_frontmatter_fields``:
    only the listed frontmatter keys are promoted into the ``document_tags``
    table for structured filtering.  Scalar values produce one row each; list
    values produce one row per item (deduplicated per document).  Complex
    types (nested dicts, objects) are stored in the raw JSON blob only and
    are not indexed.

    Args:
        db_path: Path to the SQLite database file.  Pass ``":memory:"`` (the
            default) for a transient in-memory database.
        indexed_frontmatter_fields: Frontmatter keys whose values are
            promoted to the ``document_tags`` table.  ``None`` means no tag
            indexing.
        searchable_frontmatter_fields: Frontmatter keys whose scalar values
            are newline-joined into the ``notes_fts.summary`` column on each
            document's chunk-0 row, making them keyword-searchable.  ``None``
            (default) stores an empty summary.
        fts_weights: Per-column BM25 weights (keys are FTS column names in
            ``path``, ``title``, ``folder``, ``heading``, ``content``,
            ``summary``; missing keys default to ``1.0``).  Persisted into
            the FTS5 rank configuration at init; ``None`` or all-``1.0``
            resets to the default ``bm25()``.
    """

    # notes_fts column order — bm25() weight argument order must match.
    _FTS_COLUMNS = ("path", "title", "folder", "heading", "content", "summary")

    def __init__(
        self,
        db_path: Path | str = ":memory:",
        indexed_frontmatter_fields: list[str] | None = None,
        *,
        searchable_frontmatter_fields: list[str] | None = None,
        fts_weights: dict[str, float] | None = None,
    ) -> None:
        self._db_path = db_path
        self._indexed_fields: list[str] = indexed_frontmatter_fields or []
        self._searchable_fields: tuple[str, ...] = tuple(
            searchable_frontmatter_fields or ()
        )
        self._fts_weights: dict[str, float] = dict(fts_weights or {})
        # SearchConfig validates fts_weights keys, but direct FTSIndex/Vault
        # construction bypasses it; an unknown column is silently ignored by
        # _persist_rank_config (get(col, 1.0)). Warn so a typo'd column
        # ("titel") is visible rather than degrading to default ranking.
        unknown_weight_cols = set(self._fts_weights) - set(self._FTS_COLUMNS)
        if unknown_weight_cols:
            logger.warning(
                "fts_index_unknown_weights_ignored columns=%s valid_columns=%s",
                sorted(unknown_weight_cols),
                ", ".join(self._FTS_COLUMNS),
            )
        # Thread-safety core (#519): per-thread connections, the strong-ref
        # close registry, and the BaseException-hardened bootstrap live in
        # the extracted SqliteConnectionRegistry (#760). Schema DDL and the
        # shared-cache probe stay FTSIndex-owned and run via callbacks.
        self._registry = SqliteConnectionRegistry(db_path)
        self._registry.open_primary(self._init_schema, self._probe_shared_cache)

    def _init_schema(self, conn: sqlite3.Connection) -> None:
        """Run DDL, migrations, and WAL on the primary connection.

        Called exactly once per ``FTSIndex`` instance, on the constructing
        thread. Per-thread opens do NOT call this method — they only apply
        pragmas, since DDL and WAL are persisted in the DB header.
        """
        conn.executescript(_SCHEMA_SQL)
        try:
            conn.execute(
                "ALTER TABLE links ADD COLUMN raw_target TEXT NOT NULL DEFAULT ''"
            )
            conn.commit()
        except sqlite3.OperationalError as e:
            if "duplicate column name" not in str(e).lower():
                raise
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS document_aliases (
                id INTEGER PRIMARY KEY,
                document_id INTEGER NOT NULL,
                alias TEXT NOT NULL,
                UNIQUE(document_id, alias),
                FOREIGN KEY (document_id) REFERENCES documents(id) ON DELETE CASCADE
            );
            CREATE INDEX IF NOT EXISTS idx_aliases_alias ON document_aliases(alias);
            CREATE INDEX IF NOT EXISTS idx_aliases_docid ON document_aliases(document_id);
            """
        )
        cols = {
            r["name"] for r in conn.execute("PRAGMA table_info(documents)").fetchall()
        }
        if "chunk_count" not in cols:
            try:
                conn.execute(
                    "ALTER TABLE documents ADD COLUMN chunk_count INTEGER NOT NULL DEFAULT 1"
                )
                conn.commit()
                logger.info("fts_index_migrated_column column=chunk_count")
            except sqlite3.OperationalError as exc:
                if "duplicate column name" not in str(exc).lower():
                    raise
                logger.debug("fts_index_column_already_added column=chunk_count")
        if "content_chars" not in cols:
            try:
                conn.execute(
                    "ALTER TABLE documents ADD COLUMN content_chars INTEGER NOT NULL DEFAULT 0"
                )
                conn.commit()
                logger.info("fts_index_migrated_column column=content_chars")
            except sqlite3.OperationalError as exc:
                if "duplicate column name" not in str(exc).lower():
                    raise
                logger.debug("fts_index_column_already_added column=content_chars")
        self._migrate_tombstone_columns(conn, cols)
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_sections_docid ON sections(document_id)"
        )
        # Drop-then-create so a future documents column addition refreshes the
        # view's SELECT * expansion (a view snapshots the column list at
        # CREATE time).
        conn.execute("DROP VIEW IF EXISTS documents_live")
        conn.execute(
            "CREATE VIEW documents_live AS "
            "SELECT * FROM documents WHERE skip_category IS NULL"
        )
        conn.commit()
        self._migrate_notes_fts_summary(conn)
        self._migrate_fts_rowid_map(conn)
        self._persist_rank_config(conn)
        # WAL is a DB-header pragma — persists across opens. Skip for in-memory
        # databases (SQLite silently falls back to 'memory' journal mode there).
        if not self._registry.is_memory:
            result = conn.execute("PRAGMA journal_mode = WAL").fetchone()
            if result is None or str(result[0]).lower() != "wal":
                logger.warning(
                    "wal_mode_not_enabled result=%s impact=concurrent_reads_may_block",
                    result[0] if result else "no result",
                )
        conn.commit()

    def _migrate_tombstone_columns(
        self, conn: sqlite3.Connection, cols: set[str]
    ) -> None:
        """Add the skip-tombstone columns to a pre-#1129 ``documents`` table.

        Additive migration following the ``chunk_count`` / ``content_chars``
        precedent: ``ALTER TABLE ADD COLUMN`` guarded by the PRAGMA column
        set, tolerating a duplicate-column race with a concurrent process.
        ``skip_category`` is ``NULL`` on every pre-existing row, so all
        migrated rows read as live through ``documents_live``.

        Args:
            conn: The primary connection (inside :meth:`_init_schema`).
            cols: The ``PRAGMA table_info(documents)`` column-name set.
        """
        for name, ddl in (
            ("skip_category", "ALTER TABLE documents ADD COLUMN skip_category TEXT"),
            (
                "skip_detail",
                "ALTER TABLE documents ADD COLUMN skip_detail TEXT NOT NULL DEFAULT ''",
            ),
        ):
            if name in cols:
                continue
            try:
                conn.execute(ddl)
                conn.commit()
                logger.info("fts_index_migrated_column column=%s", name)
            except sqlite3.OperationalError as exc:
                if "duplicate column name" not in str(exc).lower():
                    raise
                logger.debug("fts_index_column_already_added column=%s", name)

    def _migrate_notes_fts_summary(self, conn: sqlite3.Connection) -> None:
        """Migrate a legacy 5-column ``notes_fts`` to the 6-column schema.

        FTS5 virtual tables do not support ``ALTER TABLE ADD COLUMN``, so a
        pre-``summary`` table is dropped, recreated with the current schema,
        and repopulated in pure SQL from the ``sections``/``documents``
        source of truth — no filesystem rescan.  Migrated rows carry an
        empty ``summary`` (correct for the default configuration; a
        non-default ``searchable_frontmatter_fields`` change flips the
        chunking provenance and triggers a cold rebuild anyway).  The
        ``meta`` table is untouched, so the warm-restart completeness
        sentinel survives the migration.

        The DROP/CREATE/INSERT run inside one explicit transaction rather
        than :meth:`sqlite3.Connection.executescript`, which commits before
        it runs and leaves each statement to autocommit individually. A
        crash (SIGKILL/OOM/power loss) between the CREATE and the INSERT
        would otherwise leave a present-but-empty ``notes_fts``; the next
        boot would see the ``summary`` column, early-return here, and the
        warm-restart short-circuit (meta sentinel + ``documents`` both
        intact) would skip the rebuild — keyword search silently returning
        nothing forever. On any failure the transaction rolls back, so the
        legacy table is preserved and the migration retries cleanly on the
        next boot.

        Args:
            conn: The primary connection (inside :meth:`_init_schema`).
        """
        cols = {
            r["name"] for r in conn.execute("PRAGMA table_info(notes_fts)").fetchall()
        }
        if "summary" in cols:
            return
        try:
            conn.execute("BEGIN")
            conn.execute("DROP TABLE notes_fts")
            conn.execute(
                "CREATE VIRTUAL TABLE notes_fts USING fts5("
                "path, title, folder, heading, content, summary, "
                "tokenize='porter unicode61')"
            )
            conn.execute(
                "INSERT INTO notes_fts"
                "(path, title, folder, heading, content, summary) "
                "SELECT d.path, d.title, d.folder, COALESCE(s.heading, ''), "
                "s.content, '' "
                "FROM sections s "
                "JOIN documents d ON d.id = s.document_id"
            )
            conn.commit()
        except sqlite3.Error:
            conn.rollback()
            logger.error(
                "fts_index_notes_fts_summary_migration_failed "
                "table_state=legacy_preserved retry=on_next_boot",
                exc_info=True,
            )
            raise
        logger.info("fts_index_migrated_notes_fts_summary source=sections")

    def _migrate_fts_rowid_map(self, conn: sqlite3.Connection) -> None:
        """Backfill ``notes_fts_rowid_map`` for a pre-#1535 database.

        A database created before the rowid-delete fix (#1535) has
        ``notes_fts`` rows with no corresponding bridge-table entry, so
        :meth:`_delete_document` would find nothing to delete by rowid.
        Populate it once, in pure SQL, from the ``notes_fts``/``documents``
        join on path — the same join every reader already performs, so no
        filesystem rescan is needed. Idempotent (``INSERT OR IGNORE`` plus
        a meta sentinel), so a crash between the backfill and the sentinel
        write just reruns harmlessly on the next open. Must run after
        :meth:`_migrate_notes_fts_summary`, whose DROP/CREATE assigns fresh
        rowids this join has to see.

        Args:
            conn: The primary connection (inside :meth:`_init_schema`).
        """
        row = conn.execute(
            "SELECT 1 FROM meta WHERE key = ?",
            (_META_FTS_ROWID_MAP_BACKFILLED_KEY,),
        ).fetchone()
        if row is not None:
            return
        logger.info(
            "fts_index_rowid_map_backfill_started "
            "scope=full_notes_fts_scan reason=pre_1535_database"
        )
        conn.execute(
            "INSERT OR IGNORE INTO notes_fts_rowid_map (document_id, fts_rowid) "
            "SELECT d.id, f.rowid FROM notes_fts f "
            "JOIN documents d ON d.path = f.path"
        )
        conn.execute(
            "INSERT OR REPLACE INTO meta(key, value) VALUES(?, ?)",
            (_META_FTS_ROWID_MAP_BACKFILLED_KEY, "1"),
        )
        conn.commit()
        logger.info("fts_index_rowid_map_backfill_completed reason=pre_1535_database")

    def _persist_rank_config(self, conn: sqlite3.Connection) -> None:
        """Persist the BM25 per-column weights into the FTS5 rank config.

        When any configured weight differs from ``1.0``, writes a weighted
        ``bm25(...)`` rank function (arguments in ``notes_fts`` column
        order; unspecified columns weigh ``1.0``).  Otherwise writes the
        default ``bm25()`` — an idempotent reset so removing the
        ``FTS_WEIGHTS`` configuration restores default ranking.  ``f.rank``
        reads pick the persisted function up transparently.

        Args:
            conn: The primary connection (inside :meth:`_init_schema`).
        """
        weights = [self._fts_weights.get(col, 1.0) for col in self._FTS_COLUMNS]
        if any(w != 1.0 for w in weights):
            rank = "bm25({})".format(", ".join(f"{w:g}" for w in weights))
        else:
            rank = "bm25()"
        conn.execute(
            "INSERT INTO notes_fts(notes_fts, rank) VALUES('rank', ?)",
            (rank,),
        )
        conn.commit()
        logger.debug("fts_index_rank_config_persisted rank=%s", rank)

    def _probe_shared_cache(self) -> None:
        """Verify that a second connection to the same in-memory URI sees the schema.

        If ``SQLITE_ENABLE_SHARED_CACHE`` is unavailable in this SQLite build,
        the second connection will see an empty database — per-thread reads
        would then fail with confusing OperationalErrors. Surface that
        condition immediately with an operator-actionable error.
        """
        # The probe connection intentionally bypasses the close registry: it
        # is opened and closed entirely within this method before the FTSIndex
        # instance is exposed to any caller, so the registry-based close()
        # machinery is not needed for it.
        probe = self._registry.connect()
        try:
            row = probe.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name='documents'"
            ).fetchone()
            if row is None:
                raise RuntimeError(
                    "FTSIndex: in-memory shared-cache probe failed — this SQLite "
                    "build appears to lack SQLITE_ENABLE_SHARED_CACHE. Use a file "
                    "path for db_path, or rebuild SQLite with shared-cache support."
                )
        finally:
            try:
                probe.close()
            except sqlite3.Error:
                logger.debug(
                    "fts_index_probe_close_failed",
                    exc_info=True,
                )

    def _conn(self) -> sqlite3.Connection:
        """Return this thread's sqlite3 connection, opening one on first touch.

        Delegates to :meth:`SqliteConnectionRegistry.conn` — see there for
        the double-checked-locking contract and the note on connection
        accumulation.

        Raises:
            sqlite3.ProgrammingError: If ``close()`` has been called.
        """
        return self._registry.conn()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _insert_document(
        self,
        cur: sqlite3.Cursor,
        note: ParsedNote,
        folder: str,
    ) -> int:
        """Insert a row into ``documents`` and return its new ``id``.

        Args:
            cur: Active cursor inside the current transaction.
            note: Parsed document to insert.
            folder: Pre-derived folder string.

        Returns:
            The ``ROWID`` / ``id`` of the newly inserted document row.

        Raises:
            RuntimeError: If the INSERT did not return a row ID.
        """
        cur.execute(
            """
            INSERT INTO documents (path, title, folder, frontmatter_json,
                                   content_hash, modified_at, chunk_count,
                                   content_chars)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                note.path,
                note.title,
                folder,
                json.dumps(note.frontmatter, default=_json_default),
                note.content_hash,
                note.modified_at,
                len(note.chunks),
                note.content_chars,
            ),
        )
        if cur.lastrowid is None:
            raise RuntimeError("INSERT did not return a row ID")
        return cur.lastrowid

    def _insert_sections(
        self,
        cur: sqlite3.Cursor,
        document_id: int,
        note: ParsedNote,
    ) -> None:
        """Insert all chunks for a document into ``sections``.

        Also inserts one row per chunk into the ``notes_fts`` virtual table,
        and one bridging row per chunk into ``notes_fts_rowid_map`` (mapping
        ``document_id`` to the new ``notes_fts`` rowid), so a later delete
        can target ``notes_fts`` by rowid instead of scanning it by path.
        The ``summary`` column carries the newline-joined scalar values of
        the configured ``searchable_frontmatter_fields`` on the chunk-0 row
        only (``""`` for every other row and when no fields are configured),
        so frontmatter text is keyword-searchable without perturbing the
        per-chunk ``content`` column.

        Args:
            cur: Active cursor inside the current transaction.
            document_id: The ``id`` of the parent document row.
            note: Parsed document whose chunks are to be inserted.

        Raises:
            RuntimeError: If the INSERT did not return a row ID.
        """
        folder = _derive_folder(note.path)
        summary = _fields_text(note.frontmatter, self._searchable_fields)
        for i, chunk in enumerate(note.chunks):
            cur.execute(
                """
                INSERT INTO sections (document_id, heading, heading_level,
                                      content, start_line)
                VALUES (?, ?, ?, ?, ?)
                """,
                (
                    document_id,
                    chunk.heading,
                    chunk.heading_level,
                    chunk.content,
                    chunk.start_line,
                ),
            )
            cur.execute(
                """
                INSERT INTO notes_fts (path, title, folder, heading, content,
                                       summary)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    note.path,
                    note.title,
                    folder,
                    chunk.heading or "",
                    chunk.content,
                    summary if i == 0 else "",
                ),
            )
            fts_rowid = cur.lastrowid
            if fts_rowid is None:
                raise RuntimeError("INSERT did not return a row ID")
            cur.execute(
                "INSERT INTO notes_fts_rowid_map (document_id, fts_rowid) "
                "VALUES (?, ?)",
                (document_id, fts_rowid),
            )

    def _insert_tags(
        self,
        cur: sqlite3.Cursor,
        document_id: int,
        note: ParsedNote,
    ) -> None:
        """Index frontmatter values into ``document_tags``.

        Only keys listed in ``indexed_frontmatter_fields`` are processed.
        Scalar values produce one row; list values produce one row per item
        (deduplicated per document).  Complex types (dicts, etc.) are skipped.

        Args:
            cur: Active cursor inside the current transaction.
            document_id: The ``id`` of the parent document row.
            note: Parsed document whose frontmatter is to be indexed.
        """
        if not self._indexed_fields:
            return

        for key in self._indexed_fields:
            value = note.frontmatter.get(key)
            if value is None:
                continue

            if isinstance(value, list):
                # One row per item; skip non-scalar elements.
                seen: set[str] = set()
                for item in value:
                    if (
                        isinstance(item, (str, int, float, bool))
                        and not isinstance(item, bool)
                    ) or isinstance(item, bool):
                        # Accept all scalar types.
                        tag_val = str(item)
                        if tag_val not in seen:
                            seen.add(tag_val)
                            cur.execute(
                                """
                                INSERT OR IGNORE INTO document_tags
                                    (document_id, tag_key, tag_value)
                                VALUES (?, ?, ?)
                                """,
                                (document_id, key, tag_val),
                            )
            elif isinstance(value, dict):
                # Complex type — skip.
                logger.debug(
                    "complex_frontmatter_value_skipped key=%r path=%s",
                    key,
                    note.path,
                )
            else:
                # Scalar value.
                cur.execute(
                    """
                    INSERT OR IGNORE INTO document_tags
                        (document_id, tag_key, tag_value)
                    VALUES (?, ?, ?)
                    """,
                    (document_id, key, str(value)),
                )

    def _insert_aliases(
        self,
        cur: sqlite3.Cursor,
        document_id: int,
        note: ParsedNote,
    ) -> None:
        """Index frontmatter ``aliases`` into ``document_aliases``.

        Obsidian allows documents to declare alternative names via a YAML
        ``aliases`` field (list of strings).  These are stored so that
        :meth:`resolve_vault_wikilinks` can resolve ``[[Alias]]`` to the
        document that declares it.

        Both ``aliases`` (list) and ``alias`` (single string) frontmatter
        keys are supported, matching Obsidian's behaviour.

        Args:
            cur: Active cursor inside the current transaction.
            document_id: The ``id`` of the parent document row.
            note: Parsed document whose aliases are to be indexed.
        """
        raw = note.frontmatter.get("aliases") or note.frontmatter.get("alias")
        if raw is None:
            return

        values: list[str] = []
        if isinstance(raw, str):
            values = [raw]
        elif isinstance(raw, list):
            values = [str(item) for item in raw if isinstance(item, (str, int, float))]
        else:
            return

        seen: set[str] = set()
        for alias in values:
            alias = alias.strip()
            if alias and alias not in seen:
                seen.add(alias)
                cur.execute(
                    """
                    INSERT OR IGNORE INTO document_aliases
                        (document_id, alias)
                    VALUES (?, ?)
                    """,
                    (document_id, alias),
                )

    def _insert_links(
        self,
        cur: sqlite3.Cursor,
        document_id: int,
        note: ParsedNote,
    ) -> None:
        """Insert all extracted links for a document into ``links``.

        Follows the same delete-then-insert pattern as :meth:`_insert_tags`.
        Any existing links for ``document_id`` are removed first (via ON DELETE
        CASCADE when the document row is deleted), so this method simply inserts.

        Args:
            cur: Active cursor inside the current transaction.
            document_id: The ``id`` of the parent document row.
            note: Parsed document whose links are to be inserted.
        """
        for link in note.links:
            cur.execute(
                """
                INSERT INTO links (source_id, target_path, link_text,
                                   link_type, fragment, raw_target)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    document_id,
                    link.target_path,
                    link.link_text,
                    link.link_type,
                    link.fragment,
                    link.raw_target,
                ),
            )

    def _delete_document(self, cur: sqlite3.Cursor, path: str) -> int:
        """Delete a document row (cascade deletes sections, tags, and the
        notes_fts rowid bridge entries) and its notes_fts rows.

        Looks up ``document_id`` through the ``documents.path`` unique
        index, then deletes notes_fts rows by an indexed rowid lookup
        through ``notes_fts_rowid_map`` rather than scanning notes_fts's
        content-carrying shadow table (#1535; see
        docs/design/reference/sqlite-fts5.md).

        Args:
            cur: Active cursor inside the current transaction.
            path: Relative document path.

        Returns:
            Number of document rows deleted (0 or 1).
        """
        row = cur.execute("SELECT id FROM documents WHERE path = ?", (path,)).fetchone()
        if row is None:
            return 0
        document_id = row["id"]
        cur.execute(_DELETE_NOTES_FTS_BY_DOCUMENT_SQL, (document_id,))
        cur.execute("DELETE FROM documents WHERE path = ?", (path,))
        return cur.rowcount

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def build_from_notes(self, notes: Iterable[ParsedNote]) -> int:
        """Bulk-insert all notes, replacing any existing data.

        Existing documents are upserted (delete + re-insert) so
        ``build_from_notes`` is idempotent when called on an already-populated
        index.  All inserts are wrapped in a single transaction for
        performance and atomicity.

        Materialises *notes* into a list BEFORE the retry window opens.
        The :func:`_retry_on_sqlite_locked` helper re-invokes its
        operation on a transient ``SQLITE_LOCKED``; a one-shot generator
        would otherwise be empty on retry. Cannot use ``@_retry_on_locked``
        directly here because the decorator captures the original
        argument tuple — the generator would be exhausted by the first
        attempt before the inner ``list()`` call runs.

        Args:
            notes: Iterable of parsed documents to index.

        Returns:
            Total number of chunks (sections) indexed.
        """
        notes_list = list(notes)

        def _do() -> int:
            return self._build_from_notes_inner(notes_list)

        return _retry_on_sqlite_locked(_do)

    def _build_from_notes_inner(self, notes: list[ParsedNote]) -> int:
        """Inner body of :meth:`build_from_notes`, safe to re-invoke on retry."""
        total_chunks = 0
        conn = self._conn()
        with conn:
            cur = conn.cursor()
            for note in notes:
                folder = _derive_folder(note.path)
                self._delete_document(cur, note.path)
                doc_id = self._insert_document(cur, note, folder)
                self._insert_sections(cur, doc_id, note)
                self._insert_tags(cur, doc_id, note)
                self._insert_aliases(cur, doc_id, note)
                self._insert_links(cur, doc_id, note)
                total_chunks += len(note.chunks)
                logger.debug(
                    "build_from_notes_indexed_note chunk_count=%d path=%s",
                    len(note.chunks),
                    note.path,
                )
        logger.info("build_from_notes_completed total_chunk_count=%d", total_chunks)
        return total_chunks

    @_retry_on_locked
    def upsert_note(self, note: ParsedNote) -> int:
        """Insert or replace a single document in the index.

        Deletes any existing rows for ``note.path``, then inserts the
        document, its sections, and its tags in a single transaction.

        Args:
            note: Parsed document to insert or replace.

        Returns:
            Number of chunks (sections) indexed for this document.
        """
        folder = _derive_folder(note.path)
        conn = self._conn()
        with conn:
            cur = conn.cursor()
            self._delete_document(cur, note.path)
            doc_id = self._insert_document(cur, note, folder)
            self._insert_sections(cur, doc_id, note)
            self._insert_tags(cur, doc_id, note)
            self._insert_aliases(cur, doc_id, note)
            self._insert_links(cur, doc_id, note)
        logger.debug(
            "upsert_note_indexed chunk_count=%d path=%s", len(note.chunks), note.path
        )
        return len(note.chunks)

    @_retry_on_locked
    def delete_by_path(self, path: str) -> int:
        """Remove a document and all its data from the index.

        Args:
            path: Relative document path (e.g. ``"Journal/note.md"``).

        Returns:
            Number of document rows deleted (0 if path was not indexed).
        """
        conn = self._conn()
        with conn:
            cur = conn.cursor()
            deleted = self._delete_document(cur, path)
        if deleted:
            logger.debug("delete_by_path_removed path=%s", path)
        return deleted

    # ------------------------------------------------------------------
    # Skip tombstones (issue #1129)
    # ------------------------------------------------------------------

    @_retry_on_locked
    def upsert_tombstone(
        self, skip: SkippedFile, *, content_hash: str, modified_at: float
    ) -> None:
        """Record a surfaced skip as a tombstone row in ``documents``.

        Deletes any existing rows for ``skip.path`` (live or tombstone) and
        inserts a bare document row carrying the skip category and detail —
        ``chunk_count = 0``, ``content_chars = 0``, and deliberately **no**
        child rows (no ``sections``, ``notes_fts``, ``links``,
        ``document_tags``, or ``document_aliases`` entries), so every reader
        that joins through a child table sees nothing and ``documents_live``
        hides the row from direct readers. The delete + insert run in one
        transaction, mirroring :meth:`upsert_note`.

        Args:
            skip: The surfaced skip to record; ``skip.category`` must be one
                of :data:`~markdown_vault_mcp.types.SKIP_CATEGORIES`.
            content_hash: SHA-256 of the exact bytes that were evaluated,
                matching what the tracker records for the skip.
            modified_at: The file's mtime at skip time.
        """
        folder = _derive_folder(skip.path)
        conn = self._conn()
        with conn:
            cur = conn.cursor()
            self._delete_document(cur, skip.path)
            cur.execute(
                """
                INSERT INTO documents (path, title, folder, frontmatter_json,
                                       content_hash, modified_at, chunk_count,
                                       content_chars, skip_category, skip_detail)
                VALUES (?, ?, ?, NULL, ?, ?, 0, 0, ?, ?)
                """,
                (
                    skip.path,
                    Path(skip.path).stem,
                    folder,
                    content_hash,
                    modified_at,
                    skip.category,
                    skip.detail,
                ),
            )
        logger.debug(
            "upsert_tombstone_recorded path=%s category=%s", skip.path, skip.category
        )

    @_retry_on_locked
    def get_tombstone(self, path: str) -> dict[str, Any] | None:
        """Return the tombstone row for *path*, or ``None``.

        Args:
            path: Relative document path.

        Returns:
            A dict with keys ``path``, ``skip_category``, ``skip_detail``,
            ``content_hash``, ``modified_at``, or ``None`` when the path has
            no tombstone (absent entirely, or present as a live document).
        """
        row = (
            self._conn()
            .execute(
                """
                SELECT path, skip_category, skip_detail, content_hash, modified_at
                FROM documents
                WHERE path = ? AND skip_category IS NOT NULL
                """,
                (path,),
            )
            .fetchone()
        )
        return dict(row) if row is not None else None

    @_retry_on_locked
    def list_tombstones(self) -> list[dict[str, Any]]:
        """Return every tombstone row, ordered by path.

        Returns:
            List of dicts with the same shape as :meth:`get_tombstone`.
        """
        cur = self._conn().execute(
            """
            SELECT path, skip_category, skip_detail, content_hash, modified_at
            FROM documents
            WHERE skip_category IS NOT NULL
            ORDER BY path
            """
        )
        return [dict(row) for row in cur.fetchall()]

    @_retry_on_locked
    def has_documents(self) -> bool:
        """Return ``True`` when ``documents`` holds ANY row, tombstones included.

        The warm-restart gate (#1129): an index whose candidates were all
        skipped is still a completed build, so the short-circuit must count
        tombstones — keying on live rows alone would cold-rebuild an
        all-tombstone vault on every boot. A truly empty table (no build has
        ever recorded anything) still reads ``False``.
        """
        row = self._conn().execute("SELECT 1 FROM documents LIMIT 1").fetchone()
        return row is not None

    def optimize(self) -> bool:
        """Merge FTS5 inverted-index segments, dropping deleted-document tokens.

        Runs ``INSERT INTO notes_fts(notes_fts) VALUES('optimize')``, which
        merges all FTS5 segments into one and discards entries for deleted
        rows.  Call this after a bulk purge (see :func:`should_optimize`) so
        dead segments do not accumulate in the database file.

        The merge frees pages *inside* the database file; the file itself
        only shrinks after a ``VACUUM``.  ``VACUUM`` is never run
        automatically because it takes an exclusive lock and multiple server
        processes may share one index file — instead the reclaimable size
        (freelist pages times page size) is logged at INFO so operators can
        decide whether a manual vacuum is worthwhile.

        Lock contention beyond the retry budget is tolerated: the optimize
        is skipped with a warning and the next bulk purge retries.

        Returns:
            ``True`` when the optimize ran, ``False`` when it was skipped
            because the database stayed busy or locked.
        """
        conn = self._conn()

        def _do() -> None:
            with conn:
                conn.execute("INSERT INTO notes_fts(notes_fts) VALUES('optimize')")

        try:
            _retry_on_sqlite_locked(_do)
        except sqlite3.OperationalError as exc:
            msg = str(exc).lower()
            if "busy" in msg or "locked" in msg:
                logger.warning(
                    "optimize_skipped reason=database_contended error=%s "
                    "next_action=retry_on_next_purge",
                    exc,
                )
                return False
            raise
        freelist = conn.execute("PRAGMA freelist_count").fetchone()[0]
        page_size = conn.execute("PRAGMA page_size").fetchone()[0]
        reclaimable = int(freelist) * int(page_size)
        logger.info(
            "optimize_completed reclaimable_bytes=%d "
            "vacuum_hint=run_vacuum_to_reclaim_disk",
            reclaimable,
        )
        return True

    # ------------------------------------------------------------------
    # Build completeness sentinel (issue #525)
    # ------------------------------------------------------------------

    @_retry_on_locked
    def is_build_completed(self) -> bool:
        """Return ``True`` iff a prior ``build_index`` run committed the
        completeness sentinel into the ``meta`` table.

        Absence of the sentinel — paired with non-empty ``documents`` —
        signals a partial index left by a crashed prior build, and the
        caller (``IndexFacet.build_index``) treats it as cold.
        """
        conn = self._conn()
        with conn:
            row = conn.execute(
                "SELECT 1 FROM meta WHERE key = ?",
                (_META_BUILD_COMPLETED_KEY,),
            ).fetchone()
        return row is not None

    @_retry_on_locked
    def set_build_completed(self) -> None:
        """Mark the FTS index as the result of a clean full build."""
        conn = self._conn()
        ts = datetime.datetime.now(tz=datetime.UTC).isoformat()
        with conn:
            conn.execute(
                "INSERT OR REPLACE INTO meta(key, value) VALUES(?, ?)",
                (_META_BUILD_COMPLETED_KEY, ts),
            )

    @_retry_on_locked
    def clear_build_completed(self) -> None:
        """Erase the completeness sentinel (before a destructive rebuild)."""
        conn = self._conn()
        with conn:
            conn.execute("DELETE FROM meta WHERE key = ?", (_META_BUILD_COMPLETED_KEY,))

    # ------------------------------------------------------------------
    # Chunking provenance: embedding model + char cap (issue #649)
    # ------------------------------------------------------------------

    @_retry_on_locked
    def set_chunking_meta(
        self,
        *,
        model: str | None,
        max_chunk_chars_override: int | None,
        title_field: str = "title",
        searchable_fields: str = "",
        indexed_frontmatter_fields: str = "",
        attachment_extensions: str = "",
    ) -> None:
        """Record the embedding/indexing provenance used for this build.

        Persists the stable inputs that determine the FTS build's contents —
        the embedding model name, the explicit char-cap override, the title
        field, the searchable frontmatter fields, the indexed
        (structured-filter) frontmatter fields, and the attachment allowlist
        link extraction consulted — so a later warm-restart can detect a
        genuine option change and reject the short-circuit, triggering a
        cold rebuild (#649, #927, #1333).

        :data:`INDEX_SEMANTICS_VERSION` is written alongside them and is
        deliberately not a parameter: it records this build's *code*
        provenance rather than an operator input, so a pipeline change that
        alters derived rows invalidates the index the same way an option
        change does (#1124).

        Args:
            model: Embedding model name, or ``None`` when no provider is
                configured. ``None`` is stored as the empty string.
            max_chunk_chars_override: The explicit operator char-cap override
                in force, or ``None`` when the cap was derived from the model
                context. ``None`` is stored as the empty string; an int is
                stored as its decimal string form.
            title_field: Frontmatter key used for title resolution. The
                default ``"title"`` is stored as the empty string so a
                pre-upgrade index (absent key) reads back as the default.
            searchable_fields: Comma-joined canonical searchable-field list.
                The default (no fields) is already the empty string.
            indexed_frontmatter_fields: Comma-joined canonical
                structured-filter field list. The default (no fields) is
                already the empty string.
            attachment_extensions: Canonical attachment allowlist, as
                rendered by ``utils.canonical_attachment_extensions`` (the
                default set is the empty string).
        """
        conn = self._conn()
        model_value = "" if model is None else model
        override_value = (
            ""
            if max_chunk_chars_override is None
            else str(int(max_chunk_chars_override))
        )
        title_value = "" if title_field == "title" else title_field
        with conn:
            for key, value in (
                (_META_EMBED_MODEL_KEY, model_value),
                (_META_MAX_CHUNK_CHARS_OVERRIDE_KEY, override_value),
                (_META_TITLE_FIELD_KEY, title_value),
                (_META_SEARCHABLE_FIELDS_KEY, searchable_fields),
                (_META_INDEXED_FIELDS_KEY, indexed_frontmatter_fields),
                (_META_ATTACHMENT_EXTENSIONS_KEY, attachment_extensions),
                (_META_INDEX_SEMANTICS_KEY, str(INDEX_SEMANTICS_VERSION)),
            ):
                conn.execute(
                    "INSERT OR REPLACE INTO meta(key, value) VALUES(?, ?)",
                    (key, value),
                )

    @_retry_on_locked
    def get_chunking_meta(self) -> ChunkingMeta:
        """Return the recorded provenance, with defaults for absent keys.

        Returns:
            A :class:`ChunkingMeta`. An absent key or a stored empty string
            reads back as the default (``None`` for ``model`` and
            ``max_chunk_chars_override``, ``"title"`` for ``title_field``,
            ``""`` for ``searchable_fields``, ``indexed_frontmatter_fields``
            and ``attachment_extensions``);
            ``max_chunk_chars_override`` reads back as ``int``, and
            ``semantics_version`` as ``int`` (``0`` when absent or
            unparseable — either way the index predates the pipeline
            version it claims and must be rebuilt).
        """
        conn = self._conn()
        with conn:
            rows = conn.execute(
                "SELECT key, value FROM meta WHERE key IN (?, ?, ?, ?, ?, ?, ?)",
                (
                    _META_EMBED_MODEL_KEY,
                    _META_MAX_CHUNK_CHARS_OVERRIDE_KEY,
                    _META_TITLE_FIELD_KEY,
                    _META_SEARCHABLE_FIELDS_KEY,
                    _META_INDEXED_FIELDS_KEY,
                    _META_ATTACHMENT_EXTENSIONS_KEY,
                    _META_INDEX_SEMANTICS_KEY,
                ),
            ).fetchall()
        stored = {row[0]: row[1] for row in rows}
        model_raw = stored.get(_META_EMBED_MODEL_KEY)
        override_raw = stored.get(_META_MAX_CHUNK_CHARS_OVERRIDE_KEY)
        model: str | None = model_raw if model_raw else None
        # An empty string (a stored ``None``) is falsy → reads back as None;
        # config rejects a 0 override so truthiness is safe here.
        override: int | None = int(override_raw) if override_raw else None
        try:
            semantics_version = int(stored.get(_META_INDEX_SEMANTICS_KEY) or 0)
        except ValueError:
            # A hand-edited or corrupted row is not a reason to serve stale
            # derived rows: read it as "older than anything" and rebuild.
            semantics_version = 0
        return ChunkingMeta(
            model=model,
            max_chunk_chars_override=override,
            title_field=stored.get(_META_TITLE_FIELD_KEY) or "title",
            searchable_fields=stored.get(_META_SEARCHABLE_FIELDS_KEY) or "",
            indexed_frontmatter_fields=stored.get(_META_INDEXED_FIELDS_KEY) or "",
            attachment_extensions=stored.get(_META_ATTACHMENT_EXTENSIONS_KEY) or "",
            semantics_version=semantics_version,
        )

    @_retry_on_locked
    def search(
        self,
        query: str,
        *,
        limit: int = 10,
        folder: str | None = None,
        filters: dict[str, str] | None = None,
        snippet_words: int | None = None,
    ) -> list[FTSResult]:
        """Full-text search using BM25 ranking.

        Args:
            query: FTS5 query string. Well-formed operator syntax (``AND`` /
                ``OR`` / ``NEAR`` / phrases / prefixes) is honoured as-is. A
                query FTS5 rejects as malformed — most commonly a
                natural-language query with a hyphenated term or slug (e.g.
                ``vault-mcp``), which parses as a column filter — is retried
                once with every token quoted as a phrase literal, so it
                degrades to an implicit-AND term search instead of returning
                ``[]`` (#866).
            limit: Maximum number of results to return.
            folder: If provided, only return documents whose ``folder``
                starts with this string.
            filters: Dict of ``{tag_key: tag_value}`` pairs (AND semantics).
            snippet_words: When set to a positive integer, returned
                ``content`` is replaced with FTS5's ``snippet()`` of the
                matched content column, sized to approximately this many
                tokens. ``None`` or ``0`` returns the full chunk.

        Returns:
            List of :class:`~markdown_vault_mcp.types.FTSResult` ordered by
            descending BM25 score.
        """
        # Build tag subquery filters (one per entry, ANDed).
        tag_clauses: list[str] = []
        tag_params: list[str] = []
        if filters:
            for key, value in filters.items():
                tag_clauses.append(
                    "d.id IN ("
                    "  SELECT document_id FROM document_tags"
                    "  WHERE tag_key = ? AND tag_value = ?"
                    ")"
                )
                tag_params.extend([key, value])

        folder_clause = ""
        folder_params: list[str] = []
        if folder is not None:
            escaped = _escape_like(folder)
            folder_clause = "AND (d.folder = ? OR d.folder LIKE ? ESCAPE '\\')"
            folder_params = [folder, escaped + "/%"]

        tag_filter_sql = ""
        if tag_clauses:
            tag_filter_sql = "AND " + " AND ".join(tag_clauses)

        # column index 4 is the 'content' column in
        #   notes_fts USING fts5(path, title, folder, heading, content, ...)
        if snippet_words and snippet_words > 0:
            content_expr = "snippet(notes_fts, 4, '', '', '…', ?) AS content"
            snippet_params: list[object] = [snippet_words]
        else:
            content_expr = "f.content AS content"
            snippet_params = []

        # Correlated subqueries pick the matching sections row to source
        # start_line and section_id for each FTS hit, so the keyword/hybrid
        # channels can honour the documented (score DESC, start_line ASC,
        # section_id ASC) within-group tie-break.  Matching is on
        # (document_id, content, heading) — sections.content stores the
        # chunk text unmodified, the same value that notes_fts.content
        # stores; the snippet() projection only rewrites the SELECT list,
        # not the underlying f.content column referenced here.  COALESCE on
        # heading treats NULL/empty as equivalent so identical-content
        # chunks under different headings don't cross-match.  MIN()+fallback
        # 0 handles legacy on-disk indices that pre-date this query
        # (preserves prior behaviour).  Sections are inserted in document
        # order, so within one document MIN(s.id) and MIN(s.start_line)
        # resolve to the same row.  The trailing f.rowid tie-break makes the
        # candidate set itself deterministic at the LIMIT boundary when
        # several hits share a bm25 rank.
        sql = f"""
            SELECT
                f.path,
                d.title,
                d.folder,
                f.heading,
                {content_expr},
                ABS(f.rank) AS score,
                d.chunk_count AS chunk_count,
                COALESCE((
                    SELECT MIN(s.start_line)
                    FROM sections s
                    WHERE s.document_id = d.id
                      AND s.content = f.content
                      AND COALESCE(s.heading, '') = COALESCE(f.heading, '')
                ), 0) AS start_line,
                COALESCE((
                    SELECT MIN(s.id)
                    FROM sections s
                    WHERE s.document_id = d.id
                      AND s.content = f.content
                      AND COALESCE(s.heading, '') = COALESCE(f.heading, '')
                ), 0) AS section_id
            FROM notes_fts f
            JOIN documents d ON d.path = f.path
            WHERE notes_fts MATCH ?
              {folder_clause}
              {tag_filter_sql}
            ORDER BY score DESC, f.rowid ASC
            LIMIT ?
        """

        if not query:
            return []

        def _execute(match: str) -> sqlite3.Cursor:
            return self._conn().execute(
                sql,
                [*snippet_params, match, *folder_params, *tag_params, limit],
            )

        logger.debug(
            "fts_search_started query=%r folder=%r filters=%r limit=%d snippet_words=%r",
            query,
            folder,
            filters,
            limit,
            snippet_words,
        )
        try:
            cur = _execute(query)
        except sqlite3.OperationalError as exc:
            if not _is_fts5_query_error(exc):
                raise
            # #866: FTS5 rejected the raw query — e.g. a hyphenated slug like
            # `vault-mcp` parses as a column filter ("no such column: mcp").
            # Retry once with every token quoted so a natural-language query
            # degrades to an implicit-AND of phrase literals instead of
            # silently returning [] (which, in hybrid mode, masks the failure
            # as a semantic-only result).
            fallback = _quote_fts_query(query)
            if not fallback:
                logger.debug("fts_search_unrecoverable query=%r reason=%s", query, exc)
                return []
            logger.debug(
                "fts_search_rejected_retrying query=%r reason=%s fallback=%r",
                query,
                exc,
                fallback,
            )
            try:
                cur = _execute(fallback)
            except sqlite3.OperationalError as retry_exc:
                if not _is_fts5_query_error(retry_exc):
                    raise
                # Degraded but continuing: the query could not execute even
                # after quoting every token, so the caller gets []. Log at
                # WARNING (per the logging standard) so this is visible at the
                # default level rather than masking as an empty result set.
                logger.warning(
                    "fts_search_unexecutable query=%r fallback=%r reason=%s",
                    query,
                    fallback,
                    retry_exc,
                )
                return []
        rows = cur.fetchall()
        logger.debug("fts_search_completed result_count=%d query=%r", len(rows), query)

        results: list[FTSResult] = []
        for row in rows:
            results.append(
                FTSResult(
                    path=row["path"],
                    title=row["title"],
                    folder=row["folder"],
                    heading=row["heading"] or None,
                    content=row["content"],
                    score=row["score"],
                    chunk_count=row["chunk_count"],
                    start_line=row["start_line"],
                    section_id=row["section_id"],
                )
            )
        return results

    @_retry_on_locked
    def get_note(self, path: str) -> dict[str, Any] | None:
        """Return document metadata for a single note.

        Args:
            path: Relative document path.

        Returns:
            A dict with keys ``path``, ``title``, ``folder``,
            ``frontmatter_json``, ``content_hash``, ``modified_at``,
            ``content_chars``, or ``None`` if the document is not indexed.
        """
        cur = self._conn().execute(
            """
            SELECT path, title, folder, frontmatter_json,
                   content_hash, modified_at, content_chars
            FROM documents_live
            WHERE path = ?
            """,
            (path,),
        )
        row = cur.fetchone()
        if row is None:
            return None
        return dict(row)

    @_retry_on_locked
    def list_notes(self, *, folder: str | None = None) -> list[dict[str, Any]]:
        """List all indexed documents, optionally filtered by folder.

        Args:
            folder: If provided, only return documents whose ``folder``
                matches exactly or is a sub-folder of this value.

        Returns:
            List of dicts with the same shape as :meth:`get_note`.
        """
        if folder is not None:
            # Escape LIKE wildcards in the user-supplied folder value so that
            # literal '%' and '_' characters are matched as-is.
            escaped = _escape_like(folder)
            cur = self._conn().execute(
                """
                SELECT path, title, folder, frontmatter_json,
                       content_hash, modified_at, content_chars
                FROM documents_live
                WHERE folder = ? OR folder LIKE ? ESCAPE '\\'
                ORDER BY path
                """,
                (folder, escaped + "/%"),
            )
        else:
            cur = self._conn().execute(
                """
                SELECT path, title, folder, frontmatter_json,
                       content_hash, modified_at, content_chars
                FROM documents_live
                ORDER BY path
                """
            )
        return [dict(row) for row in cur.fetchall()]

    @_retry_on_locked
    def list_folders(self) -> list[str]:
        """Return all distinct folder values across the index.

        Returns:
            Sorted list of folder strings (including ``""`` for the root).
        """
        cur = self._conn().execute(
            "SELECT DISTINCT folder FROM documents_live ORDER BY folder"
        )
        return [row[0] for row in cur.fetchall()]

    @_retry_on_locked
    def list_field_values(self, field: str) -> list[str]:
        """Return all distinct tag values for a given frontmatter field.

        If ``field`` was not in ``indexed_frontmatter_fields``, returns an
        empty list.

        Args:
            field: Frontmatter key (e.g. ``"cluster"``).

        Returns:
            Sorted list of distinct value strings.
        """
        cur = self._conn().execute(
            """
            SELECT DISTINCT tag_value
            FROM document_tags
            WHERE tag_key = ?
            ORDER BY tag_value
            """,
            (field,),
        )
        return [row[0] for row in cur.fetchall()]

    @_retry_on_locked
    def count_documents(self) -> int:
        """Return the total number of live (non-tombstone) indexed documents."""
        row = self._conn().execute("SELECT COUNT(*) FROM documents_live").fetchone()
        return int(row[0])

    @_retry_on_locked
    def count_chunks(self) -> int:
        """Return the total number of chunk rows in the ``sections`` table.

        Returns:
            Integer count of all indexed chunks across all documents.
        """
        row = self._conn().execute("SELECT COUNT(*) FROM sections").fetchone()
        return int(row[0])

    @_retry_on_locked
    def list_chunks(self) -> list[dict[str, Any]]:
        """Return every indexed chunk joined with its document metadata.

        Used to converge the vector index against the FTS chunk set
        (#665): the returned rows carry exactly the shape stored as
        vector-row metadata, so callers can diff and embed without
        re-parsing source files.

        Returns:
            List of dicts with keys ``path``, ``title``, ``folder``,
            ``heading`` (may be ``None``), ``content``, ``start_line``,
            ``frontmatter_json`` (the document's stored frontmatter), and
            ``is_first_chunk`` (``True`` on each document's first row),
            ordered by document path then chunk position.
        """
        cur = self._conn().execute(
            """
            SELECT d.path, d.title, d.folder, s.heading, s.content,
                   s.start_line, d.frontmatter_json
            FROM sections AS s
            JOIN documents AS d ON d.id = s.document_id
            ORDER BY d.path, s.id
            """
        )
        rows: list[dict[str, Any]] = []
        prev_path: str | None = None
        for raw in cur.fetchall():
            row = dict(raw)
            row["is_first_chunk"] = row["path"] != prev_path
            prev_path = row["path"]
            rows.append(row)
        return rows

    @_retry_on_locked
    def get_toc(self, path: str, *, max_level: int | None = None) -> list[TocEntry]:
        """Return headings for a document, ordered by position.

        Queries the sections table for distinct non-NULL headings, ordered by
        the first row that introduces each heading.

        Args:
            path: Relative document path (e.g. ``"Journal/note.md"``).
            max_level: If set, drop headings with ``level`` greater than this.

        Returns:
            List of :class:`~markdown_vault_mcp.types.TocEntry` ordered by first appearance.
            Empty list if the document is not found or has no headings.
        """
        level_clause = "" if max_level is None else "AND heading_level <= ?"
        params: list[object] = [path]
        if max_level is not None:
            params.append(max_level)
        cur = self._conn().execute(
            f"""
            SELECT heading, heading_level
            FROM sections
            WHERE document_id = (SELECT id FROM documents WHERE path = ?)
              AND heading IS NOT NULL
              {level_clause}
            GROUP BY heading, heading_level
            ORDER BY MIN(rowid)
            """,
            params,
        )
        return [
            TocEntry(heading=row["heading"], level=row["heading_level"])
            for row in cur.fetchall()
        ]

    @_retry_on_locked
    def get_subtree_toc(
        self,
        prefix: str,
        *,
        max_level: int | None = None,
        max_notes: int = 200,
    ) -> tuple[list[SubtreeNote], bool]:
        """Return per-note headings for every document under a folder prefix.

        Matches documents whose ``folder`` equals *prefix* or is a descendant
        of it (boundary match, so ``"Project"`` never matches ``"Projects"``).

        Args:
            prefix: Folder path with no trailing slash (e.g. ``"Projects"``).
            max_level: If set, drop headings with ``level`` greater than this.
            max_notes: Cap on distinct notes returned (default 200).

        Returns:
            ``(notes, truncated)`` where *notes* is a list of
            :class:`~markdown_vault_mcp.types.SubtreeNote` ordered by path,
            each with raw :class:`~markdown_vault_mcp.types.TocEntry` headings
            (no synthetic H1 — the manager layer prepends the synthetic H1
            before exposing them to consumers), and *truncated* is True when
            more than ``max_notes`` notes matched.
        """
        escaped = _escape_like(prefix)
        doc_rows = (
            self._conn()
            .execute(
                """
            SELECT id, path, title, content_chars
            FROM documents_live
            WHERE (folder = ? OR folder LIKE ? ESCAPE '\\')
            ORDER BY path ASC
            LIMIT ?
            """,
                (prefix, escaped + "/%", max_notes + 1),
            )
            .fetchall()
        )
        truncated = len(doc_rows) > max_notes
        doc_rows = doc_rows[:max_notes]
        if not doc_rows:
            return [], truncated

        ids = [row["id"] for row in doc_rows]
        placeholders = ",".join("?" * len(ids))
        level_clause = "" if max_level is None else "AND heading_level <= ?"
        params: list[object] = [*ids]
        if max_level is not None:
            params.append(max_level)
        section_rows = (
            self._conn()
            .execute(
                f"""
            SELECT document_id, heading, heading_level
            FROM sections
            WHERE document_id IN ({placeholders})
              AND heading IS NOT NULL
              {level_clause}
            GROUP BY document_id, heading, heading_level
            ORDER BY document_id, MIN(rowid)
            """,
                params,
            )
            .fetchall()
        )

        by_doc: dict[int, list[TocEntry]] = {}
        for row in section_rows:
            by_doc.setdefault(row["document_id"], []).append(
                TocEntry(heading=row["heading"], level=row["heading_level"])
            )

        notes = [
            SubtreeNote(
                path=row["path"],
                title=row["title"],
                headings=by_doc.get(row["id"], []),
                content_chars=int(row["content_chars"] or 0),
            )
            for row in doc_rows
        ]
        return notes, truncated

    @_retry_on_locked
    def get_backlinks(
        self, path: str, *, limit: int | None = None
    ) -> list[dict[str, Any]]:
        """Return all documents that link TO the given path.

        Args:
            path: Relative document path that is the link target
                (e.g. ``"notes/topic.md"``).
            limit: If provided, return at most this many results.

        Returns:
            List of dicts with keys ``source_path``, ``source_title``,
            ``link_text``, ``link_type``, ``fragment``, ``raw_target``.
        """
        limit_clause = "" if limit is None else "LIMIT ?"
        params: tuple[str | int, ...] = (path,) if limit is None else (path, limit)
        cur = self._conn().execute(
            f"""
            SELECT d.path AS source_path,
                   d.title AS source_title,
                   l.link_text,
                   l.link_type,
                   l.fragment,
                   l.raw_target
            FROM links l
            JOIN documents d ON d.id = l.source_id
            WHERE l.target_path = ?
            ORDER BY d.path, l.rowid
            {limit_clause}
            """,
            params,
        )
        return [dict(row) for row in cur.fetchall()]

    @_retry_on_locked
    def get_outlinks(
        self, path: str, *, limit: int | None = None
    ) -> list[dict[str, Any]]:
        """Return all links FROM the given document.

        Uses a LEFT JOIN to check target existence in a single query,
        avoiding N+1 round-trips. Existence is checked against
        ``documents_live``, so a link to a tombstoned (skipped) file reports
        ``exists = False`` — consistent with :meth:`get_broken_links`
        treating such links as broken (#1129).

        Args:
            path: Relative document path that is the link source
                (e.g. ``"notes/topic.md"``).
            limit: If provided, return at most this many results.

        Returns:
            List of dicts with keys ``target_path``, ``link_text``,
            ``link_type``, ``fragment``, ``raw_target``, ``exists`` (bool).
        """
        limit_clause = "" if limit is None else "LIMIT ?"
        params: tuple[str | int, ...] = (path,) if limit is None else (path, limit)
        cur = self._conn().execute(
            f"""
            SELECT l.target_path,
                   l.link_text,
                   l.link_type,
                   l.fragment,
                   l.raw_target,
                   (t.id IS NOT NULL) AS target_exists
            FROM links l
            JOIN documents d ON d.id = l.source_id
            LEFT JOIN documents_live t ON t.path = l.target_path
            WHERE d.path = ?
            ORDER BY l.rowid
            {limit_clause}
            """,
            params,
        )
        return [dict(row) for row in cur.fetchall()]

    @_retry_on_locked
    def resolve_vault_wikilinks(self) -> int:
        """Resolve vault-wide wikilink ``target_path`` values against the document set.

        Obsidian resolves a bare wikilink (``[[Note]]``) by searching the
        whole vault for a document whose name matches, and a path-qualified
        one (``[[folder/Note]]``) against any document whose path ends with
        ``folder/Note.md``. When several match, the tie-break is the one
        observed on Obsidian 1.13.7 (#1350; ``docs/design/reference/
        obsidian-markdown.md``, "The tie-break"): an exact vault path wins;
        otherwise a match in the source note's own folder; otherwise the
        shortest path string.

        Resolution anchors on ``raw_target`` (the original wikilink text as
        written) rather than the current ``target_path``.  This ensures
        re-resolution works correctly after a target document is moved or
        renamed — the original stem is always available regardless of how many
        times the index has been rebuilt.

        When no path match is found, the method also checks the
        ``document_aliases`` table — if a document declares an ``aliases``
        frontmatter field containing the wikilink stem, the link resolves to
        that document.  This mirrors Obsidian's alias resolution behaviour
        (e.g. ``[[AI]]`` resolves to a document with ``aliases: [AI]``); the
        tie-break among several is the path rule's, by analogy — Obsidian's
        own alias tie-break was not observed.

        Wikilinks with an explicit relative prefix (``./`` or ``../``) are
        skipped; they are resolved relative to the source document at scan time
        and do not participate in vault-wide resolution.

        Call this method after all documents have been indexed
        (``IndexFacet.build_index()`` and ``IndexFacet.reindex()`` do this
        automatically).  Callers that add documents via :meth:`upsert_note`
        directly are responsible for calling this method once all upserts are
        complete.

        Uses ``substr``/``length`` comparisons instead of ``LIKE`` to avoid
        wildcard-escaping issues with filenames that contain ``%`` or ``_``.

        Returns:
            Number of link rows whose ``target_path`` was updated.
        """
        conn = self._conn()
        # Load all document paths once into a Python set/list for in-memory
        # matching — avoids O(N) SQL round-trips (one SELECT per wikilink row).
        doc_paths: list[str] = [
            r["path"]
            for r in conn.execute("SELECT path FROM documents_live").fetchall()
        ]
        doc_paths_set = set(doc_paths)

        # Build alias → document path mapping for fallback resolution.
        # Case-insensitive: Obsidian alias matching is case-insensitive.
        alias_rows = conn.execute(
            """
            SELECT da.alias, d.path
            FROM document_aliases da
            JOIN documents d ON d.id = da.document_id
            """
        ).fetchall()
        # Map lowercased alias to list of document paths (multiple docs could
        # share an alias; the path rule's tie-break applies).
        alias_map: dict[str, list[str]] = {}
        for ar in alias_rows:
            alias_map.setdefault(ar["alias"].lower(), []).append(ar["path"])

        # Fetch all wikilinks eligible for vault-wide resolution.
        # Explicit relative prefixes (./  ../) are excluded — those were
        # resolved at scan time and must not be overwritten.
        rows = conn.execute(
            """
            SELECT l.id, l.raw_target, l.target_path, d.path AS source_path
            FROM links l
            JOIN documents d ON d.id = l.source_id
            WHERE l.link_type = 'wikilink'
              AND l.raw_target NOT LIKE './%'
              AND l.raw_target NOT LIKE '../%'
            """
        ).fetchall()

        # Resolve each wikilink in Python, then batch-UPDATE.
        updates: list[tuple[str, int]] = []
        for row in rows:
            # Derive the search filename from raw_target:
            # 1. Strip any trailing fragment (#heading).
            stem = row["raw_target"]
            if "#" in stem:
                stem = stem[: stem.index("#")]
            if not stem:
                continue
            # 2. Append .md if not already present.
            search_target = stem if stem.lower().endswith(".md") else stem + ".md"

            # An exact vault path wins outright (rule 1); the suffix matches
            # and the alias fallback go through the tie-break (rules 2, 3).
            if search_target in doc_paths_set:
                new_path = search_target
            else:
                candidates = [p for p in doc_paths if p.endswith("/" + search_target)]
                if not candidates:
                    # Fallback: check if the stem matches a document alias.
                    # Use the raw stem (without .md) for alias matching.
                    candidates = alias_map.get(stem.lower(), [])
                if not candidates:
                    continue  # Genuinely broken — no document matches.
                new_path = _pick_wikilink_candidate(candidates, row["source_path"])
            if new_path != row["target_path"]:
                updates.append((new_path, row["id"]))

        with conn:
            conn.executemany("UPDATE links SET target_path = ? WHERE id = ?", updates)
        updated = len(updates)

        if updated:
            logger.debug("resolve_vault_wikilinks_completed resolved_count=%d", updated)
        return updated

    @_retry_on_locked
    def get_broken_links(self, *, folder: str | None = None) -> list[dict[str, Any]]:
        """Return all links whose target does not exist as an indexed document.

        Args:
            folder: If provided, restrict to source documents in this folder
                (exact match or sub-folder prefix).

        Returns:
            List of dicts with keys ``source_path``, ``source_title``,
            ``target_path``, ``link_text``, ``link_type``, ``fragment``,
            ``raw_target``.
        """
        folder_clause = ""
        params: list[str] = []
        if folder is not None:
            escaped = _escape_like(folder)
            folder_clause = "AND (d.folder = ? OR d.folder LIKE ? ESCAPE '\\')"
            params = [folder, escaped + "/%"]

        sql = f"""
            SELECT d.path AS source_path,
                   d.title AS source_title,
                   l.target_path,
                   l.link_text,
                   l.link_type,
                   l.fragment,
                   l.raw_target
            FROM links l
            JOIN documents d ON d.id = l.source_id
            WHERE NOT EXISTS (
                SELECT 1 FROM documents_live d2 WHERE d2.path = l.target_path
            )
              {folder_clause}
            ORDER BY d.path, l.rowid
        """
        cur = self._conn().execute(sql, params)
        return [dict(row) for row in cur.fetchall()]

    @_retry_on_locked
    def get_recent(
        self, *, limit: int = 20, folder: str | None = None
    ) -> list[dict[str, Any]]:
        """Return the most recently modified documents.

        Args:
            limit: Maximum number of documents to return.
            folder: If provided, restrict to documents in this folder
                (exact match or sub-folder prefix).

        Returns:
            List of dicts with the same shape as :meth:`get_note`, ordered
            by ``modified_at`` descending (most recent first).
        """
        if folder is not None:
            escaped = _escape_like(folder)
            cur = self._conn().execute(
                """
                SELECT path, title, folder, frontmatter_json,
                       modified_at, content_chars
                FROM documents_live
                WHERE folder = ? OR folder LIKE ? ESCAPE '\\'
                ORDER BY modified_at DESC
                LIMIT ?
                """,
                (folder, escaped + "/%", limit),
            )
        else:
            cur = self._conn().execute(
                """
                SELECT path, title, folder, frontmatter_json,
                       modified_at, content_chars
                FROM documents_live
                ORDER BY modified_at DESC
                LIMIT ?
                """,
                (limit,),
            )
        return [dict(row) for row in cur.fetchall()]

    @_retry_on_locked
    def get_orphan_notes(self) -> list[dict[str, Any]]:
        """Return all documents with no inbound or outbound links.

        A document is an orphan if it has zero rows in ``links`` as either
        source (no outlinks) AND does not appear as a target in any link row
        (no backlinks).

        Returns:
            List of dicts with keys ``path``, ``title``, ``folder``,
            ``frontmatter_json``, ``modified_at``, and ``content_chars``,
            ordered by path.
        """
        cur = self._conn().execute(
            """
            SELECT path, title, folder, frontmatter_json, modified_at, content_chars
            FROM documents_live d
            WHERE NOT EXISTS (SELECT 1 FROM links WHERE source_id = d.id)
              AND NOT EXISTS (SELECT 1 FROM links WHERE target_path = d.path)
            ORDER BY path
            """
        )
        return [dict(row) for row in cur.fetchall()]

    @_retry_on_locked
    def get_most_linked(self, limit: int = 10) -> list[dict[str, Any]]:
        """Return the documents with the most distinct source documents linking to them.

        Args:
            limit: Maximum number of results to return.

        Returns:
            List of dicts with keys ``path``, ``title``, ``folder``,
            ``backlink_count``, ordered by backlink_count descending.
        """
        cur = self._conn().execute(
            """
            SELECT d.path,
                   d.title,
                   d.folder,
                   COUNT(DISTINCT l.source_id) AS backlink_count
            FROM links l
            JOIN documents_live d ON d.path = l.target_path
            GROUP BY d.path, d.title, d.folder
            ORDER BY backlink_count DESC
            LIMIT ?
            """,
            (limit,),
        )
        return [dict(row) for row in cur.fetchall()]

    @_retry_on_locked
    def get_connection_path(
        self, source_path: str, target_path: str, max_depth: int = 10
    ) -> list[str] | None:
        """Return the shortest undirected path between two notes via BFS.

        Treats the link graph as undirected — a link in either direction
        counts as a connection.  Raises ``ValueError`` if either path is
        not in the documents table.

        Args:
            source_path: Vault-relative path of the starting note.
            target_path: Vault-relative path of the destination note.
            max_depth: Maximum path length (number of edges).  Clamped to
                ``[1, 10]``.  Defaults to ``10``.

        Returns:
            Ordered list of vault-relative paths from *source_path* to
            *target_path* (inclusive), or ``None`` if no path exists within
            *max_depth* hops.

        Raises:
            DocumentNotFoundError: If *source_path* or *target_path* is not
                found in the documents table.
        """
        max_depth = max(1, min(10, max_depth))

        # Validate both endpoints exist.
        for path in (source_path, target_path):
            row = (
                self._conn()
                .execute("SELECT 1 FROM documents_live WHERE path = ?", (path,))
                .fetchone()
            )
            if row is None:
                raise DocumentNotFoundError.note(path)

        # Trivial case.
        if source_path == target_path:
            return [source_path]

        # Load all edges into an undirected adjacency dict.
        adj: dict[str, set[str]] = {}
        cur = self._conn().execute(
            "SELECT d1.path, d2.path FROM links l"
            " JOIN documents_live d1 ON d1.id = l.source_id"
            " JOIN documents_live d2 ON d2.path = l.target_path"
        )
        for src, tgt in cur.fetchall():
            adj.setdefault(src, set()).add(tgt)
            adj.setdefault(tgt, set()).add(src)

        # BFS with depth tracking.
        queue: deque[tuple[str, list[str]]] = deque()
        queue.append((source_path, [source_path]))
        visited: set[str] = {source_path}

        while queue:
            current, current_path = queue.popleft()
            if len(current_path) - 1 >= max_depth:
                continue
            for neighbour in adj.get(current, set()):
                if neighbour in visited:
                    continue
                new_path = [*current_path, neighbour]
                if neighbour == target_path:
                    logger.debug(
                        "get_connection_path_found source_path=%s target_path=%s "
                        "hop_count=%d",
                        source_path,
                        target_path,
                        len(new_path) - 1,
                    )
                    return new_path
                visited.add(neighbour)
                queue.append((neighbour, new_path))

        logger.debug(
            "get_connection_path_not_found source_path=%r target_path=%r max_depth=%d",
            source_path,
            target_path,
            max_depth,
        )
        return None

    def _count_links_query(self, sql: str) -> int:
        """Execute a COUNT query, returning 0 if the links table does not exist.

        Args:
            sql: A SQL statement returning a single COUNT(*) row.

        Returns:
            The integer count, or 0 when the links table is absent (backward
            compatibility with index files predating link tracking).

        Raises:
            sqlite3.OperationalError: For any database error other than a
                missing links table.
        """
        try:
            row = self._conn().execute(sql).fetchone()
            return int(row[0])
        except sqlite3.OperationalError as e:
            if "no such table: links" in str(e).lower():
                return 0
            raise

    @_retry_on_locked
    def count_links(self) -> int:
        """Return the total number of link rows in the links table.

        Returns:
            Total link count, or 0 if the links table does not exist.
        """
        return self._count_links_query("SELECT COUNT(*) FROM links")

    @_retry_on_locked
    def count_broken_links(self) -> int:
        """Return the number of links whose target is not in the documents table.

        Returns:
            Broken link count, or 0 if the links table does not exist.
        """
        return self._count_links_query(
            """
            SELECT COUNT(*)
            FROM links
            WHERE NOT EXISTS (
                SELECT 1 FROM documents_live d WHERE d.path = links.target_path
            )
            """
        )

    @_retry_on_locked
    def count_orphans(self) -> int:
        """Return the number of documents with no inbound or outbound links.

        Returns:
            Orphan count, or 0 if the links table does not exist.
        """
        return self._count_links_query(
            """
            SELECT COUNT(*)
            FROM documents_live d
            WHERE NOT EXISTS (SELECT 1 FROM links WHERE source_id = d.id)
              AND NOT EXISTS (SELECT 1 FROM links WHERE target_path = d.path)
            """
        )

    @_retry_on_locked
    def get_chunk_count(self, path: str) -> int:
        """Return the chunk_count for a single document, defaulting to 1.

        Args:
            path: Relative document path.

        Returns:
            The ``chunk_count`` stored in the documents table, or ``1`` if
            the document is not found.
        """
        row = (
            self._conn()
            .execute("SELECT chunk_count FROM documents_live WHERE path = ?", (path,))
            .fetchone()
        )
        return int(row["chunk_count"]) if row else 1

    def get_chunk_counts(self, paths: Iterable[str]) -> dict[str, int]:
        """Return a ``{path: chunk_count}`` map for the given paths.

        Missing paths are omitted; callers should default to ``1``.

        Materialises *paths* into a list BEFORE the retry window opens.
        ``@_retry_on_locked`` cannot be used directly here because the
        decorator captures the original argument tuple — a one-shot
        generator would be exhausted by the first attempt before the
        inner ``list()`` call runs, causing the retry to silently return
        ``{}`` instead of the correct map. Mirrors :meth:`build_from_notes`.

        Args:
            paths: Iterable of relative document paths to look up.

        Returns:
            Dict mapping each found path to its ``chunk_count`` value.
        """
        paths_list = list(paths)

        def _do() -> dict[str, int]:
            return self._get_chunk_counts_inner(paths_list)

        return _retry_on_sqlite_locked(_do)

    def _get_chunk_counts_inner(self, paths: list[str]) -> dict[str, int]:
        """Inner body of :meth:`get_chunk_counts`, safe to re-invoke on retry."""
        if not paths:
            return {}
        placeholders = ",".join("?" * len(paths))
        rows = (
            self._conn()
            .execute(
                "SELECT path, chunk_count FROM documents_live "
                f"WHERE path IN ({placeholders})",
                paths,
            )
            .fetchall()
        )
        return {r["path"]: int(r["chunk_count"]) for r in rows}

    def close(self) -> None:
        """Close every per-thread connection and mark this index closed.

        Idempotent — delegates to :meth:`SqliteConnectionRegistry.close`.
        After ``close()``, any thread calling a public method raises
        ``sqlite3.ProgrammingError`` from ``_conn()``.
        """
        self._registry.close()
        logger.debug("fts_index_closed db_path=%s", self._db_path)
