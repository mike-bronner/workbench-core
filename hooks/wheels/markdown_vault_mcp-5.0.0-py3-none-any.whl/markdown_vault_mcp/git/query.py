"""Read-only git history and diff queries.

Pure functions -- lock-free, no mutation of repository state. Subprocess calls are
module-qualified (``subprocess.run``) so the test suite's global monkeypatch still
intercepts them.

The ``git_root`` parameter is pre-resolved by the caller (typically via
:meth:`GitWriteStrategy._ensure_git_root`, which memoises the result).  This
keeps git-root discovery out of these functions so that tests can prime the
cache on the strategy instance and then patch ``subprocess.run`` without the
patch also interfering with the discovery call.

Each public entry point states what a ``None`` ``git_root`` means for it, and
they deliberately differ: the history and diff queries return an empty result,
because "no git" and "nothing changed" are equally uninteresting to a caller
browsing history; :func:`get_file_at_ref` raises, because an empty string is
indistinguishable from a note that was empty at that revision and its caller is
about to write the result back; :func:`committed_revision` returns ``None``,
which is what it returns for every other unanswerable case.  Internal helpers
(:func:`resolve_path_at_ref` among them) require a resolved ``git_root``.
"""

from __future__ import annotations

import logging
import subprocess
from pathlib import Path
from typing import TYPE_CHECKING, NamedTuple

from markdown_vault_mcp.exceptions import DocumentUnreadableError, InvalidRequestError
from markdown_vault_mcp.git._run import cleanup_git_env, git_env, literal_pathspec
from markdown_vault_mcp.types import CommitDiff, HistoryEntry, RevisionContent
from markdown_vault_mcp.utils.fs import path_exists

if TYPE_CHECKING:
    from collections.abc import Iterator

    from markdown_vault_mcp.git.types import RevisionQuery

logger = logging.getLogger(__name__)

# Git's well-known empty-tree SHA: a real object in every repository.
# Used to diff a parent-less (root/orphan) commit against "nothing".
_EMPTY_TREE_SHA = "4b825dc642cb6eb9a060e54bf8d69288fbee4904"

# Diff payloads larger than this are truncated with a byte-count marker.
_DIFF_MAX_BYTES = 50 * 1024  # 50 KB

# Patch and ``--stat`` payloads name files in their own body.  Under git's
# default ``core.quotePath`` a non-ASCII name is rendered there octal-escaped
# inside double quotes, so the diff a caller reads back names a file they
# cannot then look up.  This is a rendering choice rather than the framing
# problem the log readers have (nothing parses these payloads — they are
# handed to the caller as text), so the config override is the right tool
# here where ``-z`` is the right tool there.
_READABLE_PATHS = ("-c", "core.quotePath=false")

# Rename-detection threshold for every query in this module that resolves a
# note across a rename — the single-note walks and the two-rev resolution
# alike.  One constant, because the disagreement is the bug: at git's 50%
# default a rename that also rewrote half the note reports as an unrelated add
# plus delete, so a walk pinned at 30% would serve a revision a walk left at
# the default never lists (#1297).  30% comes from #338: catch rename-with-edits
# without pairing unrelated notes from a shared template.  Passing it
# explicitly also overrides the operator's ``diff.renames`` (verified for
# true/false/copies), so rename detection is on regardless of their config —
# the same reason the limit below is pinned.  Copy detection is a different
# matter: ``--follow`` turns it on by itself, so ``C`` records reach the walks
# and are handled there.
_RENAME_THRESHOLD = "--find-renames=30"

# Rename-detection is capped per commit; a commit renaming more files than the
# cap degrades every rename to add+delete, which the walks then misread.
# Pinning the value keeps that boundary a property of this code rather than of
# whatever the operator has in their git config.
_RENAME_LIMIT = "diff.renameLimit=2000"

# \x1e (ASCII Record Separator) marks the start of each commit block in
# ``git log`` output.  Commit messages do not carry it, and while a POSIX
# filename legally may, git has no framing that would let a block boundary be
# found without a marker of some kind.
_HISTORY_SENTINEL = "\x1e"


def _split_z_block(block: str, field_count: int) -> tuple[list[str], list[str]] | None:
    """Split one ``git log -z`` commit block into header fields and paths.

    ``-z`` terminates the ``--format`` output with NUL instead of a newline,
    then — when a file list follows — emits a single ``\\n`` before the first
    path and terminates every path with NUL.  So a block reads
    ``field1\\0...fieldN\\0`` optionally followed by ``\\npath1\\0path2\\0``.
    Paths arrive as git recorded them rather than octal-escaped: ``-z``
    suppresses the double-quoted rendering ``core.quotePath`` produces for
    non-ASCII names, and unlike ``-c core.quotePath=false`` it also covers the
    names git quotes unconditionally (a double quote, tab, or newline in the
    path).  Carriage returns are the exception, and the text-mode pipe rather
    than git is what rewrites them: a lone ``\r`` is translated, and a
    ``\r\n`` pair collapses to a single byte (#1290).

    Exactly one trailing empty token is dropped — the one git's final NUL
    creates — rather than every trailing empty, because a commit with an empty
    subject contributes a legitimately empty field.  Likewise exactly one
    leading newline is removed from the first path token, since a filename may
    legally begin with one.

    Args:
        block: One commit block, sentinel already stripped.
        field_count: Number of ``--format`` fields the block's header carries.

    Returns:
        ``(header_fields, paths)``, or ``None`` when the block is empty or
        carries fewer than *field_count* header fields.
    """
    tokens = block.split("\0")
    if tokens and not tokens[-1]:
        tokens.pop()
    if len(tokens) < field_count:
        return None
    paths = tokens[field_count:]
    if paths and paths[0].startswith("\n"):
        paths[0] = paths[0][1:]
    return tokens[:field_count], paths


def _truncate_diff(diff: str) -> str:
    """Cap *diff* at :data:`_DIFF_MAX_BYTES`, appending an omission marker.

    Truncation is byte-based (UTF-8), decoding the kept prefix with
    ``errors="replace"`` so a multi-byte character split at the boundary
    cannot raise.
    """
    if len(diff.encode()) <= _DIFF_MAX_BYTES:
        return diff
    omitted = len(diff.encode()) - _DIFF_MAX_BYTES
    diff = diff.encode()[:_DIFF_MAX_BYTES].decode(errors="replace")
    return diff + f"\n[diff truncated: {omitted} bytes omitted]"


def _resolve_since_timestamp(
    git_root: Path, since_timestamp: str, env: dict[str, str] | None
) -> str | None:
    """Resolve *since_timestamp* to the most recent commit at or before it.

    Returns:
        The commit SHA, or ``None`` when no commit exists at or before the
        timestamp (inclusive boundary: a commit whose committer date equals
        the timestamp is returned).

    Raises:
        ValueError: If ``git rev-list`` exits non-zero.
    """
    try:
        rev_result = subprocess.run(
            [
                "git",
                "-C",
                str(git_root),
                "rev-list",
                f"--before={since_timestamp}",
                "-1",
                "HEAD",
                # No path filter: git rev-list has no --follow, so
                # filtering by current path silently misses pre-rename
                # commits.  Resolve the timestamp globally and let the
                # subsequent diff (which uses -- path_str) handle scope.
            ],
            capture_output=True,
            text=True,
            check=True,
            env=env,
        )
    except subprocess.CalledProcessError as exc:
        # git parses any date text without complaint and the caller checked
        # HEAD exists, so a failure here is the repository's, never the
        # timestamp's.
        raise ValueError(
            f"git rev-list failed while resolving timestamp {since_timestamp!r}: "
            f"{(exc.stderr or '').strip()}"
        ) from exc
    return rev_result.stdout.strip() or None


def _has_commits(git_root: Path, env: dict[str, str] | None) -> bool:
    """True once the repository has a commit; False while HEAD is unborn.

    A vault whose repository has no commit yet has an empty history, not a
    broken one (#1608). ``rev-parse --verify --quiet HEAD`` exits 1 both for
    an unborn HEAD and for an unreadable branch ref, so an exit 1 counts as
    unborn only when ``symbolic-ref -q HEAD`` still names a branch.

    Raises:
        ValueError: If HEAD cannot be read for any other reason.
    """

    def git(*args: str) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            ["git", "-C", str(git_root), *args],
            capture_output=True,
            text=True,
            check=False,
            env=env,
        )

    head = git("rev-parse", "--verify", "--quiet", "HEAD")
    if head.returncode == 0:
        return True
    if head.returncode == 1:
        branch = git("symbolic-ref", "-q", "HEAD")
        if branch.returncode == 0:
            return False
        head = branch
    raise ValueError(f"git could not read HEAD: {head.stderr.strip()}")


def _require_commit(git_root: Path, ref: str, env: dict[str, str] | None) -> str:
    """Resolve a caller's *ref* to the full id of the commit it names.

    ``rev-parse --verify --quiet <ref>^{commit}`` exits 1, silently, for an
    unknown ref, a prefix no commit uniquely matches, or one naming another
    kind of object. Any other exit is the repository's failure. A prefix a
    commit shares with a blob passes here but fails the bare ``git diff <ref>
    HEAD`` that rename resolution runs, so callers use the returned id.

    Returns:
        The full commit id.

    Raises:
        InvalidRequestError: If *ref* names no commit (#1608).
        ValueError: If ``git rev-parse`` fails for another reason.
    """
    result = subprocess.run(
        [
            "git",
            "-C",
            str(git_root),
            "rev-parse",
            "--verify",
            "--quiet",
            "--end-of-options",
            f"{ref}^{{commit}}",
        ],
        capture_output=True,
        text=True,
        check=False,
        env=env,
    )
    if result.returncode == 0:
        return result.stdout.strip()
    if result.returncode == 1:
        raise InvalidRequestError(
            f"{ref!r} is not a commit in this repository: unknown, not a "
            "unique commit prefix, or another kind of object. Pass a SHA "
            "from 'get_history'."
        )
    raise ValueError(f"git rev-parse failed for {ref!r}: {result.stderr.strip()}")


def _repo_rel(git_root: Path, path: Path) -> str | None:
    """Return *path* relative to *git_root* as a posix string, or ``None``.

    ``None`` means the path is outside the repository, which every caller
    reads as "git has nothing to say about this" rather than as an error.
    Git reports paths posix-relative to its root, so this is the form to
    compare its output against — the absolute, platform-native path would
    never match on Windows.
    """
    try:
        return path.resolve().relative_to(git_root).as_posix()
    except ValueError:
        return None


def _empty_tree(git_root: Path, env: dict[str, str] | None) -> str:
    """Return this repository's empty-tree object id.

    Resolved rather than hardcoded because the well-known constant is a SHA-1
    id and is not a valid object in a SHA-256 repository (#1286).  Falls back
    to the constant when resolution fails, which keeps a SHA-1 repository —
    every repository that predates the option — working unchanged.
    """
    try:
        result = subprocess.run(
            ["git", "-C", str(git_root), "hash-object", "-t", "tree", "--stdin"],
            input="",
            capture_output=True,
            text=True,
            env=env,
            check=True,
        )
    except subprocess.CalledProcessError:
        return _EMPTY_TREE_SHA
    return result.stdout.strip() or _EMPTY_TREE_SHA


class _Lineage(NamedTuple):
    """What git's own records say about the note now living at a path.

    Attributes:
        shas: The commits belonging to that note, or ``None`` when the walk
            could not be run at all (a path outside the repository, or a git
            invocation that failed).  ``None`` means "unknown", and every
            caller treats it by leaving its existing behaviour alone rather
            than filtering on a set it does not trust.
        birth_found: ``True`` when the walk reached the commit that created
            the note — so anything older belongs to whatever held the name
            before, not to this note.
    """

    shas: set[str] | None
    birth_found: bool


def _track_records(path_tokens: list[str], tracked: str) -> tuple[str, bool]:
    """Advance one commit's ``--name-status`` records in a newest-first walk.

    *tracked* is the path the note carries at the commit being examined.
    Records that do not name it are ignored: a windowed or range-bounded walk
    can hide the rename that would have retargeted the walk, and dropping the
    note's own commits on that evidence is worse than following a name one
    commit too far.

    Returns:
        ``(tracked_for_older_commits, reached_birth)``.  An ``R`` record whose
        destination is the tracked path retargets the walk to its source; an
        ``A`` (or a ``C``, which ``--follow`` enables copy detection for) on
        the tracked path is the note's birth; ``D`` / ``M`` / ``T`` leave the
        identity intact.
    """
    i = 0
    while i < len(path_tokens):
        status = path_tokens[i]
        if not status:
            i += 1
            continue
        wanted = 2 if status[0] in ("R", "C") else 1
        paths = path_tokens[i + 1 : i + 1 + wanted]
        if len(paths) < wanted:
            break
        if paths[-1] == tracked:
            if status[0] == "R":
                return paths[0], False
            if status[0] in ("A", "C"):
                return tracked, True
        i += 1 + wanted
    return tracked, False


def _lineage(
    git_root: Path,
    path: Path,
    cur_rel: str,
    env: dict[str, str] | None,
    *,
    rev_range: str | None = None,
) -> _Lineage:
    """Return the commits that belong to the note now at *cur_rel* (#1285).

    ``git log --follow`` does not stop at the commit that created the file it
    follows: where a name was freed by a rename or a delete and later reused,
    it walks past that boundary and into the previous occupant's history.  So
    the boundary is established here, from git's own ``--name-status`` records,
    by walking newest-first and stopping at the record that creates the note.

    The walk is deliberately its own invocation rather than a reading of the
    caller's stream: ``--since`` / ``--until`` and a ``-n`` cap trim what the
    caller's ``git log`` returns, and a window that excludes the note's
    creation would leave no birth record to stop at.

    Args:
        git_root: Pre-resolved git repository root.
        path: Absolute path of the note, used as the pathspec so the walk
            matches exactly what the caller's own query matched.
        cur_rel: That path repo-relative and posix — the form git's records
            use, and where the walk starts tracking.
        env: Git environment from :func:`git_env`.
        rev_range: Restrict the walk to a range (``"<ref>..HEAD"``).  ``None``
            walks back from ``HEAD`` without a bound, which is what a caller
            filtering a date-windowed query needs.

    Returns:
        A :class:`_Lineage`.  A failed git invocation yields
        ``_Lineage(None, False)`` — unknown, not empty — so a caller falls
        back to its previous behaviour instead of discarding every commit.
    """
    cmd = [
        "git",
        "-c",
        _RENAME_LIMIT,
        "-C",
        str(git_root),
        "log",
        "-z",
        "--follow",
        "--name-status",
        _RENAME_THRESHOLD,
        f"--format={_HISTORY_SENTINEL}%H",
    ]
    if rev_range is not None:
        cmd.append(rev_range)
    cmd += ["--", literal_pathspec(str(path))]
    result = subprocess.run(cmd, capture_output=True, text=True, check=False, env=env)
    if result.returncode != 0:
        return _Lineage(None, False)
    shas: set[str] = set()
    tracked = cur_rel
    for block in result.stdout.split(_HISTORY_SENTINEL):
        split = _split_z_block(block, 1)
        if split is None:
            continue
        (sha,), path_tokens = split
        shas.add(sha)
        tracked, reached_birth = _track_records(path_tokens, tracked)
        if reached_birth:
            return _Lineage(shas, True)
    return _Lineage(shas, False)


def _first_parent_records_cmd(
    git_root: Path, cur_rel: str, revs: str | None
) -> list[str]:
    """Assemble the argv for the walk that resolves a note's names.

    ``-m --first-parent`` is load-bearing, not decoration: a rename performed
    *while resolving a merge* appears in no parent's diff, so a plain walk
    returns no records for it at all — the reader is left believing the merge
    created the note, and never reaches the name it had before (#1306).
    Restricting to the first parent and asking for its diff surfaces that
    rename as an ordinary ``R`` record.

    ``-z`` frames paths by NUL, so a path containing a space, a quote or a
    newline survives intact and no ``core.quotePath`` unescaping is needed.

    Args:
        git_root: Pre-resolved git repository root.
        cur_rel: The note's path, repo-relative and posix.
        revs: What to walk: a range (``"<ref>..HEAD"``) or a single revision
            to walk back from, or ``None`` for ``HEAD`` without a bound.
    """
    cmd = [
        "git",
        "-c",
        _RENAME_LIMIT,
        "-C",
        str(git_root),
        "log",
        "-m",
        "--first-parent",
        "--follow",
        "--name-status",
        "-z",
        _RENAME_THRESHOLD,
        f"--format={_HISTORY_SENTINEL}%H",
    ]
    if revs is not None:
        cmd.append(revs)
    return [*cmd, "--", literal_pathspec(cur_rel)]


class _NameSegment(NamedTuple):
    """One stretch of a note's life under a single name (#1306).

    Attributes:
        name: The name the note carried, repo-relative and posix — the form
            git's own records use.
        acquired_at: The commit that gave the note this name: the rename, or
            the note's creation.  It belongs to this segment whatever else
            lists it, because a diff of that commit has to be taken under the
            name it *gave* the note for git to pair the rename rather than
            report the old name being deleted.
        after: That commit's first parent, excluded from the segment and with
            it everything older, so the name's previous owner stays out.
            ``None`` when the note was created by a parent-less commit, where
            there is nothing older to exclude.
        through: The newest commit at which this name was the note's own.
            ``None`` for the name the note carries now, whose segment runs to
            ``HEAD``.
    """

    name: str
    acquired_at: str | None
    after: str | None
    through: str | None


class _Frontier(NamedTuple):
    """A revision and the note's name there, whose history is still unwalked.

    Attributes:
        rev: The revision to walk back from.
        name: The name the note carries at *rev*.
        through: The newest commit at which that name was the note's own.
    """

    rev: str
    name: str
    through: str | None


# A note renamed on many merged branches would otherwise walk one chain per
# rename-carrying merge.  Past this many walks the recovery stops early: it
# reports fewer of the note's names, never names that are not the note's.
_MAX_NAME_WALKS = 16


def _parents(git_root: Path, sha: str, env: dict[str, str] | None) -> list[str]:
    """Return *sha*'s parents, first parent first; empty for a root commit."""
    result = subprocess.run(
        ["git", "-C", str(git_root), "rev-list", "--parents", "-n1", sha],
        capture_output=True,
        text=True,
        check=False,
        env=env,
    )
    if result.returncode != 0:
        return []
    return result.stdout.split()[1:]


def _first_parent(git_root: Path, sha: str, env: dict[str, str] | None) -> str | None:
    """Return *sha*'s first parent, or ``None`` for a parent-less commit."""
    parents = _parents(git_root, sha, env)
    return parents[0] if parents else None


def _branch_frontiers(
    git_root: Path,
    sha: str,
    name: str,
    older: str,
    env: dict[str, str] | None,
) -> list[_Frontier]:
    """Return the names *sha*'s merged branches knew the note by.

    A first-parent walk reads a rename carried by a merge as one step, from
    the name on the trunk straight to the name the merge settled on.  Where
    the note was *also* renamed on the branch, the name it carried there is in
    no first-parent diff at all, and the branch's own commits — made under
    that name — would go unreported.  So each other parent is asked what the
    note was called at it, and a name that is neither of the two the merge
    already named opens a walk of its own.
    """
    frontiers: list[_Frontier] = []
    for parent in _parents(git_root, sha, env)[1:]:
        at_parent = resolve_path_at_ref(git_root, parent, name, env, to_ref=sha)
        if at_parent is not None and at_parent not in (name, older):
            frontiers.append(_Frontier(parent, at_parent, parent))
    return frontiers


def _walk_one_name(
    git_root: Path, frontier: _Frontier, env: dict[str, str] | None
) -> tuple[list[_NameSegment], list[_Frontier]]:
    """Walk one line of descent, newest first, for the note at *frontier*.

    Returns:
        The segments this line contributes and the frontiers it opened.  A
        line that never reaches the note's creation contributes **nothing**:
        its oldest name has no lower bound, and a name recovered without one
        can pick up whatever held it before this note existed.
    """
    result = subprocess.run(
        _first_parent_records_cmd(git_root, frontier.name, frontier.rev),
        capture_output=True,
        text=True,
        check=False,
        env=env,
    )
    if result.returncode != 0:
        return [], []
    tracked, through = frontier.name, frontier.through
    segments: list[_NameSegment] = []
    opened: list[_Frontier] = []
    for block in result.stdout.split(_HISTORY_SENTINEL):
        split = _split_z_block(block, 1)
        if split is None:
            continue
        (sha,), path_tokens = split
        older, reached_birth = _track_records(path_tokens, tracked)
        if reached_birth:
            segments.append(
                _NameSegment(tracked, sha, _first_parent(git_root, sha, env), through)
            )
            return segments, opened
        if older != tracked:
            opened += _branch_frontiers(git_root, sha, tracked, older, env)
            segments.append(
                _NameSegment(tracked, sha, _first_parent(git_root, sha, env), through)
            )
            tracked, through = older, sha
    return [], []


def _name_segments(
    git_root: Path, cur_rel: str, env: dict[str, str] | None
) -> list[_NameSegment]:
    """Return the names the note at *cur_rel* carried, newest name first (#1306).

    A note's identity is resolved here the way :func:`get_file_at_ref` resolves
    it — by walking ``-m --first-parent``, which is the only walk that sees a
    rename performed *while resolving a merge*: that rename belongs to no
    parent's diff, so ``git log --follow`` reports the note as having been
    created by the merge and never reaches the name it had before.  Where such
    a merge joined a branch that had renamed the note too, that branch is
    walked in turn (:func:`_branch_frontiers`), because the name it used is in
    no first-parent diff either.

    The result is what a caller enumerates commits with, in place of asking
    ``--follow`` to do both jobs at once.  Each segment carries the revision
    bounds that make its name unambiguous, so a name used by another note
    before this one was created or after it was renamed away stays out — the
    boundary :func:`_lineage` establishes for the ``--follow`` walk.

    Returns:
        The segments, or an empty list when there is nothing to add: a note
        that never changed name (the ``--follow`` walk already covers it), or
        a walk that did not reach the note's birth and so cannot say where the
        oldest name stops belonging to it.
    """
    segments, pending = _walk_one_name(git_root, _Frontier("HEAD", cur_rel, None), env)
    if not segments:
        return []
    walked = {("HEAD", cur_rel)}
    while pending and len(walked) < _MAX_NAME_WALKS:
        frontier = pending.pop()
        if (frontier.rev, frontier.name) in walked:
            continue
        walked.add((frontier.rev, frontier.name))
        found, opened = _walk_one_name(git_root, frontier, env)
        segments += found
        pending += opened
    return segments if len(segments) > 1 else []


def _segment_rev_args(seg: _NameSegment, exclude: str | None) -> list[str]:
    """Return the revision arguments selecting the commits in *seg*.

    Args:
        seg: The segment to bound the walk to.
        exclude: A further commit whose ancestors are out of scope (the
            caller's own ``ref`` in a ``ref..HEAD`` query), or ``None``.
    """
    excluded = [rev for rev in (seg.after, exclude) if rev is not None]
    args = [seg.through or "HEAD"]
    if excluded:
        args += ["--not", *excluded]
    return args


def _rename_aware_diff_args(
    git_root: Path,
    from_ref: str,
    to_ref: str,
    cur_rel: str | None,
    pathspec: str,
    env: dict[str, str] | None,
) -> tuple[list[str], str | None]:
    """Build diff args for ``from_ref..to_ref``, resolving renames.

    Resolves the path *cur_rel* had at *from_ref*; when it differs from the
    current name, the diff targets the two blob specs so git pairs the
    rename instead of reporting delete+add.

    Returns:
        Tuple ``(diff_args, old_path)`` where *diff_args* is the ref/path
        portion of the ``git diff`` invocation and *old_path* is the
        resolved historical path (``None`` when no rename was resolved).
    """
    old_path = (
        resolve_path_at_ref(git_root, from_ref, cur_rel, env, to_ref=to_ref)
        if cur_rel is not None
        else None
    )
    if old_path is None or cur_rel is None or old_path == cur_rel:
        return [f"{from_ref}..{to_ref}", "--", literal_pathspec(pathspec)], old_path
    return [f"{from_ref}:{old_path}", f"{to_ref}:{cur_rel}"], old_path


def _diff_is_binary(
    git_root: Path, diff_args: list[str], env: dict[str, str] | None
) -> bool:
    """True if git reports the diff target as binary.

    *diff_args* is the ref/path portion of a ``git diff`` invocation — such as
    a range/path form (``["<from>..<to>", "--", <pathspec>]``), a two-endpoint
    blob/tree-spec form (``[f"{a}:{old}", f"{b}:{new}"]``), or two revs followed
    by a pathspec (e.g. the empty-tree SHA and a commit SHA followed by
    ``["--", <pathspec>]``, used for parent-less commits).  The endpoints may
    be refs, commit SHAs, blob specs, or the empty-tree constant; every
    pathspec among them is built by
    :func:`~markdown_vault_mcp.git._run.literal_pathspec`.
    ``git diff --numstat`` prints ``-\\t-\\t<path>`` for binary and real counts
    for text; empty output (no change) → non-binary.
    A non-zero git exit (e.g. a bad ref) yields empty stdout, so it is classified
    non-binary; the error is then surfaced by the subsequent checked ``git diff``
    call. This is a detection probe, not the final word.
    """
    result = subprocess.run(
        ["git", "-C", str(git_root), "diff", "--numstat", *diff_args],
        capture_output=True,
        text=True,
        check=False,
        env=env,
    )
    first = result.stdout.strip().split("\n", 1)[0]
    return first.startswith("-\t-")


def _vault_prefix(git_root: Path, repo_path: Path) -> str:
    """Return the prefix to strip from ``--name-only`` output paths.

    When the git root is a parent of *repo_path*, git reports paths relative
    to the git root (e.g. ``"vault/note.md"``); the returned prefix (e.g.
    ``"vault/"``) is stripped so callers always receive vault-relative paths.
    *repo_path* is resolved to handle symlinks: ``git rev-parse
    --show-toplevel`` always returns the real (resolved) path, so it must be
    matched.

    Returns:
        The vault prefix ending in ``"/"``, or ``""`` when the git root is
        the vault root itself (or *repo_path* is not under *git_root*).
    """
    try:
        vault_rel = repo_path.resolve().relative_to(git_root)
    except ValueError:
        return ""
    return "" if vault_rel == Path() else vault_rel.as_posix() + "/"


def _history_log_cmd(
    git_root: Path,
    repo_path: Path,
    path: Path | None,
    since: str | None,
    until: str | None,
    limit: int,
    *,
    is_dir: bool,
) -> list[str]:
    """Assemble the ``git log`` argv for a history query.

    Args:
        git_root: Pre-resolved git repository root.
        repo_path: Absolute path of the vault root (the vault-wide pathspec).
        path: Absolute path of the file (or directory, when *is_dir*) to
            filter on, or ``None`` for the entire vault.
        since: ``--since`` filter, or ``None`` to disable it.
        until: ``--until`` filter, or ``None`` to disable it.
        limit: Maximum number of commits (already clamped by the caller).
        is_dir: When ``True``, *path* is a directory subtree.

    Returns:
        The full ``git log`` argv, formatted with :data:`_HISTORY_SENTINEL`
        block markers and NUL-separated header fields.  ``-z`` frames the
        ``--name-only`` paths by NUL as well, so a non-ASCII name reaches
        the caller as git recorded it rather than octal-escaped inside
        double quotes (see :func:`_split_z_block`).  A single-file query
        carries :data:`_RENAME_THRESHOLD` and :data:`_RENAME_LIMIT`, so it
        crosses the same renames the revision readers do (#1297); the
        vault-wide and directory argv are unchanged by them, since rename
        detection would alter their ``--name-only`` output.
    """
    single_file = path is not None and not is_dir
    cmd = ["git"]
    if single_file:
        # Rename detection is only in play for the ``--follow`` branch below;
        # leaving the vault-wide and directory argv untouched keeps their
        # ``--name-only`` output exactly as it was.
        cmd += ["-c", _RENAME_LIMIT]
    cmd += [
        "-C",
        str(git_root),
        "log",
        "-z",
        f"--format={_HISTORY_SENTINEL}%H%x00%h%x00%aI%x00%aN <%aE>%x00%s",
        f"-n{limit}",
    ]
    if since:
        cmd.append(f"--since={since}")
    if until:
        cmd.append(f"--until={until}")
    if path is None:
        # vault-wide: scope to the resolved real path so symlinked SOURCE_DIR
        # values work correctly (git compares against the real toplevel).
        cmd += ["--name-only", "--", literal_pathspec(str(repo_path.resolve()))]
    elif is_dir:
        # directory scope: no --follow (git rejects it for anything but a
        # single file); --name-only so paths_changed carries the subtree files
        # each commit touched. git already filters the name-only output to the
        # <dir> pathspec, so no sibling paths leak in and no extra filtering is
        # needed here.
        cmd += ["--name-only", "--", literal_pathspec(str(path))]
    else:
        # Same threshold as every other rename-crossing query here: without it
        # this walk stopped at a rename git scored under its 50% default, and
        # listed no commit for a revision ``read`` would happily serve (#1297).
        cmd += ["--follow", _RENAME_THRESHOLD, "--", literal_pathspec(str(path))]
    return cmd


def _history_log_output(cmd: list[str], env: dict[str, str] | None) -> str:
    """Run the assembled ``git log`` command and return its raw stdout.

    Raises:
        ValueError: If ``git log`` exits non-zero. That is the repository's
            failure: git accepts any ``--since`` / ``--until`` text without
            complaint, so a bad date never gets here.
    """
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            check=True,
            env=env,
        )
    except subprocess.CalledProcessError as exc:
        raise ValueError(f"git log failed: {(exc.stderr or '').strip()}") from exc
    return result.stdout


class _WalkBounds(NamedTuple):
    """The caller's bounds, applied to every segment walk.

    Attributes:
        since: ``--since`` filter, or ``None``.
        until: ``--until`` filter, or ``None``.
        limit: Maximum number of commits per walk, or ``None`` for no cap.
        exclude: A commit whose ancestors are out of scope — the caller's own
            ``ref`` in a ``ref..HEAD`` query — or ``None``.
    """

    since: str | None = None
    until: str | None = None
    limit: int | None = None
    exclude: str | None = None


def _segment_shas(
    git_root: Path,
    segments: list[_NameSegment],
    bounds: _WalkBounds,
    env: dict[str, str] | None,
) -> dict[str, str]:
    """Map the note's commits under its earlier names to the name each touched.

    One walk per segment, each bounded to the revisions where that name was
    the note's own (see :class:`_NameSegment`) and carrying the caller's own
    bounds.  No ``--follow``: the names come from :func:`_name_segments`
    already, and leaving rename detection out of the enumeration is what lets
    git apply its ordinary merge simplification — so a merge is reported only
    where it changed the note relative to what it merged.

    Segments overlap at the commit that renamed the note, which touches both
    names, and there a segment's claim on the name it was *given* settles it:
    that is the name a diff of that commit has to target for git to pair the
    rename rather than report the old name being deleted.  Claims are applied
    after every walk, so the answer does not depend on the order the names
    were discovered in.

    A failed walk contributes nothing rather than raising: this supplements a
    result the caller already has.
    """
    found: dict[str, str] = {}
    claims: dict[str, str] = {}
    for seg in segments:
        cmd = ["git", "-C", str(git_root), "log", "--format=%H"]
        if bounds.limit is not None:
            cmd.append(f"-n{bounds.limit}")
        if bounds.since:
            cmd.append(f"--since={bounds.since}")
        if bounds.until:
            cmd.append(f"--until={bounds.until}")
        cmd += _segment_rev_args(seg, bounds.exclude)
        cmd += ["--", literal_pathspec(seg.name)]
        result = subprocess.run(
            cmd, capture_output=True, text=True, check=False, env=env
        )
        if result.returncode != 0:
            continue
        for sha in result.stdout.split():
            found.setdefault(sha, seg.name)
        if seg.acquired_at is not None:
            claims[seg.acquired_at] = seg.name
    for sha, name in claims.items():
        if sha in found:
            found[sha] = name
    return found


def _history_entries_for(
    git_root: Path,
    shas: set[str],
    vault_prefix: str,
    env: dict[str, str] | None,
) -> list[HistoryEntry]:
    """Return history entries for *shas*, newest first, in git's own ordering.

    ``--no-walk`` formats exactly the commits named and orders them by date,
    which is what puts commits gathered from several walks into one sequence
    without this module having to compare timestamps across time zones.
    """
    result = subprocess.run(
        [
            "git",
            "-C",
            str(git_root),
            "log",
            "--no-walk",
            "-z",
            f"--format={_HISTORY_SENTINEL}%H%x00%h%x00%aI%x00%aN <%aE>%x00%s",
            *sorted(shas),
            "--",
        ],
        capture_output=True,
        text=True,
        check=False,
        env=env,
    )
    if result.returncode != 0:
        return []
    entries: list[HistoryEntry] = []
    for block in result.stdout.split(_HISTORY_SENTINEL):
        entry = _parse_history_block(block, vault_prefix, collect_paths=False)
        if entry is not None:
            entries.append(entry)
    return entries


class _NameQuery(NamedTuple):
    """What a single-note history query needs to reach the note's old names.

    Attributes:
        cur_rel: The note's path, repo-relative and posix.
        vault_prefix: Prefix stripped from path tokens (see
            :func:`_vault_prefix`).
        bounds: The caller's own window, applied to every walk.
    """

    cur_rel: str
    vault_prefix: str
    bounds: _WalkBounds


def _with_earlier_names(
    git_root: Path,
    entries: list[HistoryEntry],
    query: _NameQuery,
    env: dict[str, str] | None,
) -> list[HistoryEntry]:
    """Add the note's commits under the names it carried before (#1306).

    ``git log --follow`` resolves a note's identity from a single parent's
    diff, so it stops at a rename that belongs to no parent's diff — the one a
    ``git mv`` while resolving a merge produces.  The names on the far side of
    such a rename are recovered here from the walk the revision reader trusts,
    and the commits under them added to what the caller already has.

    Purely additive: a note that never changed name yields no segments and
    *entries* is returned untouched, as is one whose segments turn up nothing
    the ``--follow`` walk had not already found — or one whose union git
    declines to describe, since a supplement that failed must not cost the
    caller the commits it already had.
    """
    segments = _name_segments(git_root, query.cur_rel, env)
    known = {entry.sha for entry in entries}
    extra = set(_segment_shas(git_root, segments, query.bounds, env)) - known
    if not extra:
        return entries
    ordered = _history_entries_for(git_root, known | extra, query.vault_prefix, env)
    if not ordered:
        return entries
    return ordered[: query.bounds.limit]


def _parse_history_entries(
    raw: str,
    vault_prefix: str,
    lineage: _Lineage,
    *,
    collect_paths: bool,
) -> list[HistoryEntry]:
    """Parse a history walk's ``-z`` stream into the note's own entries.

    Splits on the sentinel embedded at the start of each format line.  The
    first element will be empty (output starts with the sentinel); the parser
    rejects it along with any other empty or malformed block.  Commits outside
    *lineage* are dropped, so a reused name does not hand the caller its
    previous occupant's commits (#1285).
    """
    entries: list[HistoryEntry] = []
    for block in raw.split(_HISTORY_SENTINEL):
        entry = _parse_history_block(block, vault_prefix, collect_paths=collect_paths)
        if entry is None:
            continue
        if lineage.shas is not None and entry.sha not in lineage.shas:
            continue
        entries.append(entry)
    return entries


def _vault_relative_paths(tokens: list[str], vault_prefix: str) -> list[str]:
    """Normalise ``--name-only`` path tokens to vault-relative paths.

    Empty tokens are dropped; *vault_prefix* (when non-empty) is stripped from
    each remaining one so callers always receive vault-relative paths.  The
    tokens are otherwise passed through unaltered — they come from a ``-z``
    stream, where leading and trailing whitespace is part of the filename.
    """
    paths: list[str] = []
    for token in tokens:
        if not token:
            continue
        if vault_prefix and token.startswith(vault_prefix):
            token = token[len(vault_prefix) :]
        paths.append(token)
    return paths


def _parse_history_block(
    block: str, vault_prefix: str, *, collect_paths: bool
) -> HistoryEntry | None:
    """Parse one sentinel-delimited ``git log`` block into a history entry.

    Args:
        block: One commit block from the ``-z`` stream: five NUL-terminated
            header fields, then the block's paths (see
            :func:`_split_z_block`).
        vault_prefix: Prefix stripped from path tokens (see
            :func:`_vault_prefix`).
        collect_paths: When ``True`` (vault-wide or directory queries),
            populate ``paths_changed`` from the block's ``--name-only``
            paths; when ``False`` (single-file queries) leave it empty.

    Returns:
        The parsed :class:`HistoryEntry`, or ``None`` for an empty or
        malformed block.
    """
    split = _split_z_block(block, 5)
    if split is None:
        return None
    (sha, short_sha, timestamp, author, message), path_tokens = split
    paths_changed: list[str] = []
    if collect_paths:
        paths_changed = _vault_relative_paths(path_tokens, vault_prefix)
    return HistoryEntry(
        sha=sha,
        short_sha=short_sha,
        timestamp=timestamp,
        author=author,
        message=message,
        paths_changed=paths_changed,
    )


def get_file_history(
    git_root: Path | None,
    repo_path: Path,
    path: Path | None,
    since: str | None,
    limit: int,
    until: str | None = None,
    *,
    token: str | None,
    username: str,
    is_dir: bool = False,
) -> list[HistoryEntry]:
    """Return commits that touched *path* (or the whole vault).

    A repository with no commit yet has an empty history (#1608).

    Args:
        git_root: Pre-resolved git repository root, or ``None`` if the vault
            is not inside a git repository (returns ``[]`` immediately).
        repo_path: Absolute path of the vault root.  Used to compute the
            vault-relative prefix when the git root is a parent of the vault.
        path: Absolute path of the file (or directory, when *is_dir*) to
            filter on, or ``None`` for the entire vault.
        is_dir: When ``True``, *path* is a directory: history is scoped to its
            subtree (``git log -- <dir>``, without the single-file
            ``--follow``), and ``paths_changed`` is populated with the
            subtree files each commit touched. When ``False`` (a single file),
            ``--follow`` tracks renames, the result is filtered to the note's
            own lineage (see :func:`_lineage`, #1285) and supplemented with
            the commits under the names ``--follow`` cannot reach (see
            :func:`_with_earlier_names`, #1306), and ``paths_changed`` stays
            empty.
        since: Passed as ``--since`` to ``git log`` (ISO 8601 or git date
            expression such as ``"1 week ago"``).  ``None`` disables the
            filter.
        limit: Maximum number of commits to return (capped at 100).
        until: Passed as ``--until`` to ``git log`` (same format as
            *since*).  ``None`` disables the filter.  When both *since*
            and *until* are given the window is bounded on both sides,
            inclusive at both endpoints (git's ``--since`` / ``--until``
            semantics: a commit whose committer date equals either
            boundary is included).
        token: Personal access token for authenticated git operations, or
            ``None`` for unauthenticated access.
        username: Git username for authenticated operations.

    Returns:
        List of :class:`HistoryEntry` ordered from newest to oldest.

    Raises:
        ValueError: If ``git log`` exits non-zero; git accepts any ``since`` /
            ``until`` text without complaint, so a bad date never causes it.
    """
    if git_root is None:
        return []

    limit = min(max(1, limit), 100)
    cmd = _history_log_cmd(
        git_root, repo_path, path, since, until, limit, is_dir=is_dir
    )

    cur_rel = None if (path is None or is_dir) else _repo_rel(git_root, path)
    vault_prefix = _vault_prefix(git_root, repo_path)
    # paths_changed is populated for vault-wide and directory queries only;
    # single-file queries (--follow) leave it empty.
    collect_paths = path is None or is_dir
    env = git_env(token, username)
    try:
        if not _has_commits(git_root, env):
            return []
        raw = _history_log_output(cmd, env)
        # Single-file queries only: establish which commits belong to the note
        # now at this path, so a name that was reused does not hand the caller
        # its previous occupant's commits (#1285).
        lineage = (
            _Lineage(None, False)
            if cur_rel is None or path is None
            else _lineage(git_root, path, cur_rel, env)
        )
        entries = _parse_history_entries(
            raw, vault_prefix, lineage, collect_paths=collect_paths
        )
        if cur_rel is not None:
            entries = _with_earlier_names(
                git_root,
                entries,
                _NameQuery(cur_rel, vault_prefix, _WalkBounds(since, until, limit)),
                env,
            )
    finally:
        cleanup_git_env(env)
    return entries


def resolve_path_at_ref(
    git_root: Path,
    ref: str,
    cur_rel: str,
    env: dict[str, str] | None,
    *,
    to_ref: str = "HEAD",
) -> str | None:
    """Return the path *cur_rel* had at *ref* via rename detection, else None.

    Diffs ``ref..to_ref`` (``to_ref`` defaults to ``HEAD``).  Pass a specific
    commit as *to_ref* to resolve a rename a single commit introduced.
    """
    try:
        result = subprocess.run(
            [
                "git",
                "-C",
                str(git_root),
                "diff",
                "--name-status",
                _RENAME_THRESHOLD,
                # -z: NUL-terminated fields, tolerates tabs/newlines in paths.
                "-z",
                ref,
                to_ref,
            ],
            capture_output=True,
            text=True,
            check=True,
            env=env,
        )
    except subprocess.CalledProcessError:
        return None
    # Stream: <status>\0<path>\0 — R*/C* records add a second path
    # (\0<old>\0<new>\0).  Copies (C*) are skipped, not resolved (a copy is
    # an add, not a rename); the branch keeps the parser in sync if git ever
    # emits one.  This *particular* invocation — a plain ``git diff`` with
    # neither ``--find-copies`` nor ``--follow`` — does not produce C* records,
    # so the branch is defensive here.  It is not a claim about git in general:
    # the ``--follow`` walk behind :func:`get_file_at_ref` does see them, and
    # treats a copy as a birth rather than a lineage.
    items = result.stdout.split("\0")[:-1]
    i = 0
    while i < len(items):
        status = items[i]
        if status.startswith("R"):
            if i + 2 >= len(items):
                break
            if items[i + 2] == cur_rel:
                return items[i + 1]
            i += 3
        elif status.startswith("C"):
            if i + 2 >= len(items):
                break
            i += 3
        else:
            if i + 1 >= len(items):
                break
            i += 2
    return None


def get_file_diff(
    git_root: Path | None,
    path: Path,
    ref: str | None,
    per_commit: bool,
    since_timestamp: str | None = None,
    limit: int | None = None,
    *,
    token: str | None,
    username: str,
    summarize_binary: bool = False,
) -> str | list[CommitDiff]:
    """Return a unified diff of *path* from *ref* to HEAD.

    Exactly one of *ref* or *since_timestamp* must be supplied.  When
    *since_timestamp* is given, it is resolved via
    ``git rev-list --before=<ts> -1 HEAD`` to the most recent commit at
    or before that instant.  Boundary is **inclusive**: a commit whose
    committer date equals *since_timestamp* IS the resolved ref. In a
    repository with no commit yet, a *since_timestamp* diff is empty (#1608).

    Args:
        git_root: Pre-resolved git repository root, or ``None`` if the vault
            is not inside a git repository (returns ``""`` / ``[]``
            immediately).
        path: Absolute path of the file to diff.
        ref: The git ref (SHA or expression) to diff from.  Mutually
            exclusive with *since_timestamp*.
        per_commit: When ``False``, return a single unified diff string.
            When ``True``, return one :class:`CommitDiff` per intervening
            commit.
        since_timestamp: ISO 8601 datetime string resolved to a commit SHA
            via ``git rev-list --before``.  Mutually exclusive with *ref*.
        limit: When *per_commit* is ``True``, cap the number of commits
            walked to the *limit* most recent ones (clamped to
            ``[1, 100]``).  Ignored when *per_commit* is ``False``.
            ``None`` means unbounded (still capped by the underlying
            ``ref..HEAD`` range).
        token: Personal access token for authenticated git operations, or
            ``None`` for unauthenticated access.
        username: Git username for authenticated operations.
        summarize_binary: When ``True`` and git reports the file as a binary
            change over the range, return a ``git diff --stat`` summary
            instead of a (meaningless) binary patch.  Text files -- and every
            note, since the default is ``False`` -- fall through to the normal
            full unified diff (#342).

    Returns:
        A unified diff string when *per_commit* is ``False``, or a list of
        :class:`CommitDiff` when *per_commit* is ``True``.

    Raises:
        InvalidRequestError: If *ref* names no commit in this repository.
        ValueError: If a git subprocess exits non-zero for any other reason.
    """
    if git_root is None:
        return [] if per_commit else ""

    env = git_env(token, username)
    try:
        if since_timestamp is not None:
            if not _has_commits(git_root, env):
                return [] if per_commit else ""
            ref = _resolve_since_timestamp(git_root, since_timestamp, env)
            if ref is None:
                return [] if per_commit else ""

        if ref is None:
            raise ValueError("Either 'ref' or 'since_timestamp' must be provided")
        if since_timestamp is None:
            # A ref git resolved from the timestamp is known good; the caller's
            # is checked once here, so every later git failure is a fault.
            ref = _require_commit(git_root, ref, env)

        if not per_commit:
            return _range_diff(
                git_root, path, ref, env, summarize_binary=summarize_binary
            )
        return _per_commit_diffs(
            git_root, path, ref, limit, env, summarize_binary=summarize_binary
        )
    finally:
        cleanup_git_env(env)


def _range_diff(
    git_root: Path,
    path: Path,
    ref: str,
    env: dict[str, str] | None,
    *,
    summarize_binary: bool,
) -> str:
    """Return the single unified diff of *path* from *ref* to HEAD.

    Handles rename resolution, the binary ``--stat`` summary (#342), and
    truncation.  When the note now at *path* was created after *ref* — which
    is the interesting case only because the name may have been someone
    else's then (#1285) — the diff is taken against the empty tree, so it
    reads as the creation it is instead of pairing two notes' content.
    Raises :exc:`ValueError` if ``git diff`` fails. The caller's ref is
    already verified, and git does not fail on a path absent at either end,
    so that is the repository's failure.
    """
    path_str = str(path)
    # Both branches below settle the diff's endpoints once, so binary
    # detection, the --stat summary, and the full diff all read the same
    # target: the empty tree where the note was born inside the range, and
    # otherwise the rename-resolved pair.
    cur_rel = _repo_rel(git_root, path)
    if (
        cur_rel is not None
        and _lineage(git_root, path, cur_rel, env, rev_range=f"{ref}..HEAD").birth_found
    ):
        # The note now at this path was created within the range, so whatever
        # stood at that name at *ref* belongs to a different note.  Diff
        # against the empty tree instead: the note reads as the creation it
        # is, exactly as it would if the name had never been used before
        # (#1285).
        diff_args = [
            _empty_tree(git_root, env),
            "HEAD",
            "--",
            literal_pathspec(path_str),
        ]
    else:
        diff_args, _old_path = _rename_aware_diff_args(
            git_root, ref, "HEAD", cur_rel, path_str, env
        )

    # Binary attachments: a unified patch is meaningless, so emit a
    # --stat summary instead.  Text attachments (and notes, since the
    # default is summarize_binary=False) fall through to the full diff.
    if summarize_binary and _diff_is_binary(git_root, diff_args, env):
        try:
            stat = subprocess.run(
                [
                    "git",
                    *_READABLE_PATHS,
                    "-C",
                    str(git_root),
                    "diff",
                    "--stat",
                    *diff_args,
                ],
                capture_output=True,
                text=True,
                check=True,
                env=env,
            )
        except subprocess.CalledProcessError as exc:
            raise ValueError(
                f"Could not compute diff summary against {ref!r}: "
                f"{(exc.stderr or '').strip()}"
            ) from exc
        return stat.stdout

    diff_cmd = ["git", *_READABLE_PATHS, "-C", str(git_root), "diff", *diff_args]
    try:
        result = subprocess.run(
            diff_cmd,
            capture_output=True,
            text=True,
            check=True,
            env=env,
        )
    except subprocess.CalledProcessError as exc:
        raise ValueError(
            f"Could not compute diff against {ref!r}: {(exc.stderr or '').strip()}"
        ) from exc
    return _truncate_diff(result.stdout)


def _root_commit_diff(
    git_root: Path,
    sha: str,
    commit_path: str,
    env: dict[str, str] | None,
    *,
    summarize_binary: bool,
) -> str:
    """Render the add-form diff of a parent-less (root/orphan) commit.

    Classifies binariness against the empty tree (so a root binary still
    gets ``--stat``) and falls back to ``git show``.  Raises
    :exc:`ValueError` when even the fallback fails.
    """
    empty_tree = _empty_tree(git_root, env)
    root_binary = summarize_binary and _diff_is_binary(
        git_root, [empty_tree, sha, "--", literal_pathspec(commit_path)], env
    )
    fallback_cmd = [
        "git",
        *_READABLE_PATHS,
        "-C",
        str(git_root),
        "show",
        "--format=",
        "--stat" if root_binary else "-p",
        sha,
        "--",
        literal_pathspec(commit_path),
    ]
    try:
        show_result = subprocess.run(
            fallback_cmd,
            capture_output=True,
            text=True,
            check=True,
            env=env,
        )
    except subprocess.CalledProcessError as exc:
        raise ValueError(
            f"Could not retrieve diff for commit {sha!r}: {(exc.stderr or '').strip()}"
        ) from exc
    return show_result.stdout


def _parse_log_block(block: str, rel_fallback: str) -> tuple[str, ...] | None:
    """Parse one sentinel-delimited ``git log -z --name-only`` block.

    Returns:
        ``(sha, short_sha, timestamp, message, commit_path)``, or ``None``
        for an empty or malformed block.  *commit_path* is the path the
        file had at that commit (the old name for pre-rename commits,
        thanks to ``--follow``), falling back to *rel_fallback* when the
        block carries no path.  It is the name git recorded rather than
        git's quoted rendering of it, so it can be handed straight back as a
        pathspec (see :func:`_split_z_block`, and #1290 for the carriage
        returns still rewritten in transit).
    """
    split = _split_z_block(block, 4)
    if split is None:
        return None
    (sha, short_sha, timestamp, message), path_tokens = split
    commit_path = next((token for token in path_tokens if token), rel_fallback)
    return sha, short_sha, timestamp, message, commit_path


def _canonical_order(
    git_root: Path, shas: set[str], env: dict[str, str] | None
) -> list[str]:
    """Return *shas* newest first, in git's own ordering.

    ``--no-walk`` shows exactly the commits named, dated order, which is what
    puts commits gathered from several walks into one sequence without this
    module having to compare timestamps across time zones.  An invocation that
    fails returns nothing, leaving the caller with the order it already had.
    """
    result = subprocess.run(
        [
            "git",
            "-C",
            str(git_root),
            "log",
            "--no-walk",
            "--format=%H",
            *sorted(shas),
            "--",
        ],
        capture_output=True,
        text=True,
        check=False,
        env=env,
    )
    return result.stdout.split() if result.returncode == 0 else []


def _commit_rows_for(
    git_root: Path, shas: set[str], name: str, env: dict[str, str] | None
) -> list[tuple[str, ...]]:
    """Return per-commit rows for *shas*, each carrying *name* as its path."""
    result = subprocess.run(
        [
            "git",
            "-C",
            str(git_root),
            "log",
            "--no-walk",
            "-z",
            f"--format={_HISTORY_SENTINEL}%H%x00%h%x00%aI%x00%s",
            *sorted(shas),
            "--",
        ],
        capture_output=True,
        text=True,
        check=False,
        env=env,
    )
    if result.returncode != 0:
        return []
    rows: list[tuple[str, ...]] = []
    for block in result.stdout.split(_HISTORY_SENTINEL):
        row = _parse_log_block(block, name)
        if row is not None:
            rows.append(row)
    return rows


def _rows_with_earlier_names(
    git_root: Path,
    rows: list[tuple[str, ...]],
    cur_rel: str,
    bounds: _WalkBounds,
    env: dict[str, str] | None,
) -> list[tuple[str, ...]]:
    """Add the note's commits under the names it carried before (#1306).

    The counterpart of :func:`_with_earlier_names` for the per-commit diff
    walk, which needs each commit paired with the name the note had *there* —
    ``git show <sha> -- <today's name>`` returns nothing for a commit that
    predates a rename.  Purely additive, and the rows are reordered only when
    something was added.
    """
    segments = _name_segments(git_root, cur_rel, env)
    known = {row[0] for row in rows}
    extra: dict[str, set[str]] = {}
    for sha, name in _segment_shas(git_root, segments, bounds, env).items():
        if sha not in known:
            extra.setdefault(name, set()).add(sha)
    if not extra:
        return rows
    for name, shas in extra.items():
        rows = [*rows, *_commit_rows_for(git_root, shas, name, env)]
    by_sha = {row[0]: row for row in rows}
    order = _canonical_order(git_root, set(by_sha), env)
    if not order:
        return rows
    ordered = [by_sha[sha] for sha in order]
    return ordered[: bounds.limit] if bounds.limit is not None else ordered


def _per_commit_rows(
    git_root: Path,
    path: Path,
    ref: str,
    limit: int | None,
    env: dict[str, str] | None,
) -> list[tuple[str, ...]]:
    """Enumerate the note's commits in ``ref..HEAD``, newest first.

    Each row is ``(sha, short_sha, timestamp, message, commit_path)``, where
    *commit_path* is the name the note had at that commit — critical for
    correct diffs across renames (``git show sha -- new.md`` returns nothing
    for a commit that predates the rename; the old name must be passed
    instead).  ``-z`` is what makes that path usable as a pathspec: without it
    a non-ASCII name arrives octal-escaped inside double quotes and the
    per-commit diff comes back empty.

    The ``--follow`` walk is filtered to the note's own lineage, because it
    walks past the commit that created the note and into whatever held the
    name before (#1285), and pins :data:`_RENAME_THRESHOLD`, because at git's
    default it stopped at a rename it scored under 50% (#1297).  What it
    cannot cross at any threshold is a rename that belongs to no parent's
    diff, so the names on the far side of one are recovered separately
    (#1306).

    Raises:
        ValueError: If *ref* is not found in this repository.
    """
    path_str = str(path)
    log_cmd = [
        "git",
        "-c",
        _RENAME_LIMIT,
        "-C",
        str(git_root),
        "log",
        "-z",
        "--follow",
        _RENAME_THRESHOLD,
        f"--format={_HISTORY_SENTINEL}%H%x00%h%x00%aI%x00%s",
        "--name-only",
    ]
    clamped_limit = None if limit is None else min(max(1, limit), 100)
    if clamped_limit is not None:
        log_cmd.append(f"-n{clamped_limit}")
    log_cmd += [f"{ref}..HEAD", "--", literal_pathspec(path_str)]
    try:
        log_result = subprocess.run(
            log_cmd,
            capture_output=True,
            text=True,
            check=True,
            env=env,
        )
    except subprocess.CalledProcessError as exc:
        raise ValueError(
            f"git log failed listing commits since {ref!r}: "
            f"{(exc.stderr or '').strip()}"
        ) from exc

    # Repo-relative posix path — the correct fallback when a --name-only
    # block carries no path (git returns posix-relative paths, so the
    # absolute platform-native path_str would break rename resolution on
    # Windows).
    cur_rel = _repo_rel(git_root, path)
    rel_fallback = cur_rel if cur_rel is not None else path_str
    lineage = (
        _Lineage(None, False)
        if cur_rel is None
        else _lineage(git_root, path, cur_rel, env, rev_range=f"{ref}..HEAD")
    )
    rows: list[tuple[str, ...]] = []
    for block in log_result.stdout.split(_HISTORY_SENTINEL):
        parsed = _parse_log_block(block, rel_fallback)
        if parsed is None:
            continue
        if lineage.shas is not None and parsed[0] not in lineage.shas:
            continue
        rows.append(parsed)
    if cur_rel is None:
        return rows
    bounds = _WalkBounds(limit=clamped_limit, exclude=ref)
    return _rows_with_earlier_names(git_root, rows, cur_rel, bounds, env)


def _per_commit_diffs(
    git_root: Path,
    path: Path,
    ref: str,
    limit: int | None,
    env: dict[str, str] | None,
    *,
    summarize_binary: bool,
) -> list[CommitDiff]:
    """Return one :class:`CommitDiff` per commit in ``ref..HEAD``.

    The commits and the name the note had at each come from
    :func:`_per_commit_rows`; this builds the diff for every one of them.

    Raises :exc:`ValueError` when *ref* is not found or a per-commit diff
    fails for a commit that does have a parent.
    """
    diffs: list[CommitDiff] = []
    for sha, short_sha, timestamp, message, commit_path in _per_commit_rows(
        git_root, path, ref, limit, env
    ):
        # Build a rename-aware diff target for THIS commit vs its parent,
        # mirroring the single-range branch, so a renamed binary pairs into
        # `{old => new} | Bin OLD -> NEW` instead of an add/text stat (#683).
        parent = f"{sha}^"
        commit_args, old_at_parent = _rename_aware_diff_args(
            git_root, parent, sha, commit_path, commit_path, env
        )
        # Classify binariness for THIS commit (not the whole range).
        commit_binary = summarize_binary and _diff_is_binary(git_root, commit_args, env)
        diff_cmd = [
            "git",
            *_READABLE_PATHS,
            "-C",
            str(git_root),
            "diff",
            "--stat" if commit_binary else "-p",
            *commit_args,
        ]
        try:
            show_result = subprocess.run(
                diff_cmd, capture_output=True, text=True, check=True, env=env
            )
            commit_diff_raw = show_result.stdout
        except subprocess.CalledProcessError as exc:
            # A failure here is expected ONLY for a parent-less (root/orphan)
            # commit, where `{sha}^` can't resolve. Any other failure is real
            # and must surface rather than silently degrade to an add-form,
            # rename-unaware diff.
            parent_exists = (
                subprocess.run(
                    [
                        "git",
                        "-C",
                        str(git_root),
                        "rev-parse",
                        "--verify",
                        "--quiet",
                        f"{sha}^",
                    ],
                    capture_output=True,
                    env=env,
                ).returncode
                == 0
            )
            if parent_exists:
                raise ValueError(
                    f"Could not retrieve diff for commit {sha!r}: "
                    f"{(exc.stderr or '').strip()}"
                ) from exc
            commit_diff_raw = _root_commit_diff(
                git_root, sha, commit_path, env, summarize_binary=summarize_binary
            )
        commit_diff = commit_diff_raw.lstrip("\n")
        if (
            not commit_diff
            and old_at_parent is not None
            and old_at_parent != commit_path
        ):
            # Pure rename with byte-identical content: the two-blob diff
            # of identical blobs is empty, so the rename would otherwise be
            # invisible. Synthesize a marker rather than emit an empty diff (#683).
            commit_diff = (
                f"{old_at_parent} => {commit_path} (renamed, no content change)\n"
            )
        diffs.append(
            CommitDiff(
                sha=sha,
                short_sha=short_sha,
                timestamp=timestamp,
                message=message,
                diff=_truncate_diff(commit_diff),
            )
        )
    return diffs


# ---------------------------------------------------------------------------
# Revision reads (#1137)
# ---------------------------------------------------------------------------

# First line of a Git LFS pointer file.  An LFS-tracked note's blob holds this
# stand-in, not the note; the working tree gets the real bytes only because the
# smudge filter ran at checkout, which a revision read does not go through.
_LFS_POINTER_PREFIX = "version https://git-lfs.github.com/spec/v1"

# Git's file mode for a symlink.  The blob behind one holds the link *target*
# as text, not the linked note's content, so a revision read refuses rather
# than handing back a path string as though it were a note.
_SYMLINK_MODE = "120000"


def _revision_walk_output(
    git_root: Path, ref: str, cur_rel: str, env: dict[str, str] | None
) -> str:
    """Return git's ``--name-status`` record stream for *cur_rel* over ``ref..HEAD``.

    See :func:`_first_parent_records_cmd` for why the walk is shaped the way
    it is.  A failed invocation is an error here, because the caller is about
    to serve a note's content and has nothing to fall back on.
    """
    try:
        result = subprocess.run(
            _first_parent_records_cmd(git_root, cur_rel, f"{ref}..HEAD"),
            capture_output=True,
            text=True,
            check=True,
            env=env,
        )
    except subprocess.CalledProcessError as exc:
        raise ValueError(
            f"Could not read history for revision {ref!r}: {(exc.stderr or '').strip()}"
        ) from exc
    return result.stdout


def _iter_name_status(raw: str) -> Iterator[tuple[str, list[str]]]:
    """Yield ``(status, paths)`` from a ``-z --name-status`` stream, newest first.

    The stream interleaves ``\\x1e<sha>`` commit markers with records; a record
    is a status token followed by one path, or two for ``R``/``C``.  Only the
    status token is stripped of the newline git emits after a commit header —
    path tokens are yielded byte-for-byte, since a leading newline is legal in
    a filename.
    """
    tokens = raw.split("\0")
    i = 0
    while i < len(tokens):
        status = tokens[i].lstrip("\n")
        if not status or status.startswith(_HISTORY_SENTINEL):
            i += 1
            continue
        wanted = 2 if status[0] in ("R", "C") else 1
        paths = tokens[i + 1 : i + 1 + wanted]
        if len(paths) < wanted or not all(paths):
            # A short record, or one whose path slot is the stream's trailing
            # empty token: either way the record is incomplete, and half a
            # rename is not something to reason about.
            return
        yield status, paths
        i += 1 + wanted


def _path_at_ref(raw: str, cur_rel: str, ref: str) -> str:
    """Resolve the path *cur_rel* had at *ref*, or refuse.

    Walks git's own records newest-first, carrying the path currently being
    tracked.  Every outcome maps to something git recorded:

    * ``R old new`` where *new* is tracked — the note was renamed; keep going
      from *old*.
    * ``A`` on the tracked path — git is saying the file there was created
      within the range, so the note the caller named did not exist at *ref*.
    * ``C source new`` where *new* is tracked — git found the note's content
      copied from somewhere else rather than carried forward, which is a birth
      too, not a lineage.
    * ``D`` / ``M`` / ``T`` — the note changed or was removed but its identity
      is intact; keep going.
    * Anything else — not a record class this walk understands, and an
      unrecognised record is not evidence of continuity.

    Raises:
        InvalidRequestError: When the records do not connect the note to *ref*.
    """
    tracked = cur_rel
    for status, paths in _iter_name_status(raw):
        if status.startswith("R") and paths[-1] == tracked:
            tracked = paths[0]
        elif status.startswith("A") and paths[0] == tracked:
            raise InvalidRequestError(
                f"{tracked!r} was created after revision {ref!r}, so the note now "
                "at that path did not exist at that revision. Anything stored "
                "under that name then belongs to a different note; use "
                "'get_history' to find a revision this note actually has."
            )
        elif status.startswith("C") and paths[-1] == tracked:
            # The copy source is git's similarity match, not a note the caller
            # asked about: in the case that surfaced this (#1336) it was an
            # unrelated note that merely shared frontmatter scaffolding.
            # Naming it as the thing to read invites restoring unrelated
            # content, and the documented next step after a revision read is
            # to write it back, so this branch points at 'get_history' the
            # way the 'A' branch above does. The source is still named,
            # because it is what git said and it explains the refusal.
            raise InvalidRequestError(
                f"{tracked!r} appears as a copy of {paths[0]!r} rather than as a "
                "continuation of it, so the note now at that path did not exist "
                "at that revision. The copy source is git's similarity match, "
                "not necessarily related to what you asked for; use "
                "'get_history' to find a revision this note actually has."
            )
        elif status[0] not in ("D", "M", "T") or paths[0] != tracked:
            raise InvalidRequestError(
                f"Cannot follow {cur_rel!r} back to revision {ref!r}: git reports "
                f"{status!r} for {paths[0]!r}, which does not establish that the "
                "note is the same one. Use 'get_history' and 'get_diff' to inspect "
                "the range directly."
            )
    return tracked


def _require_ancestor(git_root: Path, ref: str, env: dict[str, str] | None) -> str:
    """Resolve *ref* to a full commit id, refusing one that is not HEAD's ancestor.

    ``ref..HEAD`` enumerates what is reachable from HEAD but not from *ref*.
    When *ref* sits on a discarded branch — after a rebase, a reset, or a SHA
    copied from elsewhere — that set is not "the commits since *ref*", and the
    walk's reasoning about creations and renames does not hold.  The commit is
    resolved first, so ``merge-base`` sees a full id: its exit 1 then means
    "not an ancestor", and any other failure is the repository's.

    Returns:
        The full commit id.

    Raises:
        InvalidRequestError: If *ref* names no commit, or one HEAD does not
            descend from, including an unborn HEAD that has no history (#1608).
        ValueError: If git fails for another reason.
    """
    commit = _require_commit(git_root, ref, env)
    if not _has_commits(git_root, env):
        raise InvalidRequestError(
            f"The current branch has no commits yet, so revision {ref!r} is not "
            "on its history."
        )
    result = subprocess.run(
        ["git", "-C", str(git_root), "merge-base", "--is-ancestor", commit, "HEAD"],
        capture_output=True,
        text=True,
        check=False,
        env=env,
    )
    if result.returncode == 1:
        raise InvalidRequestError(
            f"Revision {ref!r} is not an ancestor of the current HEAD (it may be "
            "on history that was rebased away), so this note's path at that "
            "revision cannot be established."
        )
    if result.returncode != 0:
        raise ValueError(f"git merge-base failed for {ref!r}: {result.stderr.strip()}")
    return commit


def _require_tracked(
    git_root: Path, path: Path, cur_rel: str, env: dict[str, str] | None
) -> None:
    """Refuse when the note on disk is not the one git has been recording.

    A note committed, deleted, and then recreated **untracked** leaves the walk
    with a ``D`` record and no ``A``: nothing marks the current file's birth,
    because git never saw it. Without this check the walk would return the
    deleted note's content under the new note's name.  A path absent from disk
    is the recover-a-deleted-note case and is left to the walk.

    Raises:
        InvalidRequestError: If the note on disk is not tracked (#1608).
        ValueError: If ``git ls-files`` fails.
        OSError: If the note's stat is refused (#1625).
    """
    if not path_exists(path):
        return
    result = subprocess.run(
        ["git", "-C", str(git_root), "ls-files", "--", literal_pathspec(cur_rel)],
        capture_output=True,
        text=True,
        check=False,
        env=env,
    )
    if result.returncode != 0:
        raise ValueError(f"git ls-files failed: {result.stderr.strip()}")
    if not result.stdout.strip():
        raise InvalidRequestError(
            f"{cur_rel!r} is not tracked by git, so it has no history: content "
            "stored under that name at an earlier revision belongs to a "
            "different file."
        )


def _require_inside_vault(historical: str, prefix: str, ref: str) -> None:
    """Refuse a historical path that resolves outside the vault.

    The caller's path is confined to the vault by ``validate_history_path``,
    but the path the *walk* resolves to is confined by nothing: a git
    repository can hold far more than the vault, and a note renamed in from
    outside carries a repository-relative path from outside.  Reading that
    blob would answer a vault query with content the vault never contained —
    the containment guarantee every other read path enforces.  Where the vault
    *is* the repository root the prefix is empty and nothing can fall outside
    it.

    Raises:
        InvalidRequestError: If *historical* is not beneath *prefix*.
    """
    if prefix and not historical.startswith(prefix):
        raise InvalidRequestError(
            f"At revision {ref!r} this note lived at {historical!r}, outside the "
            "vault, so its content there is not the vault's to return. Read a "
            "revision from after it moved into the vault; get_history lists them."
        )


def _tree_entry(
    git_root: Path, ref: str, repo_rel: str, env: dict[str, str] | None, shown: str
) -> tuple[str, int]:
    """Return ``(blob_sha, size)`` for *repo_rel* at *ref*.

    *ref* is the resolved commit id git is asked about; messages name the
    revision as the caller gave it, *shown*.

    Deliberately not ``git cat-file <ref>:<path>``.  That syntax is not a
    pathspec but a revision expression, and git resolves an unmatched one to
    whatever else it can parse: for a note named ``star*note.md`` it returns
    the *commit* object, so a size check passes against the wrong object and
    the subsequent blob read fails with a message on stderr and an exit status
    of **zero** — which reads as an empty note.  Asking the tree instead keeps
    the lookup a pathspec, and so glob-proof like every other in this package,
    and yields the mode, the object id, and the size in one call, with the blob
    then fetched by its own hash.

    Raises:
        InvalidRequestError: If nothing is recorded at that path, or the entry
            is not a regular file (a symlink's blob holds its target path, not
            note content; a directory has no content to return).
        ValueError: If ``git ls-tree`` fails or prints what cannot be parsed.
    """
    result = subprocess.run(
        [
            "git",
            "-C",
            str(git_root),
            "ls-tree",
            "-l",
            "-z",
            ref,
            "--",
            literal_pathspec(repo_rel),
        ],
        capture_output=True,
        text=True,
        check=False,
        env=env,
    )
    if result.returncode != 0:
        raise ValueError(
            f"git ls-tree failed for {repo_rel!r} at {ref!r}: {result.stderr.strip()}"
        )
    entry = result.stdout.split("\0")[0].strip()
    if not entry:
        raise InvalidRequestError(f"{repo_rel!r} is not present at revision {shown!r}.")
    # ``<mode> SP <type> SP <sha> SP* <size> TAB <path>`` — the path may hold
    # anything, so split off the metadata by the single tab and no further.
    meta = entry.split("\t", 1)[0].split()
    if len(meta) != 4:
        raise ValueError(f"Could not read {repo_rel!r} at revision {ref!r}.")
    mode, kind, sha, size = meta
    if mode == _SYMLINK_MODE:
        raise InvalidRequestError(
            f"{repo_rel!r} was a symlink at that revision; git stores its target "
            "path rather than note content, so there is nothing to return."
        )
    if kind != "blob":
        raise InvalidRequestError(
            f"{repo_rel!r} was not a file at revision {shown!r} (git records a "
            f"{kind}), so it has no content to return."
        )
    return sha, int(size)


def _blob_bytes(
    git_root: Path, sha: str, max_bytes: int, size: int, env: dict[str, str] | None
) -> bytes:
    """Return the bytes of blob *sha*, refusing it if *size* is over the cap.

    The size comes from the tree entry, so an oversized historical note is
    refused before it is materialised — the revision analogue of the
    ``stat()`` :meth:`DocumentManager.read` does.

    Raises:
        InvalidRequestError: If the blob exceeds *max_bytes*; a section read
            is exempt from the cap (#1608).
        ValueError: If ``git cat-file`` fails.
    """
    if 0 < max_bytes < size:
        raise InvalidRequestError(
            f"Note is {size} bytes at that revision, over the {max_bytes}-byte "
            "read limit. Pass section= to read one section of it."
        )
    blob = subprocess.run(
        ["git", "-C", str(git_root), "cat-file", "blob", sha],
        capture_output=True,
        check=False,
        env=env,
    )
    if blob.returncode != 0:
        raise ValueError(
            f"Could not read object {sha} from git history: "
            f"{blob.stderr.decode(errors='replace').strip()}"
        )
    return blob.stdout


def _note_text(blob: bytes, path: str, where: str) -> str:
    """Decode a historical note's bytes, refusing what is not note text.

    *path* is the note's name today, which the caller asked about; *where*
    names the path it had and the revision, for the reason.

    The blob is decoded explicitly, so a note that is not valid UTF-8 at that
    revision is reported as unreadable rather than a decode error escaping.
    Both refusals mirror an on-disk :meth:`DocumentManager.read`: the note
    exists at that revision but its text cannot be returned (#1608).

    Raises:
        DocumentUnreadableError: If the bytes are not valid UTF-8, or are a
            Git LFS pointer rather than the note.
    """
    try:
        text = blob.decode()
    except UnicodeDecodeError as exc:
        raise DocumentUnreadableError(
            path, f"its content as {where} is not valid UTF-8"
        ) from exc
    if text.startswith(_LFS_POINTER_PREFIX):
        raise DocumentUnreadableError(
            path,
            f"{where} is stored in Git LFS, so git holds a pointer "
            "rather than the note's text, and restoring that pointer would "
            "overwrite the note. The LFS object must be fetched to read it.",
        )
    return text


def get_file_at_ref(
    git_root: Path | None,
    query: RevisionQuery,
    *,
    token: str | None,
    username: str,
) -> RevisionContent:
    """Return a note's content as it stood at a revision, rename-aware.

    Resolution is by *note*, not by path: the caller passes the path the note
    has today and git's own add/rename records are walked back to *ref*.
    Where those records do not connect the two — a name reused by a different
    note, a delete-and-recreate, a rename git cannot detect — this raises
    rather than returning content that belongs to some other note.  A caller
    about to write the result back must never be handed a plausible wrong
    answer.

    Args:
        git_root: Pre-resolved git repository root; ``None`` raises, since an
            empty result is indistinguishable from "the note was empty then".
        query: The note, revision, and read cap being asked for.
        token: Git credential token, forwarded to the subprocess environment.
        username: Git username for credential forwarding.

    Returns:
        A :class:`~markdown_vault_mcp.types.RevisionContent` carrying the
        content and the vault-relative path the note had at that revision.

    Raises:
        InvalidRequestError: When the vault is not git-backed, the revision is
            unusable, the note's identity cannot be traced to it, or its
            content there is over the read cap.
        DocumentUnreadableError: When the note's content at that revision is
            not valid UTF-8, or is a Git LFS pointer.
        ValueError: When git itself fails.
    """
    if git_root is None:
        raise InvalidRequestError(
            "Reading a note at a revision requires a git-backed vault; this "
            "vault's source directory is not inside a git repository."
        )
    cur_rel = _repo_relative(git_root, query.path)
    prefix = _vault_prefix(git_root, query.repo_path)
    env = git_env(token, username)
    try:
        commit = _require_ancestor(git_root, query.ref, env)
        _require_tracked(git_root, query.path, cur_rel, env)
        historical = _path_at_ref(
            _revision_walk_output(git_root, commit, cur_rel, env),
            cur_rel,
            query.ref,
        )
        _require_inside_vault(historical, prefix, query.ref)
        sha, size = _tree_entry(git_root, commit, historical, env, query.ref)
        blob = _blob_bytes(git_root, sha, query.max_bytes, size, env)
        content = _note_text(
            blob,
            _strip_prefix(cur_rel, prefix),
            f"{_strip_prefix(historical, prefix)!r} at revision {query.ref!r}",
        )
    finally:
        cleanup_git_env(env)

    return RevisionContent(
        path=_strip_prefix(cur_rel, prefix),
        historical_path=_strip_prefix(historical, prefix),
        revision=query.ref,
        content=content,
    )


def committed_revision(
    git_root: Path | None,
    path: Path,
    *,
    token: str | None,
    username: str,
) -> str | None:
    """Return the newest commit whose blob for *path* is what is on disk now.

    The breadcrumb an overwrite hands back has to name a commit that actually
    holds the content being replaced, so both halves are checked: the note's
    latest commit, and that the working tree still matches it.  The comparison
    is against that **named commit** rather than ``HEAD`` — the commit worker
    runs on its own thread and does not hold the vault's write lock, so a
    ``HEAD``-relative check can answer about a commit this function never
    named.

    Returns:
        The commit SHA, or ``None`` when the note has no commit yet, when the
        working tree has moved on from its newest one, or when git cannot be
        consulted.  ``None`` means "no breadcrumb", never "no such commit".
    """
    if git_root is None:
        return None
    env = git_env(token, username)
    try:
        rel = _repo_relative(git_root, path)
        found = subprocess.run(
            [
                "git",
                "-C",
                str(git_root),
                "log",
                "-1",
                "--format=%H",
                "--",
                literal_pathspec(rel),
            ],
            capture_output=True,
            text=True,
            check=False,
            env=env,
        )
        sha = found.stdout.strip()
        if found.returncode != 0 or not sha:
            return None
        tracked = subprocess.run(
            ["git", "-C", str(git_root), "ls-files", "--", literal_pathspec(rel)],
            capture_output=True,
            text=True,
            check=False,
            env=env,
        )
        if not tracked.stdout.strip():
            # git diff is blind to an untracked file, so without this a note
            # recreated after a committed delete would "match" the commit that
            # deleted it — a breadcrumb pointing at content that is not there.
            return None
        clean = subprocess.run(
            [
                "git",
                "-C",
                str(git_root),
                "diff",
                "--quiet",
                sha,
                "--",
                literal_pathspec(rel),
            ],
            capture_output=True,
            check=False,
            env=env,
        )
        return sha if clean.returncode == 0 else None
    finally:
        cleanup_git_env(env)


def _repo_relative(git_root: Path, path: Path) -> str:
    """Return *path* as git sees it: relative to the repository root, posix.

    Git reports and accepts repository-root-relative paths, while the vault's
    own paths are relative to the vault root — which may sit below the git
    root.  Comparing the two forms directly is the defect this function
    exists to prevent: every rename and creation test in the walk would
    silently never match.

    Resolving also follows symlinks, deliberately: an on-disk read of a
    symlinked note returns the target's content, so a revision read of one
    reports the target's history rather than a second, divergent answer.

    Raises:
        InvalidRequestError: If *path* resolves outside the repository.
    """
    try:
        return path.resolve().relative_to(git_root).as_posix()
    except ValueError as exc:
        raise InvalidRequestError(
            f"{path.name!r} resolves outside the git repository, so it has no "
            "history there."
        ) from exc


def _strip_prefix(repo_rel: str, prefix: str) -> str:
    """Convert a repository-relative path back to a vault-relative one."""
    return (
        repo_rel[len(prefix) :] if prefix and repo_rel.startswith(prefix) else repo_rel
    )
