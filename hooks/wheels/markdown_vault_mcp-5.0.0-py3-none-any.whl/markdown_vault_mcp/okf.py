"""OKF (Open Knowledge Format) support: detection and read-side annotations.

OKF (`GoogleCloudPlatform/knowledge-catalog`, ``okf/SPEC.md``) is a bundle
convention over markdown-with-frontmatter. What the spec says — in both texts
of "Version 0.2", since it was amended in place on 2026-08-21 — is recorded
with sources and dates in ``docs/design/reference/okf-v0.2.md``; read it
before changing a rule here. This module implements phase 1 of
`docs/design/okf.md`: the vault-side detection probe (``okf_version`` declared
in the bundle-root ``index.md``) and the pure derivation of per-note read
annotations (``type`` / ``status`` / staleness / trust tier).

Trust model (design §2): the vault-side declaration only ever enables
*read* semantics and advisory guidance — never write behavior. Detection is
pure disk I/O with zero index coupling (the :class:`OkfDetector` mirrors
``conventions.ConventionsResolver``), so it works before the index is built
and reflects a mid-session declaration on the next call.

The OKF field vocabulary is deliberately kept as *data* (module constants)
rather than spread through code: the spec is pre-1.0 with one breaking
rename already behind it, so a future revision should be a table edit.
"""

from __future__ import annotations

import datetime as _dt
import logging
import re
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

# Both halves of the library are used here, deliberately: `fm` serialises the
# write stamps (`fm.dumps` / `fm.Post`), while every *read* goes through
# `parse_frontmatter`, the package's single parse entry point, so a block no
# handler can read raises one error rather than the handler's own (#1408).
import frontmatter as fm
import yaml

from markdown_vault_mcp.exceptions import InvalidRequestError
from markdown_vault_mcp.scanner import parse_frontmatter
from markdown_vault_mcp.utils.fs import is_directory
from markdown_vault_mcp.utils.links import build_plain_destination, escape_link_text
from markdown_vault_mcp.utils.text import read_text_utf8

if TYPE_CHECKING:
    from collections.abc import Mapping
    from pathlib import Path

logger = logging.getLogger(__name__)

# --- OKF v0.2 field-mapping table (data, not code) --------------------------

#: Spec revisions this implementation knows; anything else logs a warning
#: and is still treated as detected (permissive-consumer behavior extends
#: to the marker itself).
KNOWN_OKF_VERSIONS: tuple[str, ...] = ("0.1", "0.2")

#: Scalar frontmatter keys promoted into ``document_tags`` when detection
#: is on (feeds the phase-2 filters; harmless to index ahead of them).
OKF_INDEXED_FIELDS: tuple[str, ...] = ("type", "status", "stale_after")

#: Lifecycle vocabulary (``status``); absent means ``stable`` per spec.
OKF_STATUS_DEFAULT = "stable"
OKF_STATUS_VALUES: tuple[str, ...] = ("draft", "stable", "deprecated")

#: Trust tiers, least to most trusted.
TRUST_UNVERIFIED = "unverified"
TRUST_MACHINE = "machine-confirmed"
TRUST_HUMAN = "human-reviewed"

#: ``verified[].by`` prefix that marks a human verifier.
_HUMAN_ACTOR_PREFIX = "human:"

#: Reserved bundle filenames (navigation, not concepts). Not consumed in
#: phase 1 — staged for the conformance audit (#962: reserved files are
#: exempt from the ``type`` rule) and ranking downweights (#965).
OKF_RESERVED_FILENAMES: tuple[str, ...] = ("index.md", "log.md")

#: H1 heading, and title, of a generated ``log.md``. Shared by the two body
#: builders and the reserved-frontmatter policy so the heading a reader sees
#: and the title the index resolves cannot drift apart.
OKF_LOG_TITLE = "Log"

#: H1 heading, and title, of a generated bundle-root ``index.md``. A folder's
#: index uses the folder name instead.
OKF_ROOT_INDEX_TITLE = "Index"

#: Ranking downweight factors (design §5, #965), applied only under detection.
#: Multiplicative on a hit's score and composed so the ordering
#: deprecated < stale < normal holds (a note that is both sinks below either
#: alone). Reserved navigation files (``index.md`` / ``log.md``) are demoted so
#: they don't compete with real notes. Trust-tier *boosting* is deliberately
#: not here — the spec keeps tiers annotation-only.
OKF_DEPRECATED_WEIGHT = 0.5
OKF_STALE_WEIGHT = 0.75
OKF_RESERVED_WEIGHT = 0.5

#: ``filters`` keys that carry OKF semantics on an active bundle (phase 2,
#: #961). ``type`` is deliberately absent: it is a plain indexed tag lookup
#: with no special semantics, so the ordinary ``document_tags`` path
#: handles it.
OKF_FILTER_KEYS: tuple[str, ...] = ("status", "stale", "trust_tier")

#: Accepted spellings for the boolean ``stale`` filter value.
_STALE_TRUE = frozenset({"true", "1", "yes"})
_STALE_FALSE = frozenset({"false", "0", "no"})

#: Bundle-root file allowed to carry ``okf_version``.
_ROOT_INDEX = "index.md"

#: Read cap for the detection probe, mirroring the conventions resolver:
#: bounds I/O and parsing on a pathological root ``index.md``.
_MAX_READ_CHARS = 65536


@dataclass(frozen=True)
class OkfState:
    """Snapshot of OKF detection for one probe.

    Attributes:
        mode: Configured mode (``"auto"`` / ``"off"`` / ``"on"``).
        declared_version: ``okf_version`` value from the root ``index.md``
            frontmatter, or ``None`` when absent/unreadable.
        active: Whether read semantics are in effect — declared under
            ``auto``, always under ``on``, never under ``off``.
    """

    mode: str
    declared_version: str | None
    active: bool


class OkfDetector:
    """Probe the vault's OKF declaration from disk on demand.

    Pure disk I/O with zero index coupling (the ``ConventionsResolver``
    pattern): each :meth:`state` call reads at most the first
    :data:`_MAX_READ_CHARS` characters of the root ``index.md``, so
    detection works before the index exists (managed-git mode) and a
    mid-session declaration takes effect on the next call.

    Args:
        source_dir: Root directory of the markdown vault.
        mode: Configured OKF mode — ``"auto"`` (follow the declaration),
            ``"off"`` (never active), or ``"on"`` (active regardless).
    """

    def __init__(self, source_dir: Path, mode: str = "auto") -> None:
        self._source_dir = source_dir
        self._mode = mode
        self._warned_versions: set[str] = set()

    @property
    def mode(self) -> str:
        """The configured OKF mode."""
        return self._mode

    def state(self) -> OkfState:
        """Return the current detection snapshot.

        Returns:
            The mode, declared version (probed unless mode is ``"off"``),
            and whether read semantics are active.
        """
        if self._mode == "off":
            return OkfState(mode=self._mode, declared_version=None, active=False)
        version = self._probe_declared_version()
        # Warn-once dedup is best-effort: concurrent first probes may each
        # log the warning (set membership is checked without a lock). The
        # worst case is a duplicate log line, which does not justify
        # synchronizing a read path.
        if (
            version is not None
            and version not in KNOWN_OKF_VERSIONS
            and version not in self._warned_versions
        ):
            self._warned_versions.add(version)
            logger.warning(
                "okf_unknown_version declared=%s known=%s",
                version,
                ",".join(KNOWN_OKF_VERSIONS),
            )
        active = self._mode == "on" or version is not None
        return OkfState(mode=self._mode, declared_version=version, active=active)

    def _probe_declared_version(self) -> str | None:
        """Read ``okf_version`` from the root ``index.md`` frontmatter.

        Returns:
            The declared version as a string (YAML scalars are normalized,
            so an unquoted ``0.2`` still reads as ``"0.2"``), or ``None``
            when the file is missing, unreadable, has no parseable
            frontmatter, or carries no usable ``okf_version``.
        """
        file_path = self._source_dir / _ROOT_INDEX
        try:
            raw = read_text_utf8(file_path, limit=_MAX_READ_CHARS)
        except FileNotFoundError:
            return None
        except (OSError, UnicodeDecodeError):
            logger.debug("okf_probe_read_failed path=%s", _ROOT_INDEX, exc_info=True)
            return None
        try:
            metadata = parse_frontmatter(raw).metadata
        except yaml.YAMLError:
            logger.debug(
                "okf_probe_frontmatter_invalid path=%s", _ROOT_INDEX, exc_info=True
            )
            return None
        value = metadata.get("okf_version")
        if isinstance(value, str):
            return value.strip() or None
        if isinstance(value, (int, float)):
            return str(value)
        return None


def verified_entries(metadata: dict[str, Any]) -> list[Any]:
    """Return a note's ``verified`` field as the list the spec defines.

    The field reference allows a single verifier "as a bare mapping without
    the list dash" and requires consumers to "treat a bare mapping as a
    one-element list" (#1357). Every reader of ``verified`` goes through
    here so the shorthand is honoured at each of them alike.

    Args:
        metadata: The note's frontmatter dict.

    Returns:
        The list as written, a bare mapping wrapped as one element, or an
        empty list when the field is absent or of neither shape.
    """
    verified = metadata.get("verified")
    if isinstance(verified, list):
        return verified
    if isinstance(verified, dict):
        return [verified]
    return []


def derive_trust_tier(metadata: dict[str, Any]) -> str:
    """Derive a note's trust tier from its ``verified`` frontmatter.

    Per the design (§3): ``human-reviewed`` when any well-formed
    ``verified[].by`` carries the ``human:`` prefix; ``machine-confirmed``
    when ``verified`` is non-empty (all verifiers non-human); ``unverified``
    otherwise. Entries that are not mappings are ignored (permissive
    consumer); a bare mapping is one entry (:func:`verified_entries`).

    Args:
        metadata: The note's frontmatter dict.

    Returns:
        One of :data:`TRUST_UNVERIFIED`, :data:`TRUST_MACHINE`,
        :data:`TRUST_HUMAN`.
    """
    entries = [entry for entry in verified_entries(metadata) if isinstance(entry, dict)]
    if any(
        str(entry.get("by", "")).startswith(_HUMAN_ACTOR_PREFIX) for entry in entries
    ):
        return TRUST_HUMAN
    if entries:
        return TRUST_MACHINE
    return TRUST_UNVERIFIED


_DATE_ONLY_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")


def _aware_or_none(value: _dt.datetime, raw: Any) -> _dt.datetime | None:
    """Keep an instant that carries an offset; drop one that does not."""
    if value.tzinfo is None:
        logger.debug("okf_stale_after_naive value=%r", raw)
        return None
    return value


def _parse_stale_after(raw: Any) -> _dt.date | _dt.datetime | None:
    """Read a ``stale_after`` value into the shape its text of v0.2 gives it.

    Returns a ``date`` for the July text's calendar-day form, an aware
    ``datetime`` for the August text's instant form, and ``None`` for
    anything else — including a datetime without an offset, which neither
    text allows and the amendment says to ignore (#1373).
    """
    if isinstance(raw, _dt.datetime):
        return _aware_or_none(raw, raw)
    if isinstance(raw, _dt.date):
        return raw
    if not isinstance(raw, str):
        return None
    text = raw.strip()
    try:
        parsed = (
            _dt.date.fromisoformat(text)
            if _DATE_ONLY_RE.match(text)
            else _dt.datetime.fromisoformat(text)
        )
    except ValueError:
        logger.debug("okf_stale_after_invalid value=%r", raw)
        return None
    return _aware_or_none(parsed, raw) if isinstance(parsed, _dt.datetime) else parsed


def derive_stale(metadata: dict[str, Any], *, now: _dt.datetime) -> bool:
    """Derive staleness from ``stale_after``.

    Both texts of OKF v0.2 are honoured (``docs/design/reference/okf-v0.2.md``,
    "Lifecycle"): a calendar date is stale from that day on, judged by the
    server-local day of *now* (the July rule, #1357); an instant with an
    offset is stale when ``now >= stale_after`` (the August rule, #1373). A
    datetime without an offset is ignored, as the amendment asks.

    Args:
        metadata: The note's frontmatter dict. ``stale_after`` may be a
            ``date`` or ``datetime`` (YAML parses bare timestamps) or their
            ISO 8601 string spellings; anything else is treated as absent.
        now: The current instant, timezone-aware. Its local calendar day is
            what a bare date is compared against.

    Returns:
        ``True`` iff ``stale_after`` parses and *now* has reached it.
    """
    boundary = _parse_stale_after(metadata.get("stale_after"))
    if boundary is None:
        return False
    if isinstance(boundary, _dt.datetime):
        return now >= boundary
    return now.date() >= boundary


def derive_annotation(
    metadata: dict[str, Any],
    *,
    now: _dt.datetime | None = None,
    include_sources: bool = False,
) -> dict[str, Any]:
    """Derive the ``okf`` read-annotation payload for one note.

    Args:
        metadata: The note's frontmatter dict (may be empty).
        now: The current instant for staleness, timezone-aware; defaults to
            the server's local now.
        include_sources: When true (``read`` payloads), include the raw
            ``sources`` list; otherwise (search hits) include only
            ``sources_count``, and only when non-zero.

    Returns:
        The annotation dict: ``status`` (defaulted to ``"stable"``),
        ``stale``, and ``trust_tier`` always; ``type`` only when present
        and non-empty; sources per *include_sources*.
    """
    now = now or _dt.datetime.now().astimezone()
    annotation: dict[str, Any] = {}
    note_type = metadata.get("type")
    if isinstance(note_type, str) and note_type.strip():
        annotation["type"] = note_type.strip()
    status = metadata.get("status")
    annotation["status"] = (
        status.strip()
        if isinstance(status, str) and status.strip()
        else OKF_STATUS_DEFAULT
    )
    annotation["stale"] = derive_stale(metadata, now=now)
    annotation["trust_tier"] = derive_trust_tier(metadata)
    sources = metadata.get("sources")
    source_list = sources if isinstance(sources, list) else []
    if include_sources:
        if source_list:
            annotation["sources"] = source_list
    elif source_list:
        annotation["sources_count"] = len(source_list)
    return annotation


def okf_downweight_factor(annotation: dict[str, Any], path: str) -> float:
    """Return the multiplicative ranking factor for one OKF hit (design §5).

    The curated-pipeline downweight for phase 6 (#965). Composes the
    deprecated / stale / reserved-file factors so deprecated < stale < normal,
    and a note that is both deprecated and stale sinks below either alone.
    ``1.0`` means no change.

    Args:
        annotation: The note's :func:`derive_annotation` result (reads
            ``status`` and ``stale``).
        path: The note's vault-relative path (reserved-file check, no I/O).

    Returns:
        A factor in ``(0, 1]``.
    """
    factor = 1.0
    if annotation.get("status") == "deprecated":
        factor *= OKF_DEPRECATED_WEIGHT
    if annotation.get("stale"):
        factor *= OKF_STALE_WEIGHT
    if path.rsplit("/", 1)[-1] in OKF_RESERVED_FILENAMES:
        factor *= OKF_RESERVED_WEIGHT
    return factor


def parse_stale_filter(value: str) -> bool:
    """Parse the ``stale`` filter value into a boolean.

    Args:
        value: The raw filter value (``filters`` is ``dict[str, str]``).

    Returns:
        The requested staleness.

    Raises:
        InvalidRequestError: If *value* is not a recognized true/false spelling.
    """
    normalized = value.strip().lower()
    if normalized in _STALE_TRUE:
        return True
    if normalized in _STALE_FALSE:
        return False
    raise InvalidRequestError(f"stale filter must be true or false, got {value!r}")


def matches_okf_filters(
    metadata: dict[str, Any],
    okf_filters: dict[str, str],
    *,
    now: _dt.datetime | None = None,
) -> bool:
    """Evaluate the OKF filter dimensions against one note's frontmatter.

    Semantics (design §4): ``status`` matches the derived lifecycle value,
    so ``status=stable`` matches notes with *absent* ``status`` (the spec
    default); ``stale`` compares the derived staleness; ``trust_tier``
    compares the derived tier. Filters compose with AND.

    Args:
        metadata: The note's frontmatter dict (may be empty).
        okf_filters: The OKF-dimension subset of a ``filters`` dict —
            keys from :data:`OKF_FILTER_KEYS` only.
        now: The current instant for staleness, timezone-aware; defaults to
            the server's local now.

    Returns:
        ``True`` when every given dimension matches.

    Raises:
        InvalidRequestError: If a ``stale`` value is not a true/false spelling.
    """
    annotation = derive_annotation(metadata, now=now)
    for key, value in okf_filters.items():
        if key == "stale":
            if annotation["stale"] is not parse_stale_filter(value):
                return False
        elif annotation.get(key) != value:
            return False
    return True


@dataclass(frozen=True)
class OkfFinding:
    """One audit rule's result: a count plus capped example paths."""

    count: int
    examples: tuple[str, ...]


@dataclass(frozen=True)
class OkfAuditReport:
    """Bundle-conformance audit result (design §4; #962).

    Degrees, not verdicts: during a migration the audit is a progress
    meter, so partial conformance is first-class. ``conformance`` findings
    violate the spec's single hard rule (parseable frontmatter with a
    non-empty ``type``), its placement rule for ``okf_version``, or its
    index-file rule; ``advisories`` are tolerated-by-spec deviations worth
    fixing; ``informational`` entries are not deviations at all (wikilinks
    only matter at export; recommended fields are optional).

    Attributes:
        mode: Configured OKF mode at audit time.
        declared_version: Declared ``okf_version``, or ``None``.
        active: Whether read semantics were active at audit time.
        total_notes: Non-reserved markdown files examined.
        conformant_notes: Notes with parseable frontmatter and a
            non-empty ``type``.
        missing_type: Notes lacking a non-empty ``type``.
        unparseable_frontmatter: Notes whose frontmatter fails to parse.
        misplaced_okf_version: Notes outside the bundle root carrying
            ``okf_version``.
        unknown_status: Notes with a ``status`` outside the spec
            vocabulary (tolerated; advisory).
        log_heading_shape: ``log.md`` files with ``##`` headings that are
            not ``YYYY-MM-DD`` dates (advisory).
        root_index_missing: Whether the bundle-root ``index.md`` is absent
            (advisory; consumers must tolerate it).
        wikilink_files: Notes containing wikilinks (informational; only
            matters at export).
        missing_recommended: Notes lacking a recommended ``title`` or
            ``description`` (informational).
        index_frontmatter: ``index.md`` files carrying frontmatter the
            format does not allow there: any block on a folder index, and
            on the bundle root anything but a lone ``okf_version`` key.
            Server-generated indexes are held to the same rule. An empty or
            non-mapping block, or YAML that does not parse, counts, since
            presence is read from the block rather than its keys; keys are
            read by the same parser as every other rule, so JSON frontmatter
            is judged by its keys and its syntax is not checked. A folder
            index declaring ``okf_version`` is also
            ``misplaced_okf_version``. Declared last and defaulted so earlier
            positional construction still works.
    """

    mode: str
    declared_version: str | None
    active: bool
    total_notes: int
    conformant_notes: int
    missing_type: OkfFinding
    unparseable_frontmatter: OkfFinding
    misplaced_okf_version: OkfFinding
    unknown_status: OkfFinding
    log_heading_shape: OkfFinding
    root_index_missing: bool
    wikilink_files: OkfFinding
    missing_recommended: OkfFinding
    index_frontmatter: OkfFinding = OkfFinding(count=0, examples=())


class _FindingAccumulator:
    """Count occurrences and keep the first *cap* example paths."""

    def __init__(self, cap: int) -> None:
        self._cap = cap
        self.count = 0
        self.examples: list[str] = []

    def add(self, path: str) -> None:
        self.count += 1
        if len(self.examples) < self._cap:
            self.examples.append(path)

    def finding(self) -> OkfFinding:
        return OkfFinding(count=self.count, examples=tuple(self.examples))


class _AuditCounters:
    """Mutable working state for one :func:`audit_bundle` run."""

    def __init__(self, cap: int) -> None:
        self.missing_type = _FindingAccumulator(cap)
        self.unparseable = _FindingAccumulator(cap)
        self.misplaced = _FindingAccumulator(cap)
        self.unknown_status = _FindingAccumulator(cap)
        self.log_shape = _FindingAccumulator(cap)
        self.wikilinks = _FindingAccumulator(cap)
        self.missing_recommended = _FindingAccumulator(cap)
        self.index_frontmatter = _FindingAccumulator(cap)
        self.total = 0
        self.conformant = 0
        self.root_index_seen = False


_LOG_HEADING_RE = re.compile(r"^## (\d{4}-\d{2}-\d{2})\s*$")


def _log_headings_conform(body: str) -> bool:
    """Whether every ``##`` heading in a ``log.md`` body is a date heading."""
    return all(
        _LOG_HEADING_RE.match(line)
        for line in body.splitlines()
        if line.startswith("## ")
    )


def _index_frontmatter_conforms(rel: str, raw: str, metadata: dict[str, Any]) -> bool:
    """Whether an ``index.md`` carries only the frontmatter §8 allows.

    Presence is read from the block, not from *metadata*: an empty,
    comment-only, non-mapping or unparseable block parses to no keys yet is
    still a block. The splitter agrees with the parse about where a block
    is — after leading blank lines, and never when the opening ``---`` is
    left unclosed.
    """
    from markdown_vault_mcp.scanner import strip_frontmatter_block

    if strip_frontmatter_block(raw) == raw:
        return True
    return rel == _ROOT_INDEX and set(metadata) == {"okf_version"}


def _read_capped(file_path: Path, rel: str) -> str | None:
    """Read up to :data:`_MAX_READ_CHARS` of *file_path*, ``None`` on error."""
    try:
        return read_text_utf8(file_path, limit=_MAX_READ_CHARS)
    except (OSError, UnicodeDecodeError):
        logger.debug("okf_audit_read_failed path=%s", rel, exc_info=True)
        return None


def _evaluate_note(
    rel: str, metadata: dict[str, Any], body: str, acc: _AuditCounters
) -> None:
    """Apply the non-reserved-note rules to one parsed note."""
    note_type = metadata.get("type")
    if isinstance(note_type, str) and note_type.strip():
        acc.conformant += 1
    else:
        acc.missing_type.add(rel)
    status = metadata.get("status")
    if (
        isinstance(status, str)
        and status.strip()
        and status.strip() not in OKF_STATUS_VALUES
    ):
        acc.unknown_status.add(rel)
    if "[[" in body:
        acc.wikilinks.add(rel)
    if not metadata.get("title") or not metadata.get("description"):
        acc.missing_recommended.add(rel)


def _audit_file(rel: str, raw: str, acc: _AuditCounters) -> None:
    """Classify one markdown file and update the audit counters."""
    try:
        post = parse_frontmatter(raw)
        metadata: dict[str, Any] = dict(post.metadata)
        body = post.content
        parse_ok = True
    except yaml.YAMLError:
        metadata, body, parse_ok = {}, raw, False

    name = rel.rsplit("/", 1)[-1]
    if rel == _ROOT_INDEX:
        acc.root_index_seen = True
    elif "okf_version" in metadata:
        acc.misplaced.add(rel)
    if name in OKF_RESERVED_FILENAMES:
        if name == "log.md" and not _log_headings_conform(body):
            acc.log_shape.add(rel)
        elif name == "index.md" and not _index_frontmatter_conforms(rel, raw, metadata):
            acc.index_frontmatter.add(rel)
        return

    acc.total += 1
    if not parse_ok:
        acc.unparseable.add(rel)
    else:
        _evaluate_note(rel, metadata, body, acc)


def audit_bundle(
    source_dir: Path,
    *,
    exclude_patterns: list[str] | None = None,
    detector: OkfDetector | None = None,
    example_cap: int = 20,
) -> OkfAuditReport:
    """Audit the vault's OKF conformance from disk (design §4; #962).

    Pure disk I/O, index-independent (the detection-probe pattern): each
    file is read up to :data:`_MAX_READ_CHARS` characters — frontmatter
    always fits; a wikilink beyond the cap in a pathological note goes
    uncounted. The index's effective exclude patterns double as the audit
    whitelist, so known-nonconforming zones (convention files, configured
    excludes) are skipped via existing config.

    Args:
        source_dir: Root directory of the markdown vault.
        exclude_patterns: Effective vault exclude patterns (audit
            whitelist).
        detector: Optional detection probe for reporting mode/version
            state; ``None`` reports an inactive, mode-``"off"``-like state.
        example_cap: Maximum example paths kept per finding.

    Returns:
        The audit report. Empty or missing vault directories yield an
        all-zero report rather than an error.

    Raises:
        OSError: If the vault directory cannot be statted (#1625).
    """
    from markdown_vault_mcp.utils import is_path_excluded
    from markdown_vault_mcp.utils.fs import iter_markdown_files

    state = (
        detector.state()
        if detector is not None
        else OkfState(mode="off", declared_version=None, active=False)
    )
    excludes = list(exclude_patterns or [])
    acc = _AuditCounters(example_cap)
    paths = (
        sorted(
            p.relative_to(source_dir).as_posix()
            for p in iter_markdown_files(source_dir, excludes)
        )
        if is_directory(source_dir)
        else []
    )
    for rel in paths:
        if is_path_excluded(rel, excludes):
            continue
        raw = _read_capped(source_dir / rel, rel)
        if raw is not None:
            _audit_file(rel, raw, acc)

    return OkfAuditReport(
        mode=state.mode,
        declared_version=state.declared_version,
        active=state.active,
        total_notes=acc.total,
        conformant_notes=acc.conformant,
        missing_type=acc.missing_type.finding(),
        unparseable_frontmatter=acc.unparseable.finding(),
        misplaced_okf_version=acc.misplaced.finding(),
        unknown_status=acc.unknown_status.finding(),
        log_heading_shape=acc.log_shape.finding(),
        root_index_missing=not acc.root_index_seen,
        wikilink_files=acc.wikilinks.finding(),
        missing_recommended=acc.missing_recommended.finding(),
        index_frontmatter=acc.index_frontmatter.finding(),
    )


# --- Phase 4 migration transforms (#963): pure content builders -------------


@dataclass(frozen=True)
class OkfConvertResult:
    """Result of the wikilink-to-markdown-link conversion (#963).

    Attributes:
        files_changed: Notes whose body was rewritten.
        links_converted: Wikilink occurrences turned into markdown links.
        links_skipped: Unresolvable wikilink occurrences left untouched
            (their target is not indexed, so no root-absolute path exists).
            A wikilink naming an attachment is not a link and is not
            counted here (#1333).
        notes_scanned: Notes examined.
    """

    files_changed: int
    links_converted: int
    links_skipped: int
    notes_scanned: int


@dataclass(frozen=True)
class OkfIndexResult:
    """Result of generating a reserved ``index.md`` listing (#963).

    Attributes:
        path: Vault-relative path of the generated listing.
        entries: Notes and sub-folder pointers listed.
        frontmatter_preserved: Whether frontmatter already on the file was
            carried over. Not "the file has frontmatter": a file that had
            none is still written with the vault's required fields seeded
            (#1175), which reports ``False`` here.
        created: Subfolder ``index.md`` files written because the listing
            points at them and they did not exist (#1647), outermost first.
    """

    path: str
    entries: int
    frontmatter_preserved: bool
    created: tuple[str, ...] = ()


@dataclass(frozen=True)
class OkfLogResult:
    """Result of seeding a reserved ``log.md`` from git history (#963)."""

    path: str
    commits: int
    dates: int


def convert_wikilinks_to_markdown(content: str, outlinks: Any) -> tuple[str, int, int]:
    """Rewrite resolvable wikilinks in *content* as root-absolute md links.

    Only wikilinks whose target is indexed (``exists``) are converted, so
    the link graph is preserved edge-for-edge — a converted link points at
    the same resolved ``target_path`` the wikilink already resolved to.
    Unresolvable wikilinks are left as-is and counted as skipped; a
    wikilink naming an attachment (``![[pic.png]]``) is not a link at all,
    so it is left as-is and not counted (#1333). A resolved path and an
    alias are names, not markdown, and the two families differ on what a
    name may hold: the destination goes through
    :func:`~markdown_vault_mcp.utils.links.build_plain_destination` and the
    display text through
    :func:`~markdown_vault_mcp.utils.links.escape_link_text`, so a space,
    a ``#``, a parenthesis that will not parse, or a bracket survives the
    conversion as part of the name rather than changing what the link means
    (#1494, #1513). Interior whitespace and
    the table-cell ``\\|`` escape are not matched (the same limitation as
    the rename/move link-rewrite engine).

    Args:
        content: Raw note text (frontmatter included).
        outlinks: The note's outlinks (objects with ``link_type``,
            ``raw_target``, ``target_path``, ``link_text``, ``fragment``,
            ``exists``).

    Returns:
        ``(new_content, converted, skipped)`` — occurrence counts, not
        distinct-target counts.
    """
    converted = 0
    skipped = 0
    # Group resolvable wikilinks by raw_target: every occurrence of one
    # raw_target resolves to the same path/fragment, but each occurrence may
    # carry a different alias, so the display text is computed per match.
    by_target: dict[str, tuple[str, str | None]] = {}
    for link in outlinks:
        if link.link_type != "wikilink":
            continue
        if not link.exists:
            skipped += 1
            continue
        by_target.setdefault(link.raw_target, (link.target_path, link.fragment))
    for raw_target, (target_path, fragment) in by_target.items():
        default_display = raw_target
        if fragment and default_display.endswith("#" + fragment):
            default_display = default_display[: -(len(fragment) + 1)]

        def _replace(
            match: re.Match[str],
            *,
            tp: str = target_path,
            fg: str | None = fragment,
            fallback: str = default_display,
        ) -> str:
            alias = match.group(1)
            display = alias.strip() if alias and alias.strip() else fallback
            # A resolved path and an alias are names, not markdown: written
            # verbatim, a space ends the destination (#1494), a ``#`` or an
            # unbalanced paren re-points it, and a bracket in the alias ends
            # the link text (#1513).
            return f"[{escape_link_text(display)}](/{build_plain_destination(tp, fg)})"

        pattern = re.compile(r"\[\[" + re.escape(raw_target) + r"(?:\|([^\]]*))?\]\]")
        content, n = pattern.subn(_replace, content)
        converted += n
    return content, converted, skipped


@dataclass(frozen=True)
class ReservedFrontmatterPolicy:
    """Frontmatter the server's own generated reserved files must carry.

    ``index.md`` and ``log.md`` are written by the server, but the index gate
    is configured by the operator: with ``required_frontmatter`` set, a
    generated file carrying no frontmatter is a deterministic
    ``missing_frontmatter`` skip, so the bundle's own navigation and change
    history disappear from ``search`` and ``list_documents`` while staying
    readable from disk (#1174, #1175). The generators consult this policy so
    what they write satisfies the gate the same server enforces.

    The policy is deliberately *conditional*. With no required fields
    configured a reserved file needs no frontmatter to be indexed, and
    :meth:`build` returns ``None`` so the generators keep emitting the
    body-only files every existing vault already has on disk — closing the
    defect costs an unconfigured vault no churn.

    Attributes:
        title_field: The frontmatter key the indexer resolves titles from.
            The one required field given a derived value rather than a
            placeholder, since the server knows the title it just wrote.
        required_fields: The vault's configured ``required_frontmatter``.
    """

    title_field: str = "title"
    required_fields: tuple[str, ...] = ()

    def build(
        self, existing: Mapping[str, Any] | None, *, title: str
    ) -> dict[str, Any] | None:
        """Build the frontmatter for a generated reserved file.

        Existing keys always win, so a hand-authored title and the root
        ``index.md``'s ``okf_version`` declaration survive regeneration
        untouched and only genuinely absent required fields are added. A
        required field other than *title_field* is seeded as ``None``: the
        gate tests presence rather than value
        (:func:`~markdown_vault_mcp.scanner.parse_note_categorized`), and the
        server has nothing truthful to put there.

        ``okf_version`` is never synthesized. The conformance audit flags it
        on any file but the bundle root as ``misplaced``, so seeding it into
        a folder's generated index would trade one defect for another.

        Args:
            existing: The file's current frontmatter, or ``None`` when the
                file does not exist yet or carries none.
            title: Title for *title_field*, matching the H1 heading the body
                builders emit for the same file.

        Returns:
            The frontmatter mapping to write, or ``None`` when the file needs
            no frontmatter at all.
        """
        merged: dict[str, Any] = dict(existing or {})
        for field in self.required_fields:
            if field in merged:
                continue
            merged[field] = title if field == self.title_field else None
        return merged or None


def build_index_markdown(
    heading: str, entries: list[tuple[str, str, str | None]]
) -> str:
    """Build an OKF ``index.md`` progressive-disclosure listing.

    Args:
        heading: The H1 heading (bundle or folder name).
        entries: ``(title, root_absolute_path, description)`` per note,
            already ordered. Both the title and the path are *names*, not
            markdown: the path becomes a destination through
            :func:`~markdown_vault_mcp.utils.links.build_plain_destination`
            (#1494, #1513) and the title through
            :func:`~markdown_vault_mcp.utils.links.escape_link_text`, so an
            entry stays a link to its note whatever the note is called.
            ``description`` is emitted as written, being prose after the
            link rather than part of it.

    Returns:
        The markdown body (no frontmatter).
    """
    lines = [f"# {heading}", ""]
    for title, path, description in entries:
        line = f"- [{escape_link_text(title)}]({build_plain_destination(path)})"
        if description:
            line += f" - {description}"
        lines.append(line)
    return "\n".join(lines) + "\n"


def build_log_markdown(entries: Any) -> tuple[str, int, int]:
    """Build an OKF ``log.md`` from newest-first history entries.

    Args:
        entries: History entries (objects with ``timestamp`` ISO string,
            ``message``, ``short_sha``), newest first.

    Returns:
        ``(markdown, commit_count, date_count)``.
    """
    by_date: dict[str, list[Any]] = {}
    order: list[str] = []
    for entry in entries:
        date = str(entry.timestamp)[:10]
        if date not in by_date:
            by_date[date] = []
            order.append(date)
        by_date[date].append(entry)
    sections: list[str] = []
    for date in order:
        block = [f"## {date}", ""]
        block.extend(f"- **{c.message}** ({c.short_sha})" for c in by_date[date])
        sections.append("\n".join(block))
    header = f"# {OKF_LOG_TITLE}"
    body = f"{header}\n\n" + "\n\n".join(sections) + "\n" if sections else f"{header}\n"
    return body, sum(len(v) for v in by_date.values()), len(order)


def append_okf_log_entry(text: str | None, *, date: str, summary: str) -> str:
    """Append a dated bullet to an OKF ``log.md``, newest date section on top.

    The enforced-write convention-maintenance transform (design §6, phase 5b).
    A ``log.md`` is a newest-first change history of ``## YYYY-MM-DD`` sections;
    this inserts one ``- <summary>`` bullet for *date*:

    - When *text* is empty/``None`` (no ``log.md`` yet), a fresh log with a
      single dated section is returned.
    - When the newest section already carries *date*, the bullet is appended to
      the end of that section (keeping same-day entries together, in order).
    - Otherwise a new ``## <date>`` section is inserted directly after the
      ``# Log`` header so the newest day stays on top.

    Existing content — the header, older sections, and any hand-written prose
    under a date — is preserved verbatim; only the one bullet is inserted.

    Args:
        text: The current ``log.md`` **body**, frontmatter excluded, or
            ``None`` when the log does not exist yet. A caller holding raw
            file text takes the block off first
            (:func:`~markdown_vault_mcp.scanner.strip_frontmatter_block`):
            the result is written back as a body, so a block left in it is
            serialised under a second one (#1391).
        date: The ISO date (``YYYY-MM-DD``) of the entry's section.
        summary: The bullet text (without the leading ``- ``), e.g.
            ``"**Update**: wrote `guides/note.md`"``.

    Returns:
        The updated body (always newline-terminated).
    """
    heading = f"## {date}"
    bullet = f"- {summary}"
    if not text or not text.strip():
        return f"# {OKF_LOG_TITLE}\n\n{heading}\n\n{bullet}\n"
    lines = text.splitlines()
    first = next((i for i, line in enumerate(lines) if line.startswith("## ")), None)
    if first is not None and lines[first].strip() == heading:
        # Append to the existing newest-date section, before the next section.
        nxt = next(
            (i for i in range(first + 1, len(lines)) if lines[i].startswith("## ")),
            len(lines),
        )
        insert = nxt
        while insert - 1 > first and not lines[insert - 1].strip():
            insert -= 1
        lines.insert(insert, bullet)
        return "\n".join(lines) + "\n"
    # Insert a new newest-date section after the header (before any sections).
    head = lines[:first] if first is not None else lines
    rest = lines[first:] if first is not None else []
    head = list(head)
    while head and not head[-1].strip():
        head.pop()
    parts = [*head, "", heading, "", bullet]
    if rest:
        parts += ["", *rest]
    return "\n".join(parts) + "\n"


def okf_timestamp(now: _dt.datetime) -> str:
    """Spell an instant the way OKF's timestamp-valued keys require.

    UTC with the ``Z`` designator at seconds precision — the spec's own
    example form (``2026-06-30T14:00:00Z``; ``docs/design/reference/okf-v0.2.md``,
    "Trust"). One spelling for every deployment, and a *string*: a
    ``datetime`` value would be re-dumped by the YAML emitter as
    ``2026-06-30 14:00:00+00:00``, the corruption the spec's amendment names
    (#1372).

    Args:
        now: The instant to spell, timezone-aware.

    Returns:
        The ISO 8601 text.

    Raises:
        ValueError: If *now* carries no offset — it would be read as the
            host's local time and gain an offset the caller never stated.
    """
    if now.tzinfo is None:
        raise ValueError("okf_timestamp needs an aware datetime")
    return now.astimezone(_dt.UTC).replace(microsecond=0).isoformat()[:-6] + "Z"


def apply_okf_write_stamp(text: str, *, actor: str, now: _dt.datetime) -> str:
    """Stamp ``generated: {by, at}`` and clear ``verified`` on a note's frontmatter.

    The enforced-write layer's core transform (design §6). Operates on the final
    file text (frontmatter plus body), so it is uniform across the ``write``
    (frontmatter-param) and ``edit`` (raw-splice) paths. ``generated`` describes
    the current bytes and is overwritten with the instant of this write —
    "the content's last meaningful change" — so it moves on every content
    write; ``verified`` is dropped because a content change invalidates any
    prior attestation; ``sources`` and every other field are untouched.

    Args:
        text: The full note file text (frontmatter and body).
        actor: The provenance actor resolved by the caller — ``human:<subject>``
            for human attribution, else a tool actor such as
            ``markdown-vault-mcp/<version>``.
        now: The instant of the write, timezone-aware (spelled by
            :func:`okf_timestamp`).

    Returns:
        The stamped file text, or *text* unchanged when the resulting frontmatter
        is identical (the same actor and instant, no ``verified``) — so a
        repeated stamp keeps the note's exact bytes and YAML formatting.
    """
    post = parse_frontmatter(text)
    meta: dict[str, Any] = dict(post.metadata)
    new_meta: dict[str, Any] = dict(meta)
    new_meta["generated"] = {"by": actor, "at": okf_timestamp(now)}
    new_meta.pop("verified", None)
    if new_meta == meta:
        return text
    return fm.dumps(fm.Post(post.content, **new_meta))


def append_okf_verification(text: str, *, subject: str, now: _dt.datetime) -> str:
    """Append a ``human:<subject>`` entry to a note's ``verified`` list.

    The ``okf_verify`` tool's core transform (design §6): records an attributable
    human attestation, promoting the note's trust tier to ``human-reviewed``.
    Preserves all other frontmatter and the body verbatim; the entry keeps the
    ``{by, at}`` shape :func:`derive_trust_tier` reads.

    Args:
        text: The full note file text (frontmatter and body).
        subject: The human verifier's subject (without the ``human:`` prefix),
            or ``local`` for a confirmed review without human identity claims.
        now: The instant of the verification, timezone-aware (spelled by
            :func:`okf_timestamp`).

    Returns:
        The note text with the appended verification.
    """
    post = parse_frontmatter(text)
    meta: dict[str, Any] = dict(post.metadata)
    verified = list(verified_entries(meta))
    verified.append({"by": f"{_HUMAN_ACTOR_PREFIX}{subject}", "at": okf_timestamp(now)})
    meta["verified"] = verified
    return fm.dumps(fm.Post(post.content, **meta))
