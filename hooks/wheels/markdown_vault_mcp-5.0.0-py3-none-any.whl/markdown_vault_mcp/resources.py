"""MCP resource registrations for the markdown-vault-mcp server.

Call :func:`register_resources` after constructing the
:class:`~fastmcp.FastMCP` instance in
:func:`~markdown_vault_mcp.server.make_server`.

FastMCP 4's templated-resource screening is recorded in
``docs/design/reference/fastmcp-4.md``.
"""

from __future__ import annotations

import asyncio
import datetime
import functools
import json
import logging
from dataclasses import asdict
from typing import TYPE_CHECKING, Any

from fastmcp import FastMCP
from fastmcp.dependencies import CurrentContext, Depends
from fastmcp.exceptions import ResourceError
from fastmcp.resources import ResourceContent, ResourceResult
from fastmcp.server.context import Context

from markdown_vault_mcp.config import ProjectConfig
from markdown_vault_mcp.exceptions import InvalidRequestError
from markdown_vault_mcp.utils.serialization import toc_payload
from markdown_vault_mcp.vault import Vault

from ._icons import _TOOL_ICONS
from ._server_queryable import needs_queryable
from .domain import get_vault

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable


def _request_outcomes(
    fn: Callable[..., Awaitable[ResourceResult]],
) -> Callable[..., Awaitable[ResourceResult]]:
    """Report a URI the reader must change at INFO, not as a server fault.

    A templated resource reads what the URI names; a note that does not
    exist, a field that is not indexed or a vault without embeddings is the
    request's doing (#1608, #1599). ``ResourceError`` defaults to ERROR, so
    those are re-raised at INFO; anything else stays a fault.
    """

    @functools.wraps(fn)
    async def wrapper(*args: Any, **kwargs: Any) -> ResourceResult:
        try:
            return await fn(*args, **kwargs)
        except InvalidRequestError as exc:
            raise ResourceError(str(exc), log_level=logging.INFO) from None

    return wrapper


def _stale_resource(vault: Vault, contents: str, gen_before: int) -> ResourceResult:
    """Wrap a resource's JSON body with index-freshness metadata.

    Resources keep their bare JSON contents unchanged; freshness rides
    out-of-band in the MCP ``_meta`` field as ``index_stale``, retrievable
    via ``read_resource_mcp(uri).meta``. Resources do not expose a
    ``wait_for_pending_writes`` knob — a resource URI template binds only address path
    segments, with no mechanism for an ad-hoc control parameter — so they
    only signal: ``index_stale`` is True when a write landed during the read
    (``write_generation`` advanced past ``gen_before``) or the writer was
    non-idle at response time.

    The body is wrapped in an explicit ``application/json`` ``ResourceContent``
    so the declared MIME type survives — a bare ``str`` in ``ResourceResult``
    defaults to ``text/plain``, dropping the ``@mcp.resource`` MIME type.
    """
    index_stale = (vault.index.write_generation() != gen_before) or (
        not vault.index.is_drained()
    )
    return ResourceResult(
        contents=[ResourceContent(contents, mime_type="application/json")],
        meta={"index_stale": index_stale},
    )


def _get_config(ctx: Context) -> ProjectConfig:
    """Retrieve the cached :class:`~markdown_vault_mcp.config.ProjectConfig` from lifespan context.

    Args:
        ctx: The current request context.

    Returns:
        The ``ProjectConfig`` stored by the lifespan hook.
    """
    from markdown_vault_mcp.domain import get_config

    return get_config(ctx)


def register_resources(mcp: FastMCP) -> None:
    """Register all 8 MCP resources on *mcp*.

    Args:
        mcp: The :class:`~fastmcp.FastMCP` instance to register resources on.
    """

    @mcp.resource(
        "config://vault", mime_type="application/json", icons=_TOOL_ICONS["stats"]
    )
    async def vault_config(
        ctx: Context = CurrentContext(),
        vault: Vault = Depends(get_vault),
    ) -> ResourceResult:
        """The vault's settings: read-only mode, indexed fields, exclusions, OKF state."""
        config = _get_config(ctx)
        gen_before = vault.index.write_generation()
        stats = await asyncio.to_thread(vault.reader.stats)
        convention_folders = await asyncio.to_thread(vault.conventions.list_folders)
        okf_state = await asyncio.to_thread(vault.okf.state)
        return _stale_resource(
            vault,
            json.dumps(
                {
                    "source_dir": str(config.source_dir),
                    "read_only": config.read_only,
                    "indexed_fields": config.indexing.indexed_frontmatter_fields or [],
                    "required_fields": config.indexing.required_frontmatter or [],
                    # The vault's *effective* patterns — configured plus the
                    # conventions-file patterns Vault derives — so the
                    # reported list matches actual index behavior.
                    "exclude_patterns": list(vault.exclude_patterns or []),
                    "templates_folder": config.content.templates_folder,
                    "conventions_file": config.content.conventions_file,
                    "convention_folders": convention_folders,
                    # OKF: configured mode plus the vault-side detection
                    # outcome (okf_version declared in the root index.md).
                    "okf_mode": okf_state.mode,
                    "okf_active": okf_state.active,
                    "okf_declared_version": okf_state.declared_version,
                    "semantic_search_available": stats.semantic_search_available,
                    "attachment_extensions": stats.attachment_extensions,
                }
            ),
            gen_before,
        )

    @mcp.resource(
        "stats://vault", mime_type="application/json", icons=_TOOL_ICONS["stats"]
    )
    async def vault_stats(
        vault: Vault = Depends(get_vault),
    ) -> ResourceResult:
        """Vault statistics: note, chunk and link counts and search capabilities."""
        gen_before = vault.index.write_generation()
        result = await asyncio.to_thread(vault.reader.stats)
        return _stale_resource(vault, json.dumps(asdict(result)), gen_before)

    @mcp.resource(
        "tags://vault", mime_type="application/json", icons=_TOOL_ICONS["list_tags"]
    )
    async def vault_tags(
        vault: Vault = Depends(get_vault),
    ) -> ResourceResult:
        """Every value of every indexed frontmatter field, grouped by field."""
        gen_before = vault.index.write_generation()
        stats = await asyncio.to_thread(vault.reader.stats)
        tag_lists: list[list[str]] = list(
            await asyncio.gather(
                *[
                    asyncio.to_thread(vault.reader.list_tags, field)
                    for field in stats.indexed_frontmatter_fields
                ]
            )
        )
        grouped: dict[str, list[str]] = dict(
            zip(stats.indexed_frontmatter_fields, tag_lists, strict=False)
        )
        return _stale_resource(vault, json.dumps(grouped), gen_before)

    @mcp.resource(
        "tags://vault/{field}",
        mime_type="application/json",
        icons=_TOOL_ICONS["list_tags"],
    )
    @_request_outcomes
    async def vault_tags_by_field(
        field: str,
        vault: Vault = Depends(get_vault),
    ) -> ResourceResult:
        """Every value of one indexed frontmatter field."""
        gen_before = vault.index.write_generation()
        values = await asyncio.to_thread(vault.reader.list_tags, field)
        return _stale_resource(vault, json.dumps(values), gen_before)

    @mcp.resource(
        "folders://vault",
        mime_type="application/json",
        icons=_TOOL_ICONS["list_folders"],
    )
    async def vault_folders(
        vault: Vault = Depends(get_vault),
    ) -> ResourceResult:
        """Every folder in the vault that holds notes."""
        gen_before = vault.index.write_generation()
        folders = await asyncio.to_thread(vault.reader.list_folders)
        return _stale_resource(vault, json.dumps(folders), gen_before)

    @mcp.resource(
        "toc://vault/{path}", mime_type="application/json", icons=_TOOL_ICONS["read"]
    )
    @needs_queryable()
    @_request_outcomes
    async def vault_toc(
        path: str,
        vault: Vault = Depends(get_vault),
    ) -> ResourceResult:
        """Heading outline of a note, or of up to 200 notes under a folder."""
        gen_before = vault.index.write_generation()
        toc = await asyncio.to_thread(vault.reader.get_toc, path)
        return _stale_resource(vault, json.dumps(toc_payload(toc)), gen_before)

    @mcp.resource(
        "similar://vault/{path}",
        mime_type="application/json",
        icons=_TOOL_ICONS["get_similar"],
    )
    @needs_queryable()
    @_request_outcomes
    async def vault_similar(
        path: str,
        vault: Vault = Depends(get_vault),
    ) -> ResourceResult:
        """The 10 notes closest in meaning to a note."""
        gen_before = vault.index.write_generation()
        results = await asyncio.to_thread(vault.reader.get_similar, path, limit=10)
        return _stale_resource(
            vault, json.dumps([asdict(r) for r in results]), gen_before
        )

    @mcp.resource(
        "recent://vault",
        mime_type="application/json",
        icons=_TOOL_ICONS["get_recent"],
    )
    async def vault_recent(
        vault: Vault = Depends(get_vault),
    ) -> ResourceResult:
        """The 20 most recently modified notes."""
        gen_before = vault.index.write_generation()
        results = await asyncio.to_thread(vault.reader.get_recent, limit=20)
        items: list[dict[str, Any]] = [
            {
                **asdict(r),
                "modified_at_iso": datetime.datetime.fromtimestamp(
                    r.modified_at, tz=datetime.UTC
                ).isoformat(),
            }
            for r in results
        ]
        return _stale_resource(vault, json.dumps(items), gen_before)
