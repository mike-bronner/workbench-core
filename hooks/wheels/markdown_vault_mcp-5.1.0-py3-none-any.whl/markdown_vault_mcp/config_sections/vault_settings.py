"""Settings object for :class:`~markdown_vault_mcp.vault.Vault` construction.

:class:`VaultSettings` groups every *config-derived* ``Vault.__init__``
parameter into one frozen dataclass so the constructor no longer needs one
keyword per knob (#1158).  The collaborator objects —
``embedding_provider``, ``summarizer``, ``git_strategy``, ``on_write``, and
``chunk_strategy`` — stay explicit ``Vault`` keywords; the server path resolves
providers and the Git strategy in :class:`~markdown_vault_mcp.config_sections._assembly.VaultInstances`.

Field defaults preserve the established *library* defaults, which is why ``chunk_overlap_words`` defaults to ``0`` here while
:class:`~markdown_vault_mcp.config_sections.search.SearchConfig` defaults to
``40``, and ``read_only`` defaults to ``True`` while the server env default is
``False`` — the two tiers are distinct on purpose (see ``read_only`` below).
"""

from __future__ import annotations

import dataclasses
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Sequence
    from pathlib import Path

    from markdown_vault_mcp.config import ProjectConfig

#: Where the state file defaulted to before #1693, under the vault root.
#: Nothing writes there now; ``Vault`` copies a leftover file into the new
#: location when that is missing, and reports it at each start while present.
#: ``markdown_vault_mcp.vault`` re-exports both names.
_DEFAULT_STATE_SUBDIR = ".markdown_vault_mcp"
_DEFAULT_STATE_FILENAME = "state.json"
#: Suffix of the default state file beside the index: ``index.db`` gives
#: ``index.db.state.json``. The whole file name, so ``notes.db`` and
#: ``notes.sqlite`` in one directory never share a state file.
_DEFAULT_STATE_SUFFIX = ".state.json"
#: Suffix of the default embeddings base beside the index. The base is the
#: index file name with its dots made dashes: ``index.db`` gives
#: ``index-db-embeddings``, whose sidecars are ``index-db-embeddings.npy`` and
#: ``.json``. Dot-free, so ``Path.with_suffix`` adds to the whole name instead
#: of cutting it at a dot (#819), and built from the whole name, so
#: ``notes.db`` and ``notes.sqlite`` never share vectors.
_DEFAULT_EMBEDDINGS_SUFFIX = "-embeddings"


@dataclasses.dataclass(frozen=True)
class VaultSettings:
    """Config-derived construction settings for a :class:`~markdown_vault_mcp.vault.Vault`.

    One field per configuration knob, preserving the names, types, and
    defaults of the constructor keywords removed in #1225, plus
    ``owns_index_files``, which only a library caller sets. Construct
    directly for library use, or from a served config via
    :meth:`from_project_config` /
    :func:`~markdown_vault_mcp.config_sections._assembly.to_vault_settings`.

    Attributes:
        index_path: Path to the SQLite index file.  ``None`` (default) uses
            an in-memory database that is discarded when the object is
            collected.
        embeddings_path: Base path for the ``{path}.npy`` and
            ``{path}.json`` sidecar files.  ``None`` (default) puts them
            beside ``index_path`` as ``{index name}-embeddings`` (dots made
            dashes: ``index-db-embeddings``), or keeps
            the vectors in memory without an index path (#1708). Semantic
            search is on whenever ``Vault`` is given an embedding provider.
        owns_index_files: When ``True`` (default), this vault owns the
            index files on disk: the SQLite index, the vector sidecar and the
            state file. ``False`` is for a process that reads files another
            one owns, such as the CLI ``search`` reading a running server's
            index, and leaves them as they are: an on-disk index opens
            read-only and ranks with the weights stored in it (#1758), a
            search that finds the vector sidecar incompatible or corrupt
            raises :exc:`~markdown_vault_mcp.exceptions.VectorIndexUnusableError`
            instead of rebuilding it (#1734), and a pre-#1693 state file is
            not copied into place. An in-memory index is this process's own
            and stays writable. A library setting with no configuration knob
            behind it.
        read_only: When ``True`` (default), write operations raise
            :exc:`~markdown_vault_mcp.exceptions.ReadOnlyError`.

            This library default deliberately stays ``True`` even though
            the server's ``MARKDOWN_VAULT_MCP_READ_ONLY`` now defaults to
            ``False`` (#1113). They are separate tiers: the operator default
            is a product decision about what an installed server should do,
            while this one is a fail-safe for a downstream Python consumer
            who constructs a ``Vault`` without naming the argument. Keeping
            it costs nothing — the server path always passes the value
            explicitly through ``to_vault_settings`` — and moving it would be
            an independent breaking change to the public library interface.
        write_protect_existing: When ``True``, a write that would overwrite an
            existing file without an *if_match* etag raises
            :exc:`~markdown_vault_mcp.exceptions.DocumentExistsError`
            (default ``False``, i.e. writes overwrite unconditionally).
        report_unresolved_links: When ``True``, the ``write`` / ``edit`` /
            ``append`` MCP tools add ``unresolved_links`` to their response:
            the links the call added that ``get_broken_links`` reports
            (default ``False``, #1725).  Read by the tool layer through
            :attr:`~markdown_vault_mcp.vault.Vault.report_unresolved_links`;
            library callers ask per call instead.
        state_path: Path to the hash-state JSON file used by
            :class:`~markdown_vault_mcp.tracker.ChangeTracker`.  Defaults to
            ``{index file name}.state.json`` beside ``index_path``, and to
            memory when the index is; never inside the vault (#1693).
        indexed_frontmatter_fields: Frontmatter keys whose values are
            promoted to the ``document_tags`` table for structured filtering.
        required_frontmatter: If provided, documents missing any listed field
            are excluded from the index entirely.
        git_pull_interval_s: Interval in seconds for periodic pulls. ``0``
            disables the pull loop.
        exclude_patterns: Glob patterns (relative to *source_dir*) for files
            and directories to exclude from indexing.
        attachment_extensions: Allowlist of extensions for binary
            attachments, in any case and with or without leading dots
            (``"pdf"``, ``"PDF"`` and ``".pdf"`` are the same type).
            ``["*"]`` accepts all extensions. Also decides which link
            targets are attachment references rather than note links
            (#1333), so it is recorded as index provenance and a change
            rebuilds the index once.
        max_attachment_size_mb: Attachment context-size cap in megabytes,
            enforced by the ``read`` / ``write`` / ``fetch`` MCP tools (not by
            the vault library). ``0`` disables the limit (default ``1.0``).
        max_note_read_bytes: Maximum bytes returned by full-document reads.
            ``0`` disables the limit (default ``262144``, i.e. 256 KB).
        chunks_per_file: Search results kept per file before grouping.
        snippet_words: Snippet truncation length in words.
        length_downweight_alpha: Length-downweight exponent for ranking.
        default_search_mode: Mode used when ``search`` gets no ``mode``.
        max_chunk_words: Word cap for the default heading chunker.
        max_chunk_chars: Character cap for the default heading chunker.
        max_chunk_chars_override: Explicit operator char-cap override — the
            stable warm-restart key (#649).
        chunk_overlap_words: Overlap carried between split chunks.
        summarize_max_notes: Cap on notes summarised per ``summarize`` call
            (subtree expansion is truncated to this many notes; default 50).
        summarize_max_input_chars: Aggregate cap on note characters sent to the
            summarization backend per call (default 200000).
        title_field: Frontmatter key consulted first when resolving document
            titles (default ``"title"``; falls back to ``title`` → first H1
            → filename stem).
        searchable_frontmatter_fields: Frontmatter keys whose scalar values
            are keyword-searchable via the FTS ``summary`` column and —
            because configuring this activates format v2 — prefixed to
            first-chunk embedding text (triggering a one-time re-embed).
            ``None`` disables both.
        embed_context: When ``True``, forces format v2 (document title +
            chunk heading enrichment) even with no
            ``searchable_frontmatter_fields``; any searchable field also
            activates v2 (default ``False`` — raw chunk content).
        embedding_batch_size: Maximum number of chunk texts sent to the
            embedding provider per call in the cold-build, convergence, and
            inline-reindex paths (default ``4``).
        folder_weights: Folder-prefix score multipliers applied to search
            results just before file grouping (``None`` disables).
        fts_weights: Per-column BM25 weights persisted into the FTS5 rank
            configuration (``None`` or all-``1.0`` keeps the default).
        conventions_file: Well-known per-folder conventions filename resolved
            by :attr:`~markdown_vault_mcp.vault.Vault.conventions`
            (default ``"_conventions.md"``); ``None``
            disables folder conventions. When set, the filename is
            automatically appended to *exclude_patterns* (in both fnmatch
            forms) so convention files stay out of the index while remaining
            disk-readable. Must not contain fnmatch metacharacters.
        okf_mode: OKF (Open Knowledge Format) read-semantics mode —
            ``"auto"`` (default; follow the vault's ``okf_version``
            declaration in the root ``index.md``), ``"off"``, or ``"on"``.
            When read semantics are active at construction time, the OKF
            scalar keys (``type`` / ``status`` / ``stale_after``) extend the
            effective *indexed_frontmatter_fields* set. See
            :attr:`~markdown_vault_mcp.vault.Vault.okf`.
        okf_write: Enable the OKF enforced-write layer.
    """

    index_path: Path | None = None
    embeddings_path: Path | None = None
    read_only: bool = True
    write_protect_existing: bool = False
    report_unresolved_links: bool = False
    state_path: Path | None = None
    indexed_frontmatter_fields: Sequence[str] | None = None
    required_frontmatter: Sequence[str] | None = None
    git_pull_interval_s: int = 0
    exclude_patterns: Sequence[str] | None = None
    attachment_extensions: Sequence[str] | None = None
    max_attachment_size_mb: float = 1.0
    max_note_read_bytes: int = 262144
    chunks_per_file: int = 2
    snippet_words: int = 200
    length_downweight_alpha: float = 0.25
    default_search_mode: str = "auto"
    max_chunk_words: int = 400
    max_chunk_chars: int | None = None
    max_chunk_chars_override: int | None = None
    chunk_overlap_words: int = 0
    summarize_max_notes: int = 50
    summarize_max_input_chars: int = 200_000
    title_field: str = "title"
    searchable_frontmatter_fields: Sequence[str] | None = None
    embed_context: bool = False
    embedding_batch_size: int = 4
    folder_weights: dict[str, float] | None = None
    fts_weights: dict[str, float] | None = None
    conventions_file: str | None = "_conventions.md"
    okf_mode: str = "auto"
    okf_write: bool = False
    owns_index_files: bool = True

    @classmethod
    def from_project_config(
        cls,
        config: ProjectConfig,
        *,
        embedding_context_length: int | None = None,
    ) -> VaultSettings:
        """Map a served :class:`ProjectConfig` onto vault settings.

        Maps server configuration names onto library setting names
        (``searchable_frontmatter`` → ``searchable_frontmatter_fields``,
        ``default_mode`` → ``default_search_mode``) and the weight-map
        tuple → dict conversions (#639).  The git pull interval resolves the
        same way the git-strategy assembly does: ``config.git.pull_interval_s``
        only when a remote is configured (repo URL or token), else ``0``.

        Args:
            config: The served project configuration.
            embedding_context_length: Token context length of the resolved
                embedding provider, used to derive ``max_chunk_chars``
                (``None`` — no provider — falls back to the bounded ceiling).
                Prefer
                :func:`~markdown_vault_mcp.config_sections._assembly.to_vault_settings`,
                which resolves the provider and threads this automatically.

        Returns:
            The mapped :class:`VaultSettings`.
        """
        # Function-local import: _assembly imports the git package at module
        # level; keep this module import-light and cycle-free.
        from markdown_vault_mcp.config_sections._assembly import derive_max_chunk_chars

        git = config.git
        return cls(
            index_path=config.indexing.index_path,
            embeddings_path=config.indexing.embeddings_path,
            read_only=config.read_only,
            write_protect_existing=config.write_protect_existing,
            report_unresolved_links=config.report_unresolved_links,
            state_path=config.indexing.state_path,
            indexed_frontmatter_fields=config.indexing.indexed_frontmatter_fields,
            required_frontmatter=config.indexing.required_frontmatter,
            # Mirrors the git-strategy assembly: only the managed and
            # token-compat modes run the pull loop; commit-only mode never
            # pulls, whatever the (defaulted) configured interval says.
            git_pull_interval_s=(
                git.pull_interval_s
                if (git.repo_url is not None or git.token is not None)
                else 0
            ),
            exclude_patterns=config.indexing.exclude_patterns,
            attachment_extensions=config.content.attachment_extensions,
            max_attachment_size_mb=config.content.max_attachment_size_mb,
            max_note_read_bytes=config.content.max_note_read_bytes,
            chunks_per_file=config.search.chunks_per_file,
            snippet_words=config.search.snippet_words,
            length_downweight_alpha=config.search.length_downweight_alpha,
            default_search_mode=config.search.default_mode,
            max_chunk_words=config.search.max_chunk_words,
            max_chunk_chars=derive_max_chunk_chars(
                context_length=embedding_context_length,
                override=config.search.max_chunk_chars_override,
            ),
            max_chunk_chars_override=config.search.max_chunk_chars_override,
            chunk_overlap_words=config.search.chunk_overlap_words,
            summarize_max_notes=config.summarize.max_notes,
            summarize_max_input_chars=config.summarize.max_input_chars,
            title_field=config.indexing.title_field,
            searchable_frontmatter_fields=config.indexing.searchable_frontmatter,
            embed_context=config.embeddings.embed_context,
            embedding_batch_size=config.embeddings.embedding_batch_size,
            # Weight maps are stored as frozen sorted tuples on the config
            # (#639); the Vault API takes plain dicts.
            folder_weights=(
                dict(config.search.folder_weights)
                if config.search.folder_weights is not None
                else None
            ),
            fts_weights=(
                dict(config.search.fts_weights)
                if config.search.fts_weights is not None
                else None
            ),
            conventions_file=config.content.conventions_file,
            okf_mode=config.content.okf_mode,
            okf_write=config.content.okf_write,
        )

    def effective_indexed_fields(self, *, okf_active: bool) -> list[str]:
        """Return the indexed-frontmatter set, OKF-extended when active.

        When OKF read semantics are active at construction time, the OKF
        scalar keys (``type`` / ``status`` / ``stale_after``) join the
        configured set so ``document_tags`` carries them (design okf.md §3).

        Args:
            okf_active: Whether the vault's OKF detection probe reports
                active read semantics.

        Returns:
            The effective field list (possibly empty, never ``None``).
        """
        # Imported here rather than at module scope: `markdown_vault_mcp.okf`
        # imports `python-frontmatter`, which is outside the config import
        # floor this module is bound by (see `_assembly`'s module docstring).
        from markdown_vault_mcp.okf import OKF_INDEXED_FIELDS

        fields = list(self.indexed_frontmatter_fields or [])
        if okf_active:
            fields.extend(key for key in OKF_INDEXED_FIELDS if key not in fields)
        return fields

    def effective_exclude_patterns(self) -> Sequence[str] | None:
        """Return the exclusion patterns with the conventions-file derivation.

        When a conventions file is configured, both fnmatch forms are
        appended (``name`` and ``**/name`` — the ``**/`` form alone does not
        match a root-level file) so convention files stay out of the index
        while remaining disk-readable.  Without one, the configured patterns
        pass through unchanged (possibly ``None``).

        Returns:
            The effective pattern sequence, or ``None`` when nothing is
            excluded.

        Raises:
            ValueError: If *conventions_file* contains fnmatch
                metacharacters (which would invert the exclusion).
        """
        if not self.conventions_file:
            return self.exclude_patterns
        if any(ch in self.conventions_file for ch in "*?[]"):
            raise ValueError(
                "conventions_file must not contain fnmatch metacharacters "
                f"(*, ?, [, ]), got {self.conventions_file!r}"
            )
        return [
            *(self.exclude_patterns or []),
            self.conventions_file,
            f"**/{self.conventions_file}",
        ]

    def effective_embeddings_path(self) -> Path | None:
        """Return the embeddings sidecar base, defaulting beside the index (#1708).

        Returns:
            The explicit ``embeddings_path``; else ``{index name}-embeddings``
            with the name's dots made dashes,
            beside an on-disk ``index_path``; else ``None``, meaning the
            vectors are held in memory and rebuilt at each start.
        """
        if self.embeddings_path is not None:
            return self.embeddings_path
        if self.index_path is not None and str(self.index_path) != ":memory:":
            base_name = self.index_path.name.replace(".", "-")
            return self.index_path.with_name(f"{base_name}{_DEFAULT_EMBEDDINGS_SUFFIX}")
        return None

    def effective_state_path(self, source_dir: Path) -> Path | None:
        """Return the hash-state path, defaulting beside the index (#1693).

        The state records which notes the index holds, so it lives with the
        index and never inside the vault: with no on-disk index there is
        nothing for a state file to describe, and the state stays in memory.

        Args:
            source_dir: The vault root. Unused since the default left the
                vault (#1693); kept so existing calls keep working.

        Returns:
            The explicit ``state_path``; else ``{index file name}.state.json``
            beside an on-disk ``index_path``; else ``None``, meaning in memory
            (no ``index_path``, or SQLite's ``:memory:``).
        """
        del source_dir
        if self.state_path is not None:
            return self.state_path
        if self.index_path is not None and str(self.index_path) != ":memory:":
            return self.index_path.with_name(
                f"{self.index_path.name}{_DEFAULT_STATE_SUFFIX}"
            )
        return None
