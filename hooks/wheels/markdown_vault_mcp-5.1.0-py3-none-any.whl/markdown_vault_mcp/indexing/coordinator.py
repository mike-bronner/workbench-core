"""Index-write orchestration: owns the IndexWriter and the readiness state.

`IndexWriteCoordinator` exposes the build entry points and composes
:class:`BuildLifecycle`, which owns build attempts and publishes their outcomes
to :class:`ReadinessState`. The coordinator owns non-build async error capture,
status/drain observation and dirty-path routing. `Vault` constructs one coordinator
and delegates to it; the
coordinator constructs, starts, and closes the single-owner
:class:`~markdown_vault_mcp.indexing.index_writer.IndexWriter` thread.
"""

from __future__ import annotations

import logging
import sqlite3
import time
from concurrent.futures import CancelledError, Future
from typing import TYPE_CHECKING, Any

from markdown_vault_mcp.exceptions import IndexUnavailableError
from markdown_vault_mcp.fts_index import INDEX_SEMANTICS_VERSION
from markdown_vault_mcp.indexing.build_lifecycle import BuildLifecycle
from markdown_vault_mcp.indexing.index_writer import (
    BuildEmbeddings,
    IndexWriter,
    ProcessDirtyPaths,
    ReindexAll,
    WriterContext,
    run_build_embeddings,
    run_flush_dirty_embeddings,
    run_process_dirty_paths,
    run_reindex_all,
)
from markdown_vault_mcp.indexing.readiness import ReadinessState

if TYPE_CHECKING:
    import threading
    from collections.abc import Iterable
    from pathlib import Path

    from markdown_vault_mcp.interfaces import KeywordIndex
    from markdown_vault_mcp.managers.index import IndexManager
    from markdown_vault_mcp.types import IndexStats, ReindexResult

logger = logging.getLogger(__name__)


class IndexWriteCoordinator:
    """Owns the IndexWriter thread and the build-readiness state machine."""

    def __init__(
        self,
        *,
        fts: KeywordIndex,
        index_mgr: IndexManager,
        index_path: Path | str | None,
        file_write_lock: threading.RLock,  # noqa: ARG002 — retained constructor API
        embed_model_name: str | None = None,
        max_chunk_chars_override: int | None = None,
        title_field: str = "title",
        searchable_fields: str = "",
        indexed_frontmatter_fields: str = "",
        attachment_extensions: str = "",
    ) -> None:
        self._fts = fts
        self._index_path = index_path
        # file_write_lock remains a constructor compatibility parameter; build
        # scheduling no longer borrows the file-mutation lock.
        # Current embedding model + explicit char-cap override, compared
        # against the values recorded in FTS meta to decide whether a warm
        # restart is valid (#649). These are the STABLE inputs to the derived
        # chunk cap; comparing them (not the derived cap) avoids flapping when
        # the model context is read transiently differently.
        self._embed_model_name = embed_model_name
        self._max_chunk_chars_override = max_chunk_chars_override
        # Curated-ranking provenance: a flipped title field or searchable
        # frontmatter field set changes FTS row contents (titles / the
        # summary column), so it must reject the warm-restart short-circuit
        # the same way a model change does. ``searchable_fields`` is the
        # comma-joined canonical form ("" when none configured).
        self._title_field = title_field
        self._searchable_fields = searchable_fields
        # Structured-filter provenance: the indexed (document_tags)
        # frontmatter field set, tracked separately from searchable_fields
        # so an INDEXED_FIELDS-only change also rejects the warm-restart
        # short-circuit (#927) even when SEARCHABLE_FIELDS is explicitly
        # overridden and would otherwise stay unchanged.
        self._indexed_frontmatter_fields = indexed_frontmatter_fields
        # Link-extraction provenance: the attachment allowlist decides whether
        # a reference is a link row at all (#1333), so a change to it changes
        # the stored rows of notes whose bytes never moved. Hash-based
        # reindexing would never re-parse those notes, so without this key
        # the warm restart kept serving the previous interpretation forever.
        # Canonical form ("" for the default set, else a sorted JSON list).
        self._attachment_extensions = attachment_extensions
        self._readiness = ReadinessState()
        self._builds = BuildLifecycle(fts, self._readiness, self._can_warm_start)
        # Per-async-variant error capture (#561), surfaced via get_index_status.
        self._last_reindex_error: BaseException | None = None
        self._last_build_embeddings_error: BaseException | None = None
        self._writer_ctx = WriterContext(index_manager=index_mgr)
        self._writer = IndexWriter(
            runners={
                "build_index": self._builds.run,
                "reindex_all": run_reindex_all,
                "build_embeddings": run_build_embeddings,
                "process_dirty_paths": run_process_dirty_paths,
                "flush_dirty_embeddings": run_flush_dirty_embeddings,
            },
            ctx=self._writer_ctx,
        )
        self._writer_ctx.writer = self._writer
        self._writer.start()

    @property
    def writer(self) -> IndexWriter:
        """The owned writer (accessor for the search-rebuild path and tests)."""
        return self._writer

    # ------------------------------------------------------------------
    # Readiness
    # ------------------------------------------------------------------

    def is_queryable(self) -> bool:
        """Return True when the structural preconditions for FTS queries hold.

        A captured build error does NOT demote queryability: it is
        diagnostic state surfaced via :meth:`get_index_status`, not a gate.
        """
        return self._readiness.is_queryable()

    def require_built(self) -> None:
        """Raise :exc:`IndexUnavailableError` if :meth:`build_index` has not run."""
        self._readiness.require_built()

    def wait_until_queryable(self, timeout: float | None = None) -> None:
        """Block until the FTS index is queryable, or raise.

        A captured build error does NOT block here; it is diagnostic state
        surfaced via :meth:`get_index_status`. Raises only on timeout, a
        failed build, or a never-scheduled build.

        Raises:
            IndexUnavailableError: timeout expired (``reason="timeout"``), a
                build ran and failed (``reason="build_failed"``), or no build
                was ever scheduled (``reason="never_built"``).
        """
        if not self._readiness.wait(timeout):
            raise IndexUnavailableError(
                f"Index build still in progress; timed out after {timeout}s.",
                reason="timeout",
            )
        # The done-event is set: distinguish a build that ran and failed
        # (build_failed) from one never scheduled (never_built) (#586).
        self._readiness.require_built()

    def get_index_status(self) -> dict[str, Any]:
        """Return a non-blocking snapshot of build + writer state (eleven keys)."""
        fields = self._readiness.status_fields()
        documents_indexed_error: str | None = None
        try:
            documents_indexed = len(self._fts.list_notes())
        except sqlite3.Error as exc:
            # Failed FTS read (locked/corrupt/closed) != empty index — surface why (#583).
            logger.warning("get_index_status_list_notes_failed", exc_info=True)
            documents_indexed = 0
            documents_indexed_error = str(exc)
        result = {
            "status": fields["status"],
            "documents_indexed": documents_indexed,
            "documents_indexed_error": documents_indexed_error,
            "error": fields["error"],
            "last_reindex_error": (
                str(self._last_reindex_error)
                if self._last_reindex_error is not None
                else None
            ),
            "last_build_embeddings_error": (
                str(self._last_build_embeddings_error)
                if self._last_build_embeddings_error is not None
                else None
            ),
        }
        result.update(self._writer.get_status())
        return result

    # ------------------------------------------------------------------
    # Drain observation
    # ------------------------------------------------------------------

    def is_drained(self) -> bool:
        """Return True iff the writer has no pending or in-flight work."""
        status = self._writer.get_status()
        return (
            status["queue_depth"] == 0
            and status["in_flight"] is None
            and status["dirty_paths"] == 0
            and status["dirty_embeddings"] == 0
        )

    def write_generation(self) -> int:
        """Return the writer's monotonic completion counter."""
        return int(self._writer.get_status()["write_generation"])

    def prepare_index_read(self, timeout: float = 60.0) -> None:
        """Refresh prior writes before an index-dependent file mutation (#1464).

        Submit through the single-owner FIFO, including a retry of dirty paths
        retained after an earlier failed refresh. Waiting on this job's Future
        propagates failures; an idle queue alone cannot establish success.
        Follow-up embedding jobs need not finish. Call before taking a file
        write lock; this is a boundary for prior writes, not a snapshot against
        concurrent edits. A queued initial build runs first; this refresh does
        not require or initiate a build for disk-only library operations.
        The captured build attempt must succeed, including marker publication,
        before index data is used. Failed, cancelled and interrupted attempts
        reject every dependent mutation. An unscheduled build remains optional
        for disk-only operations. Build and refresh share one deadline.

        Args:
            timeout: Maximum total seconds for refresh and build finalization.

        Raises:
            TimeoutError: If the refresh does not finish within the budget.
            IndexUnavailableError: If the preceding build did not succeed.
            Exception: If the index writer rejects or fails the refresh.
        """
        deadline = time.monotonic() + timeout
        build, future = self._builds.enqueue_refresh(self._writer)
        try:
            if build is not None:
                build.require_success(max(0.0, deadline - time.monotonic()))
            future.result(timeout=max(0.0, deadline - time.monotonic()))
        except TimeoutError as exc:
            if future.done() and not future.cancelled() and future.exception() is exc:
                raise
            future.cancel()
            raise TimeoutError(
                "Index refresh timed out; the dependent mutation was not started. "
                "Wait for the index writer and retry."
            ) from exc

    def wait_for_drain(self, timeout: float | None = None) -> bool:
        """Block until :meth:`is_drained`; ``True`` if drained, ``False`` on timeout."""
        deadline = None if timeout is None else time.monotonic() + timeout
        poll_interval = 0.05
        while True:
            if self.is_drained():
                return True
            if deadline is not None and time.monotonic() >= deadline:
                return False
            time.sleep(poll_interval)

    # ------------------------------------------------------------------
    # Synchronous builds
    # ------------------------------------------------------------------

    def _chunking_meta_matches(self) -> bool:
        """True when the stored build provenance matches this process.

        Compares the STABLE inputs to the FTS build's contents — the model
        name and the explicit ``MAX_CHUNK_CHARS`` override (the shared
        chunker's char-cap inputs, #649), plus the title field (which
        shapes FTS titles), the searchable frontmatter fields (which shape
        the ``summary`` column), the indexed frontmatter fields (which
        shape the ``document_tags`` structured-filter set, #927), and the
        attachment allowlist (which decides whether a reference is a link
        row, #1333) — never the runtime-derived cap. A genuine option change rejects the
        warm-restart short-circuit (cold rebuild); a derived cap that merely
        differs because the model context was read transiently differently
        (e.g. an Ollama instance briefly unreachable) changes no input, so
        it does NOT force a rebuild (avoid flapping).

        The recorded :data:`~markdown_vault_mcp.fts_index.INDEX_SEMANTICS_VERSION`
        is compared on the same footing (#1124). It is the one key that is
        not an operator input: it invalidates an index whose derived rows
        (links, chunks, tags) were produced by an older parse pipeline, which
        hash-based reindexing would otherwise never re-parse.

        Returns:
            ``True`` when every recorded key matches; ``False`` after logging
            the first mismatching key at INFO, so the rebuild an operator
            sees in the log names its own cause.
        """
        stored = self._fts.get_chunking_meta()
        checks: tuple[tuple[str, object, object], ...] = (
            ("embed_model_name", stored.model, self._embed_model_name),
            (
                "max_chunk_chars_override",
                stored.max_chunk_chars_override,
                self._max_chunk_chars_override,
            ),
            ("title_field", stored.title_field, self._title_field),
            ("searchable_fields", stored.searchable_fields, self._searchable_fields),
            (
                "indexed_frontmatter_fields",
                stored.indexed_frontmatter_fields,
                self._indexed_frontmatter_fields,
            ),
            (
                "attachment_extensions",
                stored.attachment_extensions,
                self._attachment_extensions,
            ),
            (
                "index_semantics_version",
                stored.semantics_version,
                INDEX_SEMANTICS_VERSION,
            ),
        )
        for key, stored_value, current_value in checks:
            if stored_value != current_value:
                logger.info(
                    "index_provenance_changed key=%s stored=%s current=%s "
                    "action=rebuild",
                    key,
                    stored_value,
                    current_value,
                )
                return False
        return True

    def _can_warm_start(self) -> bool:
        """Reuse a complete index with matching provenance, including tombstones."""
        return (
            self._fts.is_build_completed()
            and self._chunking_meta_matches()
            and self._fts.has_documents()
        )

    def build_index(self, *, force: bool = False) -> IndexStats:
        """Build synchronously, waiting for the same outcome as async callers."""
        return self.build_index_async(force=force).result()

    def reindex(self) -> ReindexResult:
        """Incrementally update the index based on file changes.

        Raises:
            IndexUnavailableError: If :meth:`build_index` has not been called.
        """
        self._readiness.require_built()
        result: ReindexResult = self._writer.submit(ReindexAll()).result()
        return result

    def build_embeddings(self, *, force: bool = False) -> int:
        """Build the vector index from all chunks currently in the FTS index.

        Raises:
            IndexUnavailableError: If :meth:`build_index` has not been called.
            EmbeddingsNotConfiguredError: If ``embedding_provider`` is unset
                (a ``ValueError`` subclass).
        """
        self._readiness.require_built()
        result: int = self._writer.submit(BuildEmbeddings(force=force)).result()
        return result

    def rebuild_embeddings(self) -> None:
        """Force-rebuild the vector index for the search-recovery path.

        Invoked by ``SearchManager._load_vectors`` on a
        ``VectorIndexCompatibilityError`` (embedding-model upgrade). Runs on
        the writer thread to preserve the single-owner invariant. Carries NO
        ``require_built`` gate: the index is necessarily built when vectors
        are being loaded. The rebuilt-chunk count is discarded — the caller
        invokes this for its side-effect only.
        """
        self._writer.submit(BuildEmbeddings(force=True)).result()

    # ------------------------------------------------------------------
    # Asynchronous builds
    # ------------------------------------------------------------------

    def build_index_async(self, *, force: bool = False) -> Future[IndexStats]:
        """Schedule a build whose Future includes marker and readiness publication.

        An idle warm restart returns an already-resolved Future. A failed marker
        write fails this Future just like a failed scan. Cancellation is possible
        until execution begins; cancelling a pending build does not mark it failed.
        """
        return self._builds.submit(self._writer, force=force)

    def _on_reindex_done(self, fut: Future[ReindexResult]) -> None:
        """Capture async reindex outcome for visibility via get_index_status (#561)."""
        try:
            fut.result()
            self._last_reindex_error = None
        except CancelledError:
            # Cancellation (writer-shutdown drain) is not a failure — don't record (#584).
            logger.debug("async_reindex_cancelled")
        except BaseException as exc:
            # Record, never propagate — escaping strands the writer (#584).
            self._last_reindex_error = exc
            logger.exception("async_reindex_job_failed")

    def _on_build_embeddings_done(self, fut: Future[int]) -> None:
        """Capture async build_embeddings outcome for get_index_status (#561)."""
        try:
            fut.result()
            self._last_build_embeddings_error = None
        except CancelledError:
            # Cancellation (writer-shutdown drain) is not a failure — don't record (#584).
            logger.debug("async_build_embeddings_cancelled")
        except BaseException as exc:
            # Record, never propagate — escaping strands the writer (#584).
            self._last_build_embeddings_error = exc
            logger.exception("async_build_embeddings_job_failed")

    def reindex_async(self) -> Future[ReindexResult]:
        """Submit an incremental FTS reindex and return the Future.

        The writer's FIFO queue guarantees any earlier BuildIndex job runs
        first, so this does not require :meth:`build_index` up front.
        """
        fut = self._writer.submit(ReindexAll())
        fut.add_done_callback(self._on_reindex_done)
        return fut

    def build_embeddings_async(self, *, force: bool = False) -> Future[int]:
        """Submit a vector index build and return the Future.

        FIFO ordering guarantees any earlier BuildIndex runs first, so this
        does not require :meth:`build_index` up front.
        """
        fut = self._writer.submit(BuildEmbeddings(force=force))
        fut.add_done_callback(self._on_build_embeddings_done)
        return fut

    # ------------------------------------------------------------------
    # Dirty-path routing
    # ------------------------------------------------------------------

    def mark_paths_dirty(self, paths: Iterable[str]) -> None:
        """Route DocumentManager dirty-marks through the writer (#559).

        The dirty set is updated unconditionally; only the follow-up
        :class:`ProcessDirtyPaths` submission is skipped when the writer is
        closed (avoiding a ``RuntimeError`` on a closed writer at shutdown).
        """
        self._writer.mark_dirty(paths)
        if self._writer.is_closed():
            return
        try:
            self._writer.submit(ProcessDirtyPaths())
        except RuntimeError:
            if not self._writer.is_closed():
                raise
            logger.debug(
                "mark_paths_dirty_writer_closed_after_submit "
                "marks_retained_on_writer_set=True"
            )

    # ------------------------------------------------------------------
    # Deprecated legacy background build (shared lifecycle, one-shot entry)
    # ------------------------------------------------------------------

    def start_background_build_index(self) -> None:
        """Schedule a background build once through the shared build lifecycle.

        .. deprecated:: 1.28
           Superseded by :meth:`build_index_async`. One-shot per coordinator
           lifetime, including submission failure. No extra thread is created.
        """
        self._builds.start_once(self._writer)

    def should_use_background_build(self) -> bool:
        """Return True iff the lifespan should route to the background build.

        .. deprecated:: 1.28
           The lifespan no longer branches on this; retained for legacy tests.
           True only for cold on-disk DBs (real path AND no completeness
           sentinel); False for warm on-disk and in-memory DBs.
        """
        if self._index_path is None or str(self._index_path) == ":memory:":
            return False
        return not self._fts.is_build_completed()

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def close(self, timeout: float = 30.0) -> None:
        """Drain and close the writer, including all scheduled build attempts.

        Does not close the FTS index; Vault closes it after the writer drains.
        """
        self._writer.close(timeout=timeout)
