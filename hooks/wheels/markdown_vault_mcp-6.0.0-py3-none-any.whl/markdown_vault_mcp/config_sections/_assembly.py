"""Domain config-assembly logic extracted out of the template-owned ``config.py``.

``config.py`` is a copier-template-owned file: it must stay at the skeleton shape
(module docstring, ``ProjectConfig`` dataclass, ``from_env`` scaffold) with domain
content confined to the ``CONFIG-FIELDS`` / ``CONFIG-FROM-ENV`` sentinels. All the
domain assembly logic that used to live in its body — the settings-first vault
assembly (``to_vault_settings`` / ``to_vault_instances``), the git-strategy
construction, the
chunk-cap heuristic, and the ``from_env`` field validators — lives here instead
(#900, epic #898).

Imports only fastmcp_pvl_core, stdlib, and sibling domain modules (never
``config`` at runtime) so ``config.py`` can import these without a cycle.

Module-scope imports here are also bound by the config import floor: every
module reachable from ``ProjectConfig`` at import time must resolve with only
``fastmcp-pvl-core`` and PyYAML installed, because the template's
``scripts/gen_config_surface.py`` imports ``ProjectConfig`` under
``uv run --no-project`` with exactly those two, before any project
virtualenv exists (#1259). Anything reaching a further third-party package —
``markdown_vault_mcp.git`` reaches ``python-frontmatter``, for one — belongs
in ``TYPE_CHECKING`` plus a function-local import at the use site.
``tests/test_config_import_floor.py`` enforces this.
"""

from __future__ import annotations

import dataclasses
import logging
from pathlib import Path
from typing import TYPE_CHECKING, Literal

from fastmcp_pvl_core import parse_bool as _parse_bool

from markdown_vault_mcp._identity import (
    configure_identity_claims,
    configure_service_subjects,
)
from markdown_vault_mcp.config_sections.vault_settings import VaultSettings
from markdown_vault_mcp.exceptions import ConfigurationError
from markdown_vault_mcp.utils.fs import is_directory

if TYPE_CHECKING:
    from markdown_vault_mcp.config import ProjectConfig
    from markdown_vault_mcp.git import GitWriteStrategy
    from markdown_vault_mcp.providers import EmbeddingProvider
    from markdown_vault_mcp.summarizer import Summarizer
    from markdown_vault_mcp.types import WriteCallback

logger = logging.getLogger(__name__)

# Full env-var name for the required source dir, used in the missing-var message.
_SOURCE_DIR_VAR = "MARKDOWN_VAULT_MCP_SOURCE_DIR"

# The documented default for SOURCE_DIR: the image and the packaged unit
# mount the vault there, so an unset variable means that layout, and the
# operator surface (docs table, .env.example, wizard) already says so.
DEFAULT_SOURCE_DIR = Path("/data/vault")

# Heuristic ratio converting an embedding model's token context length into a
# conservative character budget for the chunker. English prose averages ~4
# chars/token; 2.8 leaves headroom for token-dense (CJK, code, tables) content
# so a derived char cap stays safely under the model's real token limit.
_CHARS_PER_TOKEN = 2.8

# Ceiling on the derived chunker char cap. Retrieval quality peaks at ~256-512
# tokens per chunk regardless of the model's context length, so the cap is bounded
# rather than scaled to context. 1500 chars (~535 tokens at _CHARS_PER_TOKEN) sits
# just above that band and keeps the fastembed/ONNX fp32 path clear of the #306
# OOM regime. Also the fallback when the model's context length is unknown.
_MAX_CHUNK_CHARS_CEILING = 1500


def derive_max_chunk_chars(*, context_length: int | None, override: int | None) -> int:
    """Resolve the chunker character cap.

    A positive override is used verbatim; ``-1`` opts into unbounded
    context-scaling; otherwise the cap is the bounded default
    ``min(_MAX_CHUNK_CHARS_CEILING, round(context * 2.8))``, falling back to
    ``_MAX_CHUNK_CHARS_CEILING`` when the context length is unknown.

    Args:
        context_length: The embedding model's maximum input length in tokens,
            or ``None`` when it cannot be determined.
        override: An explicit operator-supplied char cap. A positive value is
            used verbatim. ``-1`` opts into unbounded context-scaling (the cap
            tracks the model's full context with no ceiling, or
            ``_MAX_CHUNK_CHARS_CEILING`` when the context length is unknown),
            which can OOM the fastembed/ONNX path on a long-context model.
            ``None`` selects the bounded default
            ``min(_MAX_CHUNK_CHARS_CEILING, round(context * 2.8))``.

    Returns:
        The character budget to pass to the chunker.
    """
    if override == -1:
        # Opt-in: track the model's full context with no ceiling. Documented
        # footgun — a long-context model can OOM the fastembed/ONNX path (#306).
        if context_length is not None and context_length > 0:
            return round(context_length * _CHARS_PER_TOKEN)
        return _MAX_CHUNK_CHARS_CEILING
    if override is not None:
        return override
    # Default: retrieval-optimal and OOM-safe. ``context_length > 0`` guards a
    # degenerate 0 cap; a small-context model clamps *down* so chunks never exceed
    # what it can ingest.
    if context_length is not None and context_length > 0:
        return min(_MAX_CHUNK_CHARS_CEILING, round(context_length * _CHARS_PER_TOKEN))
    return _MAX_CHUNK_CHARS_CEILING


def resolve_source_dir(raw: str | None) -> Path:
    """Turn the ``SOURCE_DIR`` env value into a :class:`Path`, defaulting when unset.

    Takes the already-read env value (so ``config.from_env`` keeps a literal
    ``env(..., "SOURCE_DIR")`` call the wizard drift gate can see). Unset or
    blank means :data:`DEFAULT_SOURCE_DIR`; whether that directory exists is
    reported at startup (:func:`source_dir_problem`), not here, so a
    ``ProjectConfig`` constructs from an empty environment the way the
    template's contract expects.
    """
    cleaned = (raw or "").strip()
    return Path(cleaned) if cleaned else DEFAULT_SOURCE_DIR


SourceDirProblem = tuple[Literal["missing", "unreadable"], str]


def source_dir_problem(config: ProjectConfig) -> SourceDirProblem | None:
    """Why the configured vault directory cannot be served, or ``None``.

    Consulted by :meth:`Service.start`, which then builds no vault and lets
    every accessor fail with the message, and by the batch CLI commands: the
    index writer and the file watcher cannot run over an absent directory.
    Managed git mode is exempt because its bootstrap clones into the directory
    itself. A directory whose stat is refused is reported as unreadable, not
    as missing (#1625).

    Returns:
        ``(reason, message)`` with *reason* ``"missing"`` or ``"unreadable"``,
        or ``None`` when the directory is there.
    """
    if config.git.repo_url is not None:
        return None
    try:
        if is_directory(config.source_dir):
            return None
    except OSError as exc:
        return (
            "unreadable",
            f"vault directory {config.source_dir} cannot be accessed "
            f"({exc.strerror or exc}). Check the directory's permissions.",
        )
    return (
        "missing",
        f"vault directory {config.source_dir} does not exist. Set "
        f"{_SOURCE_DIR_VAR} to the path of your markdown vault.",
    )


def to_bool(raw: str | None, *, default: bool) -> bool:
    """Parse a boolean env value, falling back to *default* when unset."""
    return _parse_bool(raw) if raw is not None else default


def _build_git_strategy(
    config: ProjectConfig,
    *,
    token: str | None,
    managed: bool,
    enable_sync: bool,
    repo_url: str | None = None,
) -> GitWriteStrategy:
    """Build a GitWriteStrategy with the kwargs shared across all three git modes.

    ``enable_sync`` toggles both pull and push together — every call site enables
    or disables them in lockstep.
    """
    # Imported here rather than at module scope: `markdown_vault_mcp.git`
    # reaches `python-frontmatter` transitively, and every module reachable
    # from `ProjectConfig` at import time must resolve under the
    # config-surface generator's dependency floor (see the module docstring).
    from markdown_vault_mcp.git import GitWriteStrategy

    git = config.git
    return GitWriteStrategy(
        token=token,
        repo_url=repo_url,
        managed=managed,
        enable_pull=enable_sync,
        enable_push=enable_sync,
        username=git.username,
        push_delay_s=git.push_delay_s,
        commit_name=git.commit_name,
        commit_email=git.commit_email,
        git_lfs=git.lfs,
        repo_path=config.source_dir,
    )


@dataclasses.dataclass(frozen=True)
class VaultInstances:
    """The never-config-derived ``Vault`` collaborators, resolved from config.

    Carries the constructed instances that stay explicit ``Vault`` keywords
    in settings-first construction (#1158), plus the *resolved* pull
    interval, which is a property of the git assembly (only sync-enabled
    modes run the pull loop) rather than a raw config read — the config
    default is 600 even on non-git vaults. :meth:`close` releases them after
    the vault (#1765).

    Attributes:
        embedding_provider: Resolved embedding provider, or ``None`` when
            semantic search is unconfigured or auto-detection failed.
        summarizer: Resolved summarization backend, or ``None`` when
            unconfigured or auto-detection failed.
        git_strategy: The git write strategy (always constructed; commit-only
            mode when no remote is configured).
        on_write: Write callback for the vault — the git strategy, so writes
            auto-commit.
        git_pull_interval_s: Resolved periodic-pull interval; ``0`` when no
            remote is configured.
    """

    embedding_provider: EmbeddingProvider | None
    summarizer: Summarizer | None
    git_strategy: GitWriteStrategy
    on_write: WriteCallback | None
    git_pull_interval_s: int

    def close(self) -> None:
        """Close the collaborators this assembly constructed.

        The vault closes only what it opens (#1765), so whoever built these
        closes them, after the vault: a flushed push then follows the
        drained commits. ``on_write`` is the git strategy by default and is
        skipped when it is that same object. A collaborator without
        ``close()`` (every embedding provider today) needs none. Each call
        closes each collaborator once more; the strategy's own ``close()``
        is idempotent, so a repeated call is harmless.
        """
        self.git_strategy.close()
        for resource in (self.on_write, self.embedding_provider, self.summarizer):
            if resource is None or resource is self.git_strategy:
                continue
            close = getattr(resource, "close", None)
            if close is not None:
                close()


def _resolve_embedding_provider(config: ProjectConfig) -> EmbeddingProvider | None:
    """Resolve the embedding provider, honouring the explicit-vs-auto posture.

    An explicitly configured provider is resolved on its own; auto-detection
    runs only when ``config.indexing`` configures vector storage: the
    ``EMBEDDINGS_PATH`` storage path, or a PostgreSQL store (cross-section
    coupling, #1708, #1504).  With storage configured, an explicit provider
    that fails to load (an unrecognised name included) raises; without it,
    the failure is logged and the server runs keyword-only.

    Args:
        config: The served project configuration.

    Returns:
        The provider, or ``None`` (unconfigured, auto-detection failed, or an
        explicit provider without configured storage failed to load).

    Raises:
        ConfigurationError: If an explicitly configured provider fails to
            load while storage is configured (``EMBEDDINGS_PATH``, or
            ``EMBEDDING_STORE=postgres``).
    """
    explicit_provider = (config.embeddings.provider or "").strip()
    if not config.indexing.vector_storage_configured:
        # An explicit provider turns semantic search on by itself (#1708);
        # auto-detection still waits for configured storage (EMBEDDINGS_PATH,
        # or a PostgreSQL store, #1504), so an install that merely has a
        # backend importable never starts embedding at startup.
        if not explicit_provider:
            return None
        return _load_provider_or_keyword_only(config, explicit_provider)
    try:
        from markdown_vault_mcp import providers as _providers

        return _providers.get_embedding_provider(config)
    except (ImportError, RuntimeError) as exc:
        if explicit_provider:
            # The operator explicitly chose a backend; a load failure is
            # a configuration error that must surface, not silently fall
            # back to keyword-only search.
            raise ConfigurationError(
                f"Embedding provider {explicit_provider!r} was explicitly "
                "configured (MARKDOWN_VAULT_MCP_EMBEDDING_PROVIDER) but "
                f"could not be loaded: {exc}. Fix the configuration, or "
                "unset the variable to fall back to auto-detection."
            ) from exc
        # Semantic search is disabled until the operator sets
        # MARKDOWN_VAULT_MCP_EMBEDDING_PROVIDER to require a specific backend.
        logger.warning("embedding_provider_autodetect_failed", exc_info=True)
        return None


def _load_provider_or_keyword_only(
    config: ProjectConfig, explicit_provider: str
) -> EmbeddingProvider | None:
    """Load an explicit provider configured without vector storage.

    Before #1708 such a provider was never loaded, so a broken one cost
    nothing. A failure to load it now must not stop a server that starts
    today: it is logged and keyword search carries on.

    Args:
        config: The served project configuration.
        explicit_provider: The configured provider name.

    Returns:
        The provider, or ``None`` when it fails to load.
    """
    try:
        from markdown_vault_mcp import providers as _providers

        return _providers.get_embedding_provider(config)
    # Broad by design: provider constructors raise heterogeneous types (an
    # unknown name, a missing extra, an unsupported model, a failed model
    # download), and any of them must leave the server starting (#1708).
    except Exception as exc:
        logger.warning(
            "embedding_provider_load_failed provider=%s error=%s outcome=keyword_only",
            explicit_provider,
            exc,
        )
        return None


def _resolve_summarizer(config: ProjectConfig) -> Summarizer | None:
    """Resolve the summarization backend when one is configured.

    LLM summarization is gated on a backend being configured (an API key or
    an explicit OpenAI-compatible base URL).  Same posture as embeddings: an
    explicit provider that fails to load is a configuration error;
    auto-detect failure warns and disables.

    Args:
        config: The served project configuration.

    Returns:
        The backend, or ``None`` (unconfigured, or auto-detection failed).

    Raises:
        ConfigurationError: If an explicitly configured backend fails to
            load.
    """
    if not config.summarize.has_provider():
        return None
    explicit_summarizer = (config.summarize.provider or "").strip()
    try:
        from markdown_vault_mcp import summarizer as _summarizer

        return _summarizer.get_summarizer(config)
    except (ImportError, RuntimeError) as exc:
        if explicit_summarizer:
            raise ConfigurationError(
                f"Summarize provider {explicit_summarizer!r} was "
                "explicitly configured "
                "(MARKDOWN_VAULT_MCP_SUMMARIZE_PROVIDER) but could not "
                f"be loaded: {exc}. Fix the configuration, or unset the "
                "variable to fall back to auto-detection."
            ) from exc
        # The summarize tool is disabled until the SDK is installed:
        # pip install 'markdown-vault-mcp[summarize]'.
        logger.warning("summarize_backend_autodetect_failed", exc_info=True)
        return None


def _resolve_git(config: ProjectConfig) -> tuple[GitWriteStrategy, int]:
    """Build the git strategy for the configured mode, with the pull interval.

    Args:
        config: The served project configuration.

    Returns:
        ``(strategy, pull_interval_s)`` — the interval is ``0`` in
        commit-only mode (no remote configured).
    """
    if config.git.repo_url is not None:
        strategy = _build_git_strategy(
            config,
            token=config.git.token,
            repo_url=config.git.repo_url,
            managed=True,
            enable_sync=True,
        )
        return strategy, config.git.pull_interval_s

    # Backward compatibility mode: token without explicit repo URL keeps
    # pull+push semantics, using the existing local checkout's origin.
    if config.git.token is not None:
        strategy = _build_git_strategy(
            config,
            token=config.git.token,
            managed=False,
            enable_sync=True,
        )
        return strategy, config.git.pull_interval_s

    # Unmanaged / commit-only mode: commit locally if repo exists, never pull/push.
    strategy = _build_git_strategy(
        config,
        token=None,
        managed=False,
        enable_sync=False,
    )
    return strategy, 0


def to_vault_instances(config: ProjectConfig) -> VaultInstances:
    """Resolve the constructed ``Vault`` collaborators from config.

    Resolves the embedding provider, summarizer, and the three-mode
    Git strategy.

    Args:
        config: The :class:`~markdown_vault_mcp.config.ProjectConfig` to
            build from.

    Returns:
        The resolved :class:`VaultInstances`.

    Raises:
        ConfigurationError: If an explicitly configured embedding or
            summarize provider fails to load.
    """
    provider = _resolve_embedding_provider(config)
    summarizer = _resolve_summarizer(config)
    # Register the OIDC claim keys with the identity layer, which resolves
    # them at the MCP tool edge into a Principal (#1160) — the strategy's own
    # dispatcher thread has no request token (#1218). Done here rather than
    # inside the git-strategy builder so the identity and versioning seams
    # stay separate at their construction point (#1231).
    configure_identity_claims(
        name_claim=config.git.commit_name_claim,
        email_claim=config.git.commit_email_claim,
    )
    configure_service_subjects(config.content.service_subjects)
    git_strategy, git_pull_interval_s = _resolve_git(config)
    return VaultInstances(
        embedding_provider=provider,
        summarizer=summarizer,
        git_strategy=git_strategy,
        on_write=git_strategy,
        git_pull_interval_s=git_pull_interval_s,
    )


def to_vault_settings(
    config: ProjectConfig, *, instances: VaultInstances | None = None
) -> VaultSettings:
    """Map config onto :class:`VaultSettings` for settings-first construction.

    Thin composition over
    :meth:`~markdown_vault_mcp.config_sections.vault_settings.VaultSettings.from_project_config`
    that threads the resolved embedding provider's token context into the
    ``max_chunk_chars`` derivation (a token-dense chunk that fits
    ``max_chunk_words`` can still exceed the model context; a positive
    override wins verbatim, ``-1`` opts into unbounded context-scaling
    (#790), otherwise the cap is bounded by the ceiling, which is also the
    fallback when the context is unknown).

    Args:
        config: The :class:`~markdown_vault_mcp.config.ProjectConfig` to
            build from.
        instances: Already-resolved collaborators from
            :func:`to_vault_instances`; pass them to avoid resolving the
            embedding provider a second time.  ``None`` resolves a throwaway
            set internally.

    Returns:
        The mapped :class:`VaultSettings`.
    """
    if instances is None:
        instances = to_vault_instances(config)
    provider = instances.embedding_provider
    return VaultSettings.from_project_config(
        config,
        embedding_context_length=(
            provider.context_length if provider is not None else None
        ),
    )


def resolve_git_repo_url(raw: str | None, token: str | None, prefix: str) -> str | None:
    """Resolve ``GIT_REPO_URL``, warning when a token is set without it.

    Args:
        raw: The already-read ``GIT_REPO_URL`` env value.
        token: The already-resolved ``GIT_TOKEN`` value (or ``None``).
        prefix: Env var prefix, used in the warning message.

    Returns:
        The repo URL, or ``None`` when unset.
    """
    repo_url = raw or None
    if token and not repo_url:
        # Legacy mode is deprecated; set GIT_REPO_URL to enable explicit
        # managed mode instead of relying on a bare token.
        logger.warning(
            "git_token_without_repo_url token_var_prefix=%s repo_url_var_prefix=%s",
            prefix,
            prefix,
        )
    return repo_url


def resolve_summarize_api_key(prefixed_raw: str | None) -> str | None:
    """Resolve the summarize API key: prefixed value, bare fallback, or None.

    Args:
        prefixed_raw: The already-read ``SUMMARIZE_OPENAI_API_KEY`` value.

    Returns:
        The effective API key (bare ``OPENAI_API_KEY`` as fallback), or
        ``None`` when neither is set.
    """
    import os

    return (prefixed_raw or os.environ.get("OPENAI_API_KEY") or "").strip() or None


def resolve_summarize_base_url(prefixed_raw: str | None, key: str | None) -> str | None:
    """Resolve the summarize base URL with enablement-safe bare fallback.

    The bare ``OPENAI_BASE_URL`` is a value fallback only: it routes traffic
    when a key already enables summarize, but never enables the tool by
    itself — a user setting it purely for embeddings must not get a surprise
    summarize tool. Only the prefixed var counts toward enablement.

    Args:
        prefixed_raw: The already-read ``SUMMARIZE_OPENAI_BASE_URL`` value.
        key: The already-resolved summarize API key (or ``None``).

    Returns:
        The effective base URL, or ``None``.
    """
    import os

    prefixed = (prefixed_raw or "").strip() or None
    bare = (os.environ.get("OPENAI_BASE_URL") or "").strip() or None
    return prefixed or (bare if key else None)


def resolve_searchable_fields(
    raw: str | None, indexed: tuple[str, ...] | None
) -> tuple[str, ...] | None:
    """Resolve the ``SEARCHABLE_FIELDS`` env value against ``INDEXED_FIELDS``.

    Unset/empty inherits *indexed* (a field configured for structured
    filtering is searchable out of the box); the sentinel ``none`` means
    "filterable but not searchable" — no fields, no inherit; anything else
    is parsed as a comma-separated list.

    Args:
        raw: The already-read ``SEARCHABLE_FIELDS`` env value.
        indexed: The already-parsed ``INDEXED_FIELDS`` tuple (or ``None``).

    Returns:
        The resolved searchable-fields tuple, or ``None``.
    """
    from markdown_vault_mcp.config_sections._helpers import opt_list

    if (raw or "").strip().lower() == "none":
        return None
    return opt_list(raw) or indexed


def resolve_conventions_file(raw: str | None) -> str | None:
    """Resolve the ``CONVENTIONS_FILE`` env value.

    Unset/empty defaults to ``_conventions.md``; the sentinel ``none``
    disables folder conventions entirely.

    Args:
        raw: The already-read ``CONVENTIONS_FILE`` env value.

    Returns:
        The conventions filename, or ``None`` when disabled.
    """
    cleaned = (raw or "").strip()
    if not cleaned:
        return "_conventions.md"
    if cleaned.lower() == "none":
        return None
    return cleaned


def resolve_attachment_extensions(raw: str | None) -> tuple[str, ...] | None:
    """Resolve the ``ATTACHMENT_EXTENSIONS`` env value.

    ``*`` allows every non-markdown extension; unset/empty selects the
    built-in allowlist (``None``); anything else parses as a list.

    Args:
        raw: The already-read ``ATTACHMENT_EXTENSIONS`` env value.

    Returns:
        The extensions tuple, ``("*",)``, or ``None`` for the built-in list.
    """
    from markdown_vault_mcp.config_sections._helpers import opt_list

    cleaned = (raw or "").strip()
    if not cleaned:
        return None
    if cleaned == "*":
        return ("*",)
    return opt_list(cleaned)


def resolve_prompts_folder(raw: str | None, source_dir: Path) -> str | None:
    """Resolve the ``PROMPTS_FOLDER`` value, joining a relative path to the vault.

    Args:
        raw: The prompts-folder value (env-read or field-supplied).
        source_dir: Vault root; used to resolve a relative prompts folder.

    Returns:
        The absolute prompts-folder path as a string, or ``None`` when unset.
    """
    cleaned = (raw or "").strip()
    if not cleaned:
        return None
    pf = Path(cleaned.replace("\\", "/"))
    if not pf.is_absolute():
        pf = source_dir / pf
    return str(pf)


def normalize_templates_folder(raw: str | None) -> str:
    """Normalize a templates-folder value (backslashes, edge slashes, default).

    Args:
        raw: The templates-folder value (env-read or field-supplied).

    Returns:
        The normalized relative folder path, defaulting to ``_templates``.
    """
    return ((raw or "").strip().replace("\\", "/").strip("/")) or "_templates"
