"""Command-line interface for Markdown Vault MCP."""

from __future__ import annotations

from typing import Literal

import typer
from fastmcp_pvl_core import (
    ConfigurationError,
    build_event_store,
    configure_logging_from_env,
    maybe_start_debugpy,
    normalise_http_path,
    run_http,
)

from markdown_vault_mcp.config import _ENV_PREFIX, ProjectConfig

app = typer.Typer(
    name="markdown-vault-mcp",
    help="Generic markdown vault MCP with hybrid search",
    no_args_is_help=True,
    add_completion=False,
)

Transport = Literal["stdio", "http", "sse"]


@app.callback()
def _root(
    verbose: bool = typer.Option(
        False, "-v", "--verbose", help="Enable debug logging."
    ),
) -> None:
    """Root callback — bootstraps logging for every subcommand.

    pvl-core owns the root logger.  ``configure_logging_from_env`` installs
    the one console handler chain every logger in the process renders
    through — ``markdown_vault_mcp.*``, ``fastmcp.*`` and uvicorn alike —
    picks Rich or JSON from ``MARKDOWN_VAULT_MCP_LOG_FORMAT`` (unset: Rich on
    a terminal, JSON anywhere else), resolves the level from ``-v`` or
    ``MARKDOWN_VAULT_MCP_LOG_LEVEL``, and governs the noisy third-party
    loggers (``httpx``, ``httpcore``, the MCP SDK request line) itself.
    Nothing to attach or quiet here: a second root handler would render
    every line twice.  ``serve`` builds its server with
    ``configure_logging=False`` so this stays the process's only call: a
    second one would drop ``-v`` back to the environment's level.
    """
    configure_logging_from_env(_ENV_PREFIX, verbose=verbose)


@app.command()
def serve(
    transport: Transport = typer.Option(
        "stdio", help="MCP transport (stdio / http / sse)."
    ),
    host: str | None = typer.Option(
        None, help=f"Bind host (http only; default: ${_ENV_PREFIX}_HOST or 127.0.0.1)."
    ),
    port: int | None = typer.Option(
        None, help=f"Bind port (http only; default: ${_ENV_PREFIX}_PORT or 8000)."
    ),
    http_path: str | None = typer.Option(
        None,
        "--http-path",
        "--path",
        help=(f"Mount path (http only, default: ${_ENV_PREFIX}_HTTP_PATH or /mcp)."),
    ),
) -> None:
    """Run the MCP server."""
    import os

    from markdown_vault_mcp.server import make_server

    # Optional remote-debugger listener — placed in ``serve`` (not the
    # typer root callback) so non-server commands like ``--help``,
    # ``--version``, or future ``dump-config``-style subcommands are
    # never blocked by ``MARKDOWN_VAULT_MCP_DEBUG_WAIT=true``.  No-op
    # unless ``MARKDOWN_VAULT_MCP_DEBUG_PORT`` is set; ``debugpy`` is only
    # present when the image was built with ``--build-arg DEBUG=true``
    # (a missing import logs a WARNING and continues).  ``_root`` has
    # already installed pvl-core's root handler chain by the time ``serve``
    # runs, so the helper's INFO/WARNING logs render through it rather
    # than Python's lastResort.
    maybe_start_debugpy(_ENV_PREFIX)

    try:
        config = ProjectConfig.from_env()
        # Resolved once, ahead of ``make_server``: the health routes it
        # registers derive their prefix from the mount path, so the value
        # handed to ``http_app(path=...)`` below and the one the server saw
        # must be the same object, not two reads that could drift.
        path = normalise_http_path(
            http_path or os.environ.get(f"{_ENV_PREFIX}_HTTP_PATH")
        )
        server = make_server(
            transport=transport,
            config=config,
            http_path=path,
            configure_logging=False,
        )
        # Inside the guard: since pvl-core 9 ``build_event_store`` raises
        # ``ConfigurationError`` for a malformed ``MARKDOWN_VAULT_MCP_KV_STORE_URL``
        # or legacy ``MARKDOWN_VAULT_MCP_EVENT_STORE_URL``, which must get the
        # same one-line exit as every other operator value (#647).
        event_store = (
            build_event_store(_ENV_PREFIX, config.server)
            if transport == "http"
            else None
        )
    except ConfigurationError as exc:
        # A malformed or missing operator value is one actionable line on
        # stderr, not Typer's Rich traceback: the message already names the
        # variable and the problem (#616). stderr keeps stdout clean for the
        # stdio transport.
        typer.echo(f"ERROR: configuration error: {exc}", err=True)
        raise typer.Exit(code=1) from exc

    if transport == "http":
        # pvl-core runs uvicorn.  It pins ``lifespan="on"`` (FastMCP's
        # startup/shutdown hooks run through the ASGI lifespan protocol),
        # ``log_config=None`` (uvicorn must not reinstall its own handlers
        # over the root chain ``_root`` set up) and the SIGTERM drain window
        # from ``MARKDOWN_VAULT_MCP_SHUTDOWN_GRACE_S`` (default 3s, so
        # containers stop cleanly).  ``None`` for host or port means "not
        # given on the command line"; ``run_http`` then reads ``config.server``.
        run_http(
            server.http_app(path=path, event_store=event_store),
            config=config.server,
            host=host,
            port=port,
        )
    else:
        server.run(transport=transport)


# DOMAIN-COMMANDS-START — add domain @app.command()s (and their helpers) below; kept across copier update
# Domain CLI subcommands live here so the rest of this file stays byte-identical
# to the template and applies cleanly on copier update. Use function-local
# imports for domain modules (as ``serve`` does) to keep the top-level import
# surface template-owned. Module-level ``TYPE_CHECKING`` guards are fine — they
# are erased at runtime.

import enum  # noqa: E402
from typing import TYPE_CHECKING, Any, NamedTuple  # noqa: E402

if TYPE_CHECKING:
    from pathlib import Path

    from markdown_vault_mcp.config_sections import VaultSettings
    from markdown_vault_mcp.config_sections._assembly import VaultInstances
    from markdown_vault_mcp.exceptions import (
        StoreBusyError,
        StoreCorruptError,
        StoreIncompatibleError,
    )
    from markdown_vault_mcp.managers.embedding_import import ImportReport
    from markdown_vault_mcp.vault import Vault


class _BuiltVault(NamedTuple):
    """A vault a command built, with the collaborators built for it (#1765)."""

    vault: Vault
    instances: VaultInstances
    settings: VaultSettings | None = None

    def close(self) -> None:
        """Close the vault, then the collaborators it was given.

        The vault closes only what it opened; the git strategy closes last,
        so its push flush follows the drained commits.
        """
        self.vault.close()
        self.instances.close()


def _build_vault(
    source_dir: str | None = None,
    index_path: str | None = None,
    *,
    scratch_state: bool = False,
    in_memory_vectors: bool = False,
    shared_files: bool = False,
    scratch_index: bool = False,
) -> _BuiltVault:
    """Build a synchronous Vault from env vars + optional CLI overrides.

    Uses the same settings-first ``to_vault_settings`` / ``to_vault_instances``
    assembly as the server path (#1158), but constructs a bare Vault (no
    background tasks, file watcher, or index writer — those belong to the
    server's lifespan).

    Args:
        source_dir: Overrides ``{PREFIX}_SOURCE_DIR`` when given (set into the
            environment before ``ProjectConfig.from_env()`` reads it).
        index_path: Overrides the resolved SQLite index path when given.
        scratch_state: Keep the change-tracking state in memory, ignoring
            ``STATE_PATH``, for a one-shot in-memory index whose state must
            not overwrite a running server's (#1691).
        in_memory_vectors: Resolve the embedding provider even when nothing
            would keep the vectors (no ``EMBEDDINGS_PATH``, no PostgreSQL
            store and no on-disk index), so they are embedded in memory. Off by default: the
            provider is then never resolved, since a batch command would pay
            it for vectors it throws away (#1708).
        shared_files: Leave the index files on disk as they are, since a
            running server may own them: an on-disk index opens read-only
            (#1758) and an unusable vector sidecar makes a search raise
            instead of being rebuilt (#1734).
        scratch_index: Keep the keyword index and its state in memory and
            open the configured vector store read-only, where it is
            configured, for a dry run that writes nothing (#1505).

    Returns:
        The constructed :class:`~markdown_vault_mcp.vault.Vault` (index not
        built) with the collaborators built for it; call ``close()`` on the
        pair when done.
    """
    import dataclasses
    import os
    from pathlib import Path

    from markdown_vault_mcp.config_sections._assembly import (
        source_dir_problem,
        to_vault_instances,
        to_vault_settings,
    )
    from markdown_vault_mcp.vault import Vault

    # --source-dir overrides the env var: set it before from_env() reads it.
    # Deliberate process-env mutation — safe for a single-shot, single-threaded CLI.
    if source_dir:
        os.environ[f"{_ENV_PREFIX}_SOURCE_DIR"] = source_dir
    config = ProjectConfig.from_env()
    # A batch command over an absent or inaccessible directory would index
    # nothing and exit 0; refuse with the reason, the way ``serve`` reports a
    # configuration error (a missing directory names the variable to set).
    problem = source_dir_problem(config)
    if problem is not None:
        typer.echo(f"ERROR: configuration error: {problem[1]}", err=True)
        raise typer.Exit(code=1)
    if not in_memory_vectors and not _vectors_kept(config, index_path):
        # Nothing would keep the vectors, so drop the provider before it is
        # resolved: FastEmbed would load, or download, its model for nothing.
        config = dataclasses.replace(config, embedding_provider=None)
    instances = to_vault_instances(config)
    settings = to_vault_settings(config, instances=instances)
    if index_path:
        settings = dataclasses.replace(settings, index_path=Path(index_path))
    if scratch_state:
        settings = dataclasses.replace(settings, state_path=None)
    if shared_files:
        settings = dataclasses.replace(settings, owns_index_files=False)
    if scratch_index:
        settings = dataclasses.replace(
            settings,
            embeddings_path=settings.effective_embeddings_path(),
            index_path=None,
            state_path=None,
            owns_index_files=False,
        )
    return _BuiltVault(
        Vault(
            source_dir=config.source_dir,
            settings=settings,
            embedding_provider=instances.embedding_provider,
            summarizer=instances.summarizer,
            git_strategy=instances.git_strategy,
            on_write=instances.on_write,
        ),
        instances,
        settings,
    )


def _vectors_kept(config: ProjectConfig, index_path: str | None) -> bool:
    """Report whether a file would keep the vectors this command embeds.

    Args:
        config: The configuration the command read.
        index_path: The ``--index-path`` override, if given.

    Returns:
        ``True`` when ``EMBEDDINGS_PATH`` or a PostgreSQL store is
        configured (#1504), or the index is on disk, where the vectors
        default beside it (#1708).
    """
    if config.indexing.vector_storage_configured:
        return True
    index = index_path or config.indexing.index_path
    return index is not None and str(index) != ":memory:"


def index(
    source_dir: str | None = typer.Option(
        None, help=f"Path to markdown vault (overrides ${_ENV_PREFIX}_SOURCE_DIR)."
    ),
    index_path: str | None = typer.Option(
        None, help=f"Path to SQLite index file (overrides ${_ENV_PREFIX}_INDEX_PATH)."
    ),
    force: bool = typer.Option(False, help="Drop and rebuild the index from scratch."),
) -> None:
    """Build the full-text search index."""
    from markdown_vault_mcp._http_logging import quiet_http_loggers
    from markdown_vault_mcp.exceptions import (
        EmbeddingsNotConfiguredError,
        EmbeddingsNotPublishedError,
        StoreBusyError,
    )

    quiet_http_loggers()
    built = _build_owning_vault("admin index", source_dir, index_path)
    try:
        stats = built.vault.index.build_index(force=force)
        if stats.vault_root_empty:
            typer.echo(_empty_root_message("indexed", "admin index"), err=True)
            raise typer.Exit(1)
        typer.echo(
            f"Indexed {stats.documents_indexed} documents, "
            f"{stats.chunks_indexed} chunks"
        )
        try:
            n = built.vault.index.build_embeddings(force=force)
            typer.echo(f"Embedded {n} chunks")
        except EmbeddingsNotConfiguredError:
            pass  # embeddings not configured
        except EmbeddingsNotPublishedError as exc:
            typer.echo(f"ERROR: {exc} Retry when the provider recovers.", err=True)
            raise typer.Exit(1) from exc
    except StoreBusyError as exc:
        typer.echo(_busy_message(exc, "admin index"), err=True)
        raise typer.Exit(1) from exc
    finally:
        built.close()


def _empty_root_message(done: str, command: str) -> str:
    """Say that an empty vault folder stopped *command*, and what to do.

    Args:
        done: What did not happen, such as ``"indexed"``.
        command: The command to run again once the folder is back.

    Returns:
        The one-line refusal for stderr.
    """
    return (
        "ERROR: the vault folder is empty while the index holds notes, as "
        f"when its volume is not mounted, so nothing was {done}. Mount it and "
        f"run {command} again; to empty the vault on purpose, run admin index --force."
    )


def _build_owning_vault(
    command: str,
    source_dir: str | None = None,
    index_path: str | None = None,
    **options: bool,
) -> _BuiltVault:
    """Build the vault for a command that writes it, or stop with the refusal.

    Opening the index as its owner takes its writer lock (#1890), so beside a
    running server the build itself is refused, before anything is written.

    Args:
        command: The command to name in the refusal.
        source_dir: As for :func:`_build_vault`.
        index_path: As for :func:`_build_vault`.
        **options: :func:`_build_vault`'s keyword options.

    Returns:
        The built vault.

    Raises:
        typer.Exit: With code 1 when another process owns a store.
    """
    from markdown_vault_mcp.exceptions import StoreBusyError

    try:
        return _build_vault(source_dir, index_path, **options)
    except StoreBusyError as exc:
        typer.echo(_busy_message(exc, command), err=True)
        raise typer.Exit(1) from exc


def _busy_message(exc: StoreBusyError, command: str) -> str:
    """Say that a running server holds a store, and what to do.

    Args:
        exc: The store's refusal: its writer lock or lease is held elsewhere.
        command: The command to run again.

    Returns:
        The ``ERROR:`` line for stderr.
    """
    return (
        f"ERROR: {exc.backend}:{exc.location} is being written by another "
        f"process. Stop the server first, then run {command} again."
    )


def _embed_in_memory(vault: Vault) -> None:
    """Embed the vault for one search by meaning when nothing keeps the vectors.

    Vectors that ``EMBEDDINGS_PATH``, an on-disk index or a PostgreSQL store
    keep are only read: building them here would write vectors a running
    server may share (#1708, #1504).

    Args:
        vault: A vault whose in-memory index is already built.
    """
    status = vault.index.embeddings_status()
    if status["available"] and status["path"] is None:
        vault.index.build_embeddings()


def _unusable_vectors_message(exc: StoreCorruptError | StoreIncompatibleError) -> str:
    """Explain why search refused stored vectors, and what to do instead.

    Args:
        exc: The store's refusal: another model, or damage.

    Returns:
        The ``ERROR:`` line for stderr.
    """
    from markdown_vault_mcp.exceptions import StoreIncompatibleError

    if isinstance(exc, StoreIncompatibleError):
        remedy = "Search with the embedding settings that built them"
    else:
        remedy = (
            "To rebuild them, run admin index with the settings that built them "
            "while no server uses them"
        )
    reason = str(exc).rstrip(".")
    return (
        f"ERROR: cannot search by meaning: {reason}. The vectors are left as "
        f"they are, since a running server may use them. {remedy}, or search "
        "with --mode keyword."
    )


def _require_index_file(index_path: Path) -> None:
    """Refuse a search of an on-disk index that has not been built.

    The index is opened read-only, which cannot create it; creating it here
    would write a file a server may be about to own (#1758).

    Args:
        index_path: The configured ``INDEX_PATH``.

    Raises:
        typer.Exit: With code 1 when no file is at the path.
    """
    from markdown_vault_mcp.utils.fs import path_exists

    if not path_exists(index_path):
        typer.echo(
            f"ERROR: no index at {index_path}. Build it with index, or start "
            "the server that owns it.",
            err=True,
        )
        raise typer.Exit(code=1)


def _local_search(
    query: str, source_dir: str | None, arguments: dict[str, Any]
) -> list[dict[str, Any]]:
    """Search a local index without changing files a server may own."""
    from dataclasses import asdict
    from typing import cast

    mode = arguments.get("mode")
    limit = arguments["limit"]
    folder = arguments["folder"]
    from markdown_vault_mcp.exceptions import StoreCorruptError, StoreIncompatibleError

    # An in-memory index is empty until built, so build it, keeping its state
    # in memory too: STATE_PATH may be a running server's (#1691). An on-disk
    # index is only read: build_index() would rebuild a server's index
    # whenever this shell's settings differ from the ones it was built with,
    # and even opening it for writing commits the rank weights (#1758).
    configured = ProjectConfig.from_env().indexing
    configured_index = configured.index_path
    in_memory = configured_index is None or str(configured_index) == ":memory:"
    if configured_index is not None and not in_memory:
        _require_index_file(configured_index)
    # Only a valid vector mode embeds: a mistyped one must fail in the search
    # below before a paid provider has embedded the vault (#1708).
    by_meaning = mode in ("semantic", "hybrid")
    # Vectors on disk are only read too: a server rebuilds a sidecar that
    # does not fit its provider, and one in another shell's would rebuild it
    # under the server (#1734).
    built = _build_vault(
        source_dir,
        None,
        scratch_state=in_memory,
        in_memory_vectors=by_meaning,
        shared_files=True,
    )
    try:
        if in_memory:
            built.vault.index.build_index()
            # Vectors kept elsewhere (EMBEDDINGS_PATH, or PostgreSQL, #1504)
            # are only read: this shell does not own them.
            if by_meaning and not configured.vector_storage_configured:
                _embed_in_memory(built.vault)
        try:
            results = built.vault.reader.search(
                query,
                limit=limit,
                mode=cast("Literal['keyword', 'semantic', 'hybrid'] | None", mode),
                folder=folder,
                **{
                    key: arguments[key]
                    for key in ("filters", "chunks_per_file", "snippet_words")
                    if key in arguments
                },
            )
        except (StoreCorruptError, StoreIncompatibleError) as exc:
            typer.echo(_unusable_vectors_message(exc), err=True)
            raise typer.Exit(code=1) from exc
        from markdown_vault_mcp._read_payloads import annotate_hits
        from markdown_vault_mcp.okf import derive_annotation

        return annotate_hits(
            [asdict(r) for r in results],
            derive_annotation if built.vault.okf.state().active else None,
        )
    finally:
        built.close()


def reindex(
    source_dir: str | None = typer.Option(
        None, help=f"Path to markdown vault (overrides ${_ENV_PREFIX}_SOURCE_DIR)."
    ),
    index_path: str | None = typer.Option(
        None, help=f"Path to SQLite index file (overrides ${_ENV_PREFIX}_INDEX_PATH)."
    ),
    force: bool = typer.Option(
        False,
        "--force",
        help=(
            "Drop the index and re-parse every file, ignoring change detection. "
            "An upgrade that changes extraction rebuilds by itself on the next "
            "run; use this only for an index you have reason to distrust."
        ),
    ),
) -> None:
    """Incrementally reindex the vault."""
    from markdown_vault_mcp._http_logging import quiet_http_loggers
    from markdown_vault_mcp.exceptions import (
        EmbeddingsNotConfiguredError,
        StoreBusyError,
    )

    quiet_http_loggers()
    built = _build_owning_vault("admin reindex", source_dir, index_path)
    try:
        # reindex() needs a built index (#525); build_index() is a cheap no-op
        # when the index is already populated (a SQL row-count check, no
        # filesystem scan) and the recorded build provenance still matches
        # this process (#1124).
        built.vault.index.build_index(force=force)
        result = built.vault.index.reindex()
        if result.vault_root_empty:
            typer.echo(_empty_root_message("reindexed", "admin reindex"), err=True)
            raise typer.Exit(1)
        typer.echo(
            f"Reindex: {result.added} added, {result.modified} modified, "
            f"{result.deleted} deleted, {result.unchanged} unchanged, "
            f"{result.skipped} skipped"
        )
        try:
            # Converges vectors to FTS chunks (#665).
            n = built.vault.index.build_embeddings()
            typer.echo(f"Embedded {n} chunks")
        except EmbeddingsNotConfiguredError:
            pass  # embeddings not configured
    except StoreBusyError as exc:
        typer.echo(_busy_message(exc, "admin reindex"), err=True)
        raise typer.Exit(1) from exc
    finally:
        built.close()


class _SourceKind(enum.StrEnum):
    """The vector stores an import reads from."""

    numpy = "numpy"
    sqlite = "sqlite"
    postgres = "postgres"


def embeddings_import(
    source: _SourceKind = typer.Option(
        ...,
        "--from",
        help="The store to copy vectors from: numpy, sqlite or postgres.",
    ),
    from_path: str | None = typer.Option(
        None,
        "--from-path",
        help=(
            "Base path of a numpy or sqlite source (default: the configured "
            "embeddings base)."
        ),
    ),
    from_schema: str | None = typer.Option(
        None,
        "--from-schema",
        help="Schema of a postgres source (default: the configured schema).",
    ),
    from_dsn_env: str | None = typer.Option(
        None,
        "--from-dsn-env",
        help=(
            "Environment variable holding a postgres source's connection string "
            f"(default: ${_ENV_PREFIX}_EMBEDDING_POSTGRES_DSN)."
        ),
    ),
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        help="Count what would be copied and embedded; write nothing.",
    ),
) -> None:
    """Copy vectors from another store into the configured one, embedding only what it lacks."""
    from pathlib import Path

    from markdown_vault_mcp._http_logging import quiet_http_loggers
    from markdown_vault_mcp.exceptions import (
        EmbeddingsNotPublishedError,
        StoreOpenError,
    )
    from markdown_vault_mcp.managers.embedding_import import (
        ImportRefused,
        ImportSource,
        import_embeddings,
    )

    quiet_http_loggers()
    built = _build_owning_vault(
        "admin embeddings import", in_memory_vectors=True, scratch_index=dry_run
    )
    wanted = ImportSource(
        source.value,
        path=Path(from_path) if from_path else None,
        schema=from_schema,
        dsn_env=from_dsn_env,
    )
    try:
        if built.settings is None:  # pragma: no cover - _build_vault always sets it
            raise RuntimeError("The vault was built without its settings.")
        report = import_embeddings(built.vault, built.settings, wanted, dry_run=dry_run)
    except ImportRefused as exc:
        typer.echo(f"ERROR: {exc}", err=True)
        raise typer.Exit(1) from exc
    except EmbeddingsNotPublishedError as exc:
        typer.echo(f"ERROR: {exc} Retry when the provider recovers.", err=True)
        raise typer.Exit(1) from exc
    except StoreOpenError as exc:
        typer.echo(f"ERROR: the configured store cannot be opened: {exc}", err=True)
        raise typer.Exit(1) from exc
    finally:
        built.close()
    _report_import(report)


def _report_import(report: ImportReport) -> None:
    """Print what an import did, or would do; exit 1 when it saved nothing.

    Args:
        report: The import's report.

    Raises:
        typer.Exit: With code 1 when the build published nothing.
    """
    refused = report.refused_rows
    rows = f", {refused} source row{'' if refused == 1 else 's'} refused"
    rows = rows if refused else ""
    if report.dry_run:
        typer.echo(
            f"Would import from {report.source} into {report.destination}: "
            f"{report.chunks} chunks, {report.reused} reusable, {report.embedded} "
            f"to embed{rows}. Nothing was written."
        )
        return
    if not report.published:
        typer.echo(
            f"ERROR: the provider embedded none of the chunks {report.source} "
            "lacks, so nothing was published. Retry when the provider recovers.",
            err=True,
        )
        raise typer.Exit(1)
    typer.echo(
        f"Imported from {report.source} into {report.destination}: "
        f"{report.chunks} chunks, {report.reused} reused, {report.embedded} "
        f"embedded{rows}."
    )
    if report.failed_batches:
        batches = report.failed_batches
        typer.echo(
            f"{batches} provider batch{'' if batches == 1 else 'es'} failed; the "
            "server embeds the chunks still missing at its next start."
        )


from markdown_vault_mcp._cli_admin import register_admin_commands  # noqa: E402
from markdown_vault_mcp._cli_reader import register_read_commands  # noqa: E402

# Read commands first, so the help lists them before the admin group (#2005).
register_read_commands(app)
register_admin_commands(app, index, reindex, embeddings_import)

# DOMAIN-COMMANDS-END


def main() -> None:
    """CLI entry point — used by ``[project.scripts]`` in pyproject.toml."""
    app()


if __name__ == "__main__":
    main()
