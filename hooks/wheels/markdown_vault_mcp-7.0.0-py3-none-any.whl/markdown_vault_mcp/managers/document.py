"""Document CRUD, attachment, and path-validation manager.

Handles all read/write/edit/append/delete/rename operations, attachment I/O,
path validation, and backlink updates — all with dependency injection
and no back-reference to :class:`Vault`.

Serializer behavior: ``docs/design/reference/python-frontmatter-pyyaml.md``.
"""

from __future__ import annotations

import contextlib
import logging
import os
import posixpath
import shutil
import sqlite3
import stat
from collections import defaultdict
from dataclasses import replace
from pathlib import Path
from typing import TYPE_CHECKING, Any

import frontmatter as fm
import yaml

from markdown_vault_mcp._commit_scope import (
    auxiliary_commit_writes,
    current_commit_scope,
)
from markdown_vault_mcp._okf_log_repair import (
    LogRepairCollision,
    LogRepairInterrupted,
    LogRepairPreview,
    LogRepairResult,
    preview_log_repair,
    require_reviewed,
    retain_original,
)
from markdown_vault_mcp._yaml12 import YAML12_HANDLER
from markdown_vault_mcp.exceptions import (
    FIND_NOTE,
    ConcurrentModificationError,
    DocumentExistsError,
    DocumentNotFoundError,
    DocumentUnreadableError,
    EditConflictError,
    FolderMoveInterruptedError,
    InvalidRequestError,
    NoteTooLargeError,
    ReadOnlyError,
    SubmodulePathError,
)
from markdown_vault_mcp.hashing import compute_etag
from markdown_vault_mcp.managers._rewrite_ledger import LinkRewriteLedger
from markdown_vault_mcp.managers._write_kernel import atomic_write, check_if_match
from markdown_vault_mcp.managers._write_notifier import (
    OnWriteCallback,
    WriteNotifier,
)
from markdown_vault_mcp.managers.artifacts import ArtifactPolicy, ArtifactStore
from markdown_vault_mcp.scanner import (
    _resolve_link_path,
    extract_section,
    list_section_headings,
    parse_note,
    strip_frontmatter_block,
)
from markdown_vault_mcp.source_probe import require_vault_root
from markdown_vault_mcp.types import (
    AttachmentContent,
    DeleteResult,
    EditResult,
    MoveFolderResult,
    NoteContent,
    RenameResult,
    SubtreeToc,
    TocEntry,
    WriteCallback,
    WriteOperation,
    WriteResult,
)
from markdown_vault_mcp.utils import (
    is_note,
    is_path_excluded,
    reject_nul,
    resolve_inside,
    validate_path,
)
from markdown_vault_mcp.utils.fs import (
    is_directory,
    is_regular_file,
    path_exists,
    walk_files_strict,
)
from markdown_vault_mcp.utils.links import (
    compute_new_raw_target as _compute_new_raw_target,
)
from markdown_vault_mcp.utils.links import (
    rewrite_link_destinations as _rewrite_link_destinations,
)
from markdown_vault_mcp.utils.text import (
    build_position_map as _build_position_map,
)
from markdown_vault_mcp.utils.text import (
    decode_utf8 as _decode_utf8,
)
from markdown_vault_mcp.utils.text import (
    find_closest_match as _find_closest_match,
)
from markdown_vault_mcp.utils.text import (
    normalize_text as _normalize_text,
)
from markdown_vault_mcp.utils.text import (
    read_text_utf8 as _read_text_utf8,
)

if TYPE_CHECKING:
    import threading
    from collections.abc import Callable, Iterable, Iterator, Sequence

    from markdown_vault_mcp._okf_write import OkfWriteEnrich
    from markdown_vault_mcp.git.submodules import SubmoduleGuard
    from markdown_vault_mcp.interfaces import KeywordGraphIndex
    from markdown_vault_mcp.scanner import ChunkStrategy

logger = logging.getLogger(__name__)

# The next step for an old_text that matches more than once (#1639).
_DISAMBIGUATE = (
    "Include more surrounding text in old_text, or pass line_start and line_end."
)

#: Set as :attr:`~markdown_vault_mcp.types.RenameResult.hint` when
#: ``update_links=True`` is passed for an attachment.  The link graph is
#: notes-only — references to attachments are not tracked as links — so there
#: is nothing to rewrite; a bare ``updated_links: 0`` hid that (#1338).
_ATTACHMENT_UPDATE_LINKS_HINT = (
    "update_links does not apply to attachments: references to attachments "
    "are not tracked as links, so none were rewritten. Notes embedding the "
    "old path still name it; edit them to point at the new path."
)


def _submodule_links_text(sources: list[str]) -> str:
    """Name backlinks left in submodules or nested repositories (#1564, #1949)."""
    names = ", ".join(repr(s) for s in sources)
    return (
        f"The links in {names} still name the old path: they are inside a git "
        "submodule or nested repository, which this server does not change. Edit them in the "
        "note's own repository."
    )


class DocumentManager:
    """Manages document CRUD, attachments, path validation, and backlinks.

    All file I/O, FTS index mutations, and write-callback dispatch for
    individual documents flow through this class.

    Args:
        fts: The FTS index for upsert/delete operations.
        source_dir: Absolute path to the vault root directory.
        write_lock: Shared re-entrant lock serialising write operations.
        chunk_strategy: Strategy for splitting documents into chunks.
        read_only: When ``True`` (default), write operations raise
            :exc:`~markdown_vault_mcp.exceptions.ReadOnlyError`. Stays
            ``True`` for the same reason ``Vault``'s does: it is the
            library-tier fail-safe, not the operator default the server
            flipped in #1113.
        write_protect_existing: When ``True``, :meth:`write` and
            :meth:`write_attachment` refuse to overwrite an existing file
            unless the caller supplies an ``if_match`` etag.
        exclude_patterns: Glob patterns for paths to exclude.
        attachment_extensions: Allowlist of attachment file extensions.
        max_note_read_bytes: Maximum bytes returned by full-document reads.
            ``0`` disables the limit (default ``262144``, i.e. 256 KB).
        on_write_callback: Fires after a successful write to enqueue a
            git commit.  Signature:
            ``(abs_path, content, operation, old_path=None)``, where
            *old_path* is set only on ``rename`` and lets the commit stage
            exactly the two paths the rename touched (#894).
        mark_paths_dirty: Routes FTS-affecting write operations through
            the single-owner :class:`IndexWriter` (#559).  Called with an
            iterable of vault-relative paths after each successful
            mutation; the writer drains the resulting dirty set via a
            ``ProcessDirtyPaths`` job.  ``None`` (default) leaves the
            DocumentManager FTS-side-effect-free, which is the contract
            used by the isolation tests.
        sync_index: Refresh prior writes before an index-dependent mutation.
            Called outside the file-write lock; errors abort before mutation.
            ``None`` leaves synchronization to the direct manager caller.
        title_field: Frontmatter key consulted first when resolving document
            titles.  Must match the value the index managers use, or
            ``read()`` titles would diverge from search titles.
        submodule_guard: Refuses a write into a git submodule or nested
            repository, which would never be committed (#1564, #1949). ``None`` refuses nothing.
    """

    def __init__(
        self,
        fts: KeywordGraphIndex,
        source_dir: Path,
        *,
        write_lock: threading.RLock,
        chunk_strategy: ChunkStrategy,
        read_only: bool = True,
        write_protect_existing: bool = False,
        exclude_patterns: list[str] | None = None,
        attachment_extensions: Sequence[str] | None = None,
        max_note_read_bytes: int = 262144,
        on_write_callback: OnWriteCallback | WriteCallback | None = None,
        mark_paths_dirty: Callable[[Iterable[str]], None] | None = None,
        title_field: str = "title",
        okf_write_enrich: OkfWriteEnrich | None = None,
        sync_index: Callable[[], None] | None = None,
        submodule_guard: SubmoduleGuard | None = None,
    ) -> None:
        self._fts = fts
        self._source_dir = source_dir
        self._file_write_lock = write_lock
        self._chunk_strategy = chunk_strategy
        self._read_only = read_only
        self._write_protect_existing = write_protect_existing
        self._exclude_patterns = exclude_patterns
        self._max_note_read_bytes = max_note_read_bytes
        self._notifier = WriteNotifier(on_write_callback)
        self._artifacts = ArtifactStore(
            source_dir,
            write_lock=write_lock,
            notifier=self._notifier,
            indexed=fts.has_documents,
            submodule_guard=submodule_guard,
            policy=ArtifactPolicy(
                attachment_extensions=attachment_extensions,
                read_only=read_only,
                write_protect_existing=write_protect_existing,
            ),
        )
        self._mark_paths_dirty = mark_paths_dirty
        self._sync_index = sync_index
        self._submodule_guard = submodule_guard
        self._title_field = title_field
        # OKF enforced-write hook (#964): transforms the final note text
        # (stamp `generated`; `verified` is kept) before it lands. None when
        # OKF_WRITE is off — zero overhead on the write path.
        self._okf_write_enrich = okf_write_enrich
        # The link rewrites this manager made, so a rename can accept an
        # etag that only those rewrites made stale (#1492).
        self._link_rewrites = LinkRewriteLedger()

    # ------------------------------------------------------------------
    # Validation helpers
    # ------------------------------------------------------------------

    def ensure_index_current(self) -> None:
        """Refresh queued index writes before deriving a file mutation from them.

        The optional callback is wired by Vault. Call outside the file-write
        lock so waiting cannot hold up another writer's completion.
        """
        if self._sync_index is not None:
            self._sync_index()

    def _check_writable(self) -> None:
        """Raise when the vault is read-only, or its folder is empty while indexed.

        Raises:
            ReadOnlyError: If ``read_only=True``.
            VaultUnavailableError: If the vault folder holds nothing while the
                index holds notes, as when its volume is not mounted (#1791).
        """
        if self._read_only:
            raise ReadOnlyError(
                "Vault is read-only; write operations are not permitted."
            )
        require_vault_root(self._source_dir, indexed=self._fts.has_documents())

    def _refuse_submodule(
        self, abs_path: Path, argument: str, path: str, *, holding: bool = True
    ) -> None:
        """Refuse a write in or holding a git submodule or nested repository.

        Call right after validating *path*, before anything touches disk.
        """
        if self._submodule_guard is not None:
            self._submodule_guard.refuse(abs_path, argument, path, holding=holding)

    def case_only_sibling(self, path: str) -> str | None:
        """Return the vault path of an entry that differs from *path* only by case.

        OKF 0.3 §6: "Producers SHOULD NOT make two paths that differ only by
        case." The server's own generators ask before creating a reserved
        file, so a user's ``Index.md`` never gains an ``index.md`` beside it
        (#2454). On a case-insensitive file system the same check stops the
        generator writing over that note. An unreadable folder reports no
        sibling; the write that follows meets the same error.

        Args:
            path: The vault-relative POSIX path the server is about to create.

        Returns:
            The colliding entry's vault-relative path, or ``None``.
        """
        folder, _, name = path.rpartition("/")
        base = self._source_dir / folder if folder else self._source_dir
        try:
            entries = sorted(child.name for child in base.iterdir())
        except OSError:
            return None
        lowered = name.lower()
        for entry in entries:
            if entry != name and entry.lower() == lowered:
                return f"{folder}/{entry}" if folder else entry
        return None

    def refuse_folder_in_submodule(self, folder: str, argument: str) -> None:
        """Refuse a folder inside a git submodule or nested repository.

        For the OKF tools, which write into the folder they are given.

        Args:
            folder: Vault-relative folder, ``""`` for the root.
            argument: The tool parameter that carried *folder*.

        Raises:
            SubmodulePathError: If *folder* is a protected repository or lies inside one.
        """
        self._refuse_submodule(
            self._source_dir / folder, argument, folder, holding=False
        )

    def in_submodule(self, path: str) -> bool:
        """Whether a note or folder lies in a submodule or nested repository.

        Args:
            path: Vault-relative path.

        Returns:
            ``True`` when *path* is a protected repository or lies inside one;
            ``False`` for a folder that only holds one, and without a guard.
        """
        guard = self._submodule_guard
        if guard is None:
            return False
        found = guard.submodule_of(self._source_dir / path, holding=False)
        return found is not None and found[1]

    @contextlib.contextmanager
    def write_scope(self) -> Iterator[None]:
        """Hold the write lock across a caller's own read-then-write sequence.

        The lock is re-entrant, so a caller may hold it while calling a write
        method that takes it again.  Public because a decision made *from* the
        current state — the overwrite breadcrumb (#1137) reads which commit
        holds what is on disk — is only true if nothing else writes the note
        between reading that state and acting on it.
        """
        with self._file_write_lock:
            yield

    def ensure_writable(self) -> None:
        """Raise :exc:`ReadOnlyError` if the vault is read-only.

        Public entry point for collaborators (e.g. the OKF migration
        manager) that need to reject up front, before any per-note write is
        reached — a whole-vault transform over an empty read-only vault
        would otherwise silently no-op.
        """
        self._check_writable()

    def _is_path_excluded(self, path: str) -> bool:
        """Check whether *path* matches any configured exclude pattern.

        Args:
            path: Relative POSIX path string.

        Returns:
            ``True`` if the path matches any pattern in
            ``self._exclude_patterns``.
        """
        return is_path_excluded(path, self._exclude_patterns)

    def _validate_path(self, path: str) -> Path:
        """Resolve a relative path and validate it is inside source_dir.

        Args:
            path: Relative document path.

        Returns:
            The resolved absolute path.

        Raises:
            InvalidRequestError: If the path escapes the source directory or does
                not end with ``.md``.
        """
        return validate_path(path, self._source_dir)

    def _validate_attachment_path(self, path: str) -> Path:
        """Resolve and validate a non-.md attachment path.

        Thin delegator to :meth:`ArtifactStore.validate_path` (#1235); kept
        because ``Vault`` and the tests reach for it by this name.

        Args:
            path: Relative attachment path.

        Returns:
            The resolved absolute path.

        Raises:
            InvalidRequestError: If the path escapes the source directory, ends
                with ``.md``, or has an extension not in the attachment
                allowlist.
        """
        return self._artifacts.validate_path(path)

    def _validate_dir_path(self, path: str) -> Path:
        """Resolve a relative folder path and validate it is inside the vault.

        Unlike :meth:`_validate_path`, this does not require a ``.md`` suffix —
        it is for directory prefixes used by :meth:`move_folder` and
        :meth:`_subtree_toc`.

        Args:
            path: Relative folder path (e.g. ``"drafts"`` or ``"a/b"``).

        Returns:
            The resolved absolute path.

        Raises:
            InvalidRequestError: If the path is empty, the vault root, or escapes
                the source directory.
        """
        if not path or path in (".", "/"):
            raise InvalidRequestError(
                f"Invalid folder path: {path!r}. Pass a folder below the vault "
                "root, as list_folders returns it."
            )
        abs_path = resolve_inside(path, self._source_dir)
        if abs_path == self._source_dir.resolve():
            # A folder scope must be a strict subtree, never the vault root.
            raise InvalidRequestError(
                f"{path!r} is the vault root; a folder scope must name a subfolder"
            )
        return abs_path

    # ------------------------------------------------------------------
    # Legacy log repair (#1403)
    # ------------------------------------------------------------------

    def _log_repair_snapshot(self, path: str) -> tuple[Path, bytes]:
        """Read a bounded raw snapshot of exactly one vault-relative log.md."""
        if Path(path).is_absolute():
            raise InvalidRequestError(
                f"path {path!r} must be vault-relative. Name the affected log.md "
                "relative to the vault root."
            )
        abs_path = self._validate_path(path)
        if Path(path).name != "log.md" or abs_path.name != "log.md":
            raise InvalidRequestError(
                f"path {path!r} must name log.md. Name the vault-relative path "
                "of the affected log."
            )
        try:
            if not stat.S_ISREG(abs_path.stat().st_mode):
                raise DocumentNotFoundError.note(path)
            cap = self._max_note_read_bytes
            with abs_path.open("rb") as stream:
                original = stream.read(cap + 1 if cap > 0 else -1)
            if cap > 0 and len(original) > cap:
                raise NoteTooLargeError(
                    f"Log {path!r} exceeds the note read limit. Review and repair "
                    "it by hand; nothing was changed."
                )
            original.decode("utf-8")
        except (FileNotFoundError, NotADirectoryError) as exc:
            raise DocumentNotFoundError.note(path) from exc
        except (OSError, UnicodeDecodeError) as exc:
            raise DocumentUnreadableError(path, str(exc)) from exc
        return abs_path, original

    def okf_preview_log_repair(self, path: str) -> LogRepairPreview:
        """Preview one legacy log repair without changing files.

        Args:
            path: Vault-relative path ending in log.md.

        Returns:
            Exact candidate bytes and span, or an explanation for manual review.
        """
        with self.write_scope():
            _, original = self._log_repair_snapshot(path)
            return preview_log_repair(path, original)

    def okf_apply_log_repair(self, path: str, *, etag: str) -> LogRepairResult:
        """Apply a reviewed splice after retaining the complete original.

        Args:
            path: Exact vault-relative log.md path used for the preview.
            etag: The ``etag`` of the preview the operator reviewed.

        Returns:
            New byte etag and the adjacent complete-original recovery path.

        Raises:
            ConcurrentModificationError: The log changed since that preview.
            InvalidRequestError: No candidate remains, or the recovery path
                is occupied.
            LogRepairInterrupted: Retention or a later step failed; inspect before retry.
        """
        self.ensure_writable()
        with self.write_scope():
            abs_path, original = self._log_repair_snapshot(path)
            self._refuse_submodule(abs_path, "path", path)
            preview = preview_log_repair(path, original)
            require_reviewed(preview, etag)
            recovery = abs_path.with_name("log.md.frontmatter-repair.bak")
            recovery_path = recovery.relative_to(self._source_dir.resolve()).as_posix()
            target_attempted = False
            try:
                retain_original(recovery, original, recovery_path=recovery_path)
                self._notifier.fire(recovery, "", "write")
                check_if_match(abs_path, path, preview.etag)
                repaired = (
                    original[: preview.removal_start] + original[preview.removal_end :]
                )
                target_attempted = True
                atomic_write(abs_path, repaired)
                if self._mark_paths_dirty is not None:
                    self._mark_paths_dirty([path])
                self._notifier.fire(abs_path, repaired.decode("utf-8"), "write")
            except LogRepairCollision:
                raise
            except Exception as exc:
                raise LogRepairInterrupted(
                    recovery_path, target_may_have_changed=target_attempted
                ) from exc
            return LogRepairResult(
                path=path,
                etag=compute_etag(repaired),
                recovery_path=recovery_path,
                original_etag=preview.etag,
                removed_blocks=preview.removed_blocks,
            )

    # ------------------------------------------------------------------
    # Read operations
    # ------------------------------------------------------------------

    def read(self, path: str, *, section: str | None = None) -> NoteContent | None:
        """Read a document or a single section from disk.

        Args:
            path: Relative document path (e.g. ``"Journal/note.md"``).
            section: When provided, return the whole section whose heading
                matches *section* — its body and any sub-sections, up to the
                next heading at the same or higher level (case-sensitive;
                internal whitespace is collapsed before comparison). ``None``
                returns the whole document.

        Returns:
            A :class:`~markdown_vault_mcp.types.NoteContent`, or ``None`` in
            whole-document mode if there is no file at *path*: it does not
            exist, is not a regular file, or lies outside the vault. When ``section``
            is provided, the returned ``NoteContent.frontmatter`` is an empty
            dict ``{}`` because section reads do not synthesise per-section
            frontmatter. Call ``read(path)`` without ``section=`` to get the
            full document's frontmatter.

        Raises:
            DocumentUnreadableError: When the file exists but cannot be read:
                a failed stat or read, invalid UTF-8, or frontmatter that does
                not parse (#1608). Section mode raises it too.
            InvalidRequestError: When *path* holds a NUL byte (#1636), or
                *section* is provided and is empty / whitespace, or the
                document does not contain a section with that heading.
            DocumentNotFoundError: In section mode, when there is no such
                document ("no document" implies "no section").
        """
        reject_nul(path)
        if section is not None:
            if not section.strip():
                raise InvalidRequestError("section must be a non-empty heading or None")
            return self._read_section(path, section.strip())

        abs_path = (self._source_dir / path).resolve()
        if not abs_path.is_relative_to(self._source_dir.resolve()):
            return None
        # stat() rather than is_file(): on Python 3.14 is_file() answers False
        # for a path it cannot stat, which would report a fault as absence.
        try:
            file_stat = abs_path.stat()
        except (FileNotFoundError, NotADirectoryError):
            return None
        except OSError as exc:
            raise DocumentUnreadableError(path, str(exc)) from exc
        if not stat.S_ISREG(file_stat.st_mode):
            return None

        # Enforce MAX_NOTE_READ_BYTES (.md whole-document reads only — section=
        # reads short-circuit with an early return above; non-.md paths fall
        # through to parse_note(), so the cap stays scoped to its env-var name).
        is_md = path.lower().endswith(".md")
        if is_md and self._max_note_read_bytes > 0:
            size_bytes = file_stat.st_size
            if size_bytes > self._max_note_read_bytes:
                logger.info(
                    "read_refused_oversized path=%s size_bytes=%d limit_bytes=%d "
                    "setting=%s",
                    path,
                    size_bytes,
                    self._max_note_read_bytes,
                    "MARKDOWN_VAULT_MCP_MAX_NOTE_READ_BYTES",
                )
                raise NoteTooLargeError(
                    f"Document {path!r} is {size_bytes:,} bytes, over the "
                    f"{self._max_note_read_bytes:,}-byte limit this server "
                    "returns in one read. Read it a section at a time with "
                    f"read({path!r}, section=...); get_toc or a search result's "
                    "heading field names the sections."
                )

        # Guard both on-disk reads (parse_note's, and the content read below)
        # in one try. A file removed between the stat and here, or between the
        # two reads, is absent (#745). Anything else, a file that cannot be read
        # or whose frontmatter does not parse, raises DocumentUnreadableError
        # instead of leaking the raw exception (#742, #1608). parse_frontmatter
        # raises yaml.YAMLError for a JSON block too (#1408).
        # (parse_note decodes without universal-newline translation; the content
        # is read separately via _read_text_utf8, which applies it, so the two
        # reads are intentionally not collapsed — see #745.)
        try:
            note = parse_note(
                abs_path,
                self._source_dir,
                self._chunk_strategy,
                title_field=self._title_field,
            )
            raw_content = _read_text_utf8(abs_path)
        except (FileNotFoundError, NotADirectoryError):
            return None
        except (UnicodeDecodeError, OSError, yaml.YAMLError) as exc:
            raise DocumentUnreadableError(path, str(exc)) from exc

        etag = note.content_hash
        folder = str(Path(path).parent)
        if folder == ".":
            folder = ""

        return NoteContent(
            path=note.path,
            title=note.title,
            folder=folder,
            content=raw_content,
            frontmatter=note.frontmatter,
            modified_at=note.modified_at,
            etag=etag,
        )

    def _read_section(self, path: str, heading: str) -> NoteContent:
        """Return a NoteContent containing the full named section.

        The section is reconstructed from the document on disk: its span runs
        from just after the heading line to the next heading at the same or
        higher level (or end of document), so the *whole* section is returned
        even when the chunker fragmented it into several rows — an over-budget
        body split on paragraphs, or a parent split at its sub-headings (#741).
        Sub-sections under the requested heading are included.

        Args:
            path: Relative document path.
            heading: Heading string to match (internal whitespace collapsed;
                case-sensitive). When a document contains multiple sections
                with the same heading text, the first occurrence is returned.

        Returns:
            A :class:`~markdown_vault_mcp.types.NoteContent` with the
            section's content.  ``frontmatter`` is always ``{}`` because
            section reads do not synthesise per-section frontmatter; call
            :meth:`read` without ``section=`` to get the full document's
            frontmatter.

        Raises:
            DocumentNotFoundError: If the document is not indexed or its file no
                longer exists.
            InvalidRequestError: If the heading is not found.
            DocumentUnreadableError: If the file exists but cannot be read,
                decoded or parsed (#1608).
        """
        doc_row = self._fts.get_note(path)
        if doc_row is None:
            raise DocumentNotFoundError(
                f"Section '{heading}' not found in document {path}: "
                f"document is not indexed or does not exist. {FIND_NOTE}"
            )

        abs_path = self._validate_path(path)
        # The file decoded and parsed cleanly when it was indexed, but it may
        # have changed on disk since (the stale-index window). A file removed
        # since is absent, as in whole-document mode; one that no longer reads
        # or parses is DocumentUnreadableError, never "section not found" (#1608).
        try:
            text = _read_text_utf8(abs_path)
        except (FileNotFoundError, NotADirectoryError) as exc:
            raise DocumentNotFoundError(
                f"Section '{heading}' not found in document {path}: "
                f"the document no longer exists. {FIND_NOTE}"
            ) from exc
        except (UnicodeDecodeError, OSError) as exc:
            raise DocumentUnreadableError(path, str(exc)) from exc

        try:
            content = extract_section(text, heading)
        except yaml.YAMLError as exc:
            raise DocumentUnreadableError(path, str(exc)) from exc

        if content is None:
            # extract_section already parsed the frontmatter successfully above,
            # so list_section_headings (same parse) cannot raise here. Dedupe
            # so a repeated heading is suggested once and does not crowd the cap.
            available = list(dict.fromkeys(list_section_headings(text)))[:10]
            if available:
                suggestion = " — available headings include: " + ", ".join(
                    repr(h) for h in available
                )
            else:
                suggestion = " (document has no headings)"
            raise InvalidRequestError(
                f"Section '{heading}' not found in document {path}{suggestion}"
            )

        folder = str(Path(path).parent)
        if folder == ".":
            folder = ""

        return NoteContent(
            path=path,
            title=doc_row["title"],
            folder=folder,
            content=content,
            frontmatter={},  # section reads do not synthesise frontmatter
            modified_at=doc_row["modified_at"],
            etag="",  # ETag is whole-file; not meaningful for a section
        )

    def attachment_size(self, path: str) -> int:
        """Return the on-disk byte size of an attachment without reading it.

        Args:
            path: Relative attachment path.

        Returns:
            The file size in bytes (from ``stat``).

        Raises:
            InvalidRequestError: If the path escapes the source directory, ends
                with ``.md``, or has an extension not in the allowlist.
            DocumentNotFoundError: If no regular file is at the path.
            ValueError: If the file system refuses the ``stat`` or read.
        """
        return self._artifacts.size(path)

    def read_attachment(self, path: str) -> AttachmentContent:
        """Read the binary content of a non-.md attachment.

        Args:
            path: Relative attachment path (e.g. ``"assets/diagram.pdf"``).

        Returns:
            :class:`~markdown_vault_mcp.types.AttachmentContent` with
            base64-encoded content and MIME type.

        Raises:
            InvalidRequestError: If the path escapes the source directory, ends
                with ``.md``, or has an extension not in the allowlist.
            DocumentNotFoundError: If no regular file is at the path.
            ValueError: If the file system refuses the ``stat`` or read.
        """
        return self._artifacts.read(path)

    def get_toc(
        self,
        path: str,
        *,
        max_level: int | None = None,
        max_notes: int = 200,
    ) -> list[TocEntry] | SubtreeToc:
        """Return a table of contents for a note or a folder subtree.

        When *path* ends in ``.md`` the result is a single note's flat
        outline: a :class:`~markdown_vault_mcp.types.TocEntry` list with the
        document title prepended as a synthetic H1. Otherwise *path* is treated
        as a folder prefix and the result is a
        :class:`~markdown_vault_mcp.types.SubtreeToc` aggregating the subtree.

        Args:
            path: Note path (``"a/b.md"``) or folder prefix (``"a/b"``).
            max_level: If set, drop headings with ``level`` above this; must be
                ``>= 1``. The synthetic H1 title is always present regardless of
                ``max_level`` (it is prepended after the level filter).
            max_notes: Folder mode only — cap on distinct notes (default 200);
                must be ``>= 1``.

        Returns:
            Note mode: ``list[TocEntry]``. Folder mode: :class:`~markdown_vault_mcp.types.SubtreeToc`.

        Raises:
            InvalidRequestError: If ``max_notes < 1`` or ``max_level < 1``; if
                the path escapes the vault; folder mode, if *path* is empty or
                the vault root (``.``/``/``).
            DocumentNotFoundError: Note mode, if no document exists at *path*.
        """
        if max_notes < 1:
            raise InvalidRequestError(f"max_notes must be >= 1, got {max_notes!r}")
        if max_level is not None and max_level < 1:
            raise InvalidRequestError(f"max_level must be >= 1, got {max_level!r}")
        if is_note(path):
            return self._note_toc(path, max_level=max_level)
        return self._subtree_toc(path, max_level=max_level, max_notes=max_notes)

    @staticmethod
    def _prepend_title_h1(title: str, headings: list[TocEntry]) -> list[TocEntry]:
        """Prepend the document title as a synthetic H1, dropping any real H1 whose text matches the title."""
        toc: list[TocEntry] = [TocEntry(heading=title, level=1)]
        toc.extend(h for h in headings if not (h.level == 1 and h.heading == title))
        return toc

    def _note_toc(self, path: str, *, max_level: int | None) -> list[TocEntry]:
        """Return a single note's flat outline, title prepended as a synthetic H1."""
        self._validate_path(path)
        row = self._fts.get_note(path)
        if row is None:
            raise DocumentNotFoundError.note(path)
        title: str = row["title"]
        headings = self._fts.get_toc(path, max_level=max_level)
        return self._prepend_title_h1(title, headings)

    def _subtree_toc(
        self, path: str, *, max_level: int | None, max_notes: int
    ) -> SubtreeToc:
        """Return the nested-per-note TOC for every note under a folder prefix."""
        prefix = path.rstrip("/")
        self._validate_dir_path(prefix)
        notes_raw, truncated = self._fts.get_subtree_toc(
            prefix, max_level=max_level, max_notes=max_notes
        )
        # replace() copies path/title and swaps in the H1-prepended headings,
        # so a future SubtreeNote field is preserved automatically.
        notes = [
            replace(note, headings=self._prepend_title_h1(note.title, note.headings))
            for note in notes_raw
        ]
        return SubtreeToc(path=prefix, notes=notes, truncated=truncated)

    # ------------------------------------------------------------------
    # Write operations
    # ------------------------------------------------------------------

    def _check_no_clobber(
        self, abs_path: Path, path: str, if_match: str | None
    ) -> None:
        """Reject a blind overwrite when write protection is enabled.

        A write carrying an ``if_match`` etag is a deliberate replacement of
        content the caller has read, so it stays allowed; only a write that
        would replace a file the caller never looked at is refused.

        Args:
            abs_path: Absolute path of the target file.
            path: Vault-relative path, used in the error.
            if_match: Etag supplied by the caller, or ``None``.

        Raises:
            DocumentExistsError: If ``write_protect_existing`` is enabled,
                *if_match* is ``None``, and *abs_path* already exists.
        """
        if not self._write_protect_existing or if_match is not None:
            return
        if is_regular_file(abs_path):
            # The operator's setting goes in the log, not the model's text (#1639).
            logger.info(
                "write_refused_protected path=%s setting=%s",
                path,
                "MARKDOWN_VAULT_MCP_WRITE_PROTECT_EXISTING",
            )
            raise DocumentExistsError(
                f"{path} exists; overwriting requires proof of read: call "
                "'read', then retry with if_match=<etag> — or use 'edit' for "
                "targeted changes, or 'append' to add to the end. Do not "
                "delete and recreate: that destroys the note first and "
                "proves nothing. (This vault protects existing files from "
                "blind overwrites.)"
            )

    def write(
        self,
        path: str,
        content: str,
        frontmatter: dict[str, Any] | None = None,
        if_match: str | None = None,
        *,
        allow_overwrite: bool = False,
    ) -> WriteResult:
        """Create or overwrite a document.

        Creates intermediate directories as needed.  If *frontmatter* is
        provided, it is serialised as a YAML header in mapping insertion order,
        including nested mappings. YAML comments and formatting are not retained.

        Args:
            path: Relative document path.
            content: Markdown body (excluding frontmatter).
            frontmatter: Optional frontmatter dict serialised as YAML header.
            if_match: Optional etag from a previous :meth:`read` call.
                When provided, the write is only performed if the current
                file hash matches this value, preventing overwrites of
                concurrent modifications. Supplying *if_match* for a file
                that does not yet exist raises
                :exc:`~markdown_vault_mcp.exceptions.ConcurrentModificationError`.
                Pass ``None`` (default) to skip the check.
            allow_overwrite: Exempts this call from ``write_protect_existing``.
                Reserved for the server's own read-modify-write maintenance of
                generated files; not reachable from the ``write`` tool.

        Returns:
            :class:`~markdown_vault_mcp.types.WriteResult`.

        Raises:
            SubmodulePathError: If *path* lies inside a git submodule or
                nested repository (#1564, #1949).
            ReadOnlyError: If the vault is read-only.
            ConcurrentModificationError: If *if_match* is provided and does
                not match the current file hash (or the file does not exist).
            DocumentExistsError: If ``write_protect_existing`` is enabled and
                *path* already exists while no *if_match* is supplied.
            InvalidRequestError: If *path* escapes the source directory.
        """
        self._check_writable()
        with self._file_write_lock:
            abs_path = self._validate_path(path)
            self._refuse_submodule(abs_path, "path", path)
            if not allow_overwrite:
                self._check_no_clobber(abs_path, path, if_match)
            check_if_match(abs_path, path, if_match)
            created = not is_regular_file(abs_path)

            abs_path.parent.mkdir(parents=True, exist_ok=True)

            if frontmatter is not None:
                post = fm.Post(content, **frontmatter)
                file_content = fm.dumps(post, handler=YAML12_HANDLER, sort_keys=False)
            else:
                file_content = content

            stored = None if created else self._stored_for_enrich(abs_path, path)
            self._finalize_content_write(
                abs_path, path, file_content, "write", stored=stored
            )
            result = WriteResult(path=path, created=created)

        return result

    def _stored_for_enrich(self, abs_path: Path, path: str) -> str | None:
        """Read the note a ``write`` replaces, for the enforced-write layer.

        The layer carries the stored ``verified`` across (design §6), so it
        needs the bytes being replaced. Called with ``_file_write_lock`` held,
        so no server write lands between this read and the replacement.

        Args:
            abs_path: Absolute path of the existing file.
            path: Vault-relative path, for the log line.

        Returns:
            The stored text; ``None`` when the layer is off (nothing reads it)
            or the file is not UTF-8 text, which has no ``verified`` to keep.
        """
        if self._okf_write_enrich is None:
            return None
        try:
            return _read_text_utf8(abs_path)
        except UnicodeDecodeError:
            logger.warning("okf_write_stored_not_utf8 path=%s", path)
            return None

    def _finalize_content_write(
        self,
        abs_path: Path,
        path: str,
        content: str,
        operation: WriteOperation,
        *,
        stored: str | None,
    ) -> None:
        """Run the shared tail of every content write.

        Enriches *content* through the OKF enforced-write hook (when wired),
        writes it atomically, marks the path dirty for the index writer, and
        fires the write callback.  Must be called with ``_file_write_lock``
        held.

        Args:
            abs_path: Absolute path of the target file.
            path: Vault-relative path of the target file.
            content: Full file content to persist.
            operation: The write operation reported to the enricher and the
                write callback.
            stored: The file's text before this write, read under the same
                lock, or ``None`` for a new file. The enricher keeps its
                ``verified`` (design §6).
        """
        if self._okf_write_enrich is not None:
            # A block that does not parse makes no concept, so the layer
            # writes it as given rather than refusing it (#2486).
            content = self._okf_write_enrich(
                content, operation, path=path, stored=stored
            )
        atomic_write(abs_path, content)
        if self._mark_paths_dirty is not None:
            self._mark_paths_dirty([path])
        self._notifier.fire(abs_path, content, operation)

    def append(
        self,
        path: str,
        content: str,
        if_match: str | None = None,
        *,
        create_if_missing: bool = False,
    ) -> WriteResult:
        """Append *content* to the end of a document (#980).

        Unlike :meth:`edit`, no prior read is required: the existing file
        content is never part of the request.  When the file does not end
        with a newline, one is inserted before *content* so the appended
        text starts on its own line; otherwise *content* is written
        directly after the existing content.  Like every content write,
        the file is persisted in the vault's normalized form (UTF-8, no
        BOM, ``\\n`` line endings), so a CRLF file is normalized on its
        first append.

        Args:
            path: Relative document path.
            content: Text to append.  Must be non-empty.
            if_match: Optional etag from a previous :meth:`read` call.
                When provided, the append is only performed if the current
                file hash matches this value.  Pass ``None`` (default) to
                append unconditionally.
            create_if_missing: When ``True``, a missing document is created
                with *content* as its body instead of raising
                :exc:`~markdown_vault_mcp.exceptions.DocumentNotFoundError`.

        Returns:
            :class:`~markdown_vault_mcp.types.WriteResult` — ``created`` is
            ``True`` only when *create_if_missing* created a new file.

        Raises:
            SubmodulePathError: If *path* lies inside a git submodule or
                nested repository (#1564, #1949).
            ReadOnlyError: If the vault is read-only.
            DocumentNotFoundError: If the file does not exist and
                *create_if_missing* is ``False``.
            ConcurrentModificationError: If *if_match* is provided and does
                not match the current file hash (or the file is missing).
            InvalidRequestError: If *content* is empty or *path* escapes the
                source directory.
        """
        self._check_writable()
        if not content:
            raise InvalidRequestError("content must not be empty")

        with self._file_write_lock:
            abs_path = self._validate_path(path)
            self._refuse_submodule(abs_path, "path", path)
            existed = is_regular_file(abs_path)
            if not existed and not create_if_missing:
                raise DocumentNotFoundError.note(path)
            check_if_match(abs_path, path, if_match)

            if existed:
                file_content = _read_text_utf8(abs_path)
                needs_newline = bool(file_content) and not file_content.endswith("\n")
                new_content = file_content + ("\n" if needs_newline else "") + content
            else:
                abs_path.parent.mkdir(parents=True, exist_ok=True)
                new_content = content

            # An append is a content edit for the enforced-write layer and
            # the git commit callback alike.
            self._finalize_content_write(
                abs_path,
                path,
                new_content,
                "edit",
                stored=file_content if existed else None,
            )
            result = WriteResult(path=path, created=not existed)

        return result

    def write_attachment(
        self,
        path: str,
        content: bytes,
        if_match: str | None = None,
    ) -> WriteResult:
        """Create or overwrite a non-.md attachment.

        Args:
            path: Relative attachment path (e.g. ``"assets/diagram.pdf"``).
            content: Raw bytes to write.
            if_match: Optional etag from a previous :meth:`read_attachment`
                call. When provided, the write is only performed if the
                current file hash matches this value, preventing overwrites
                of concurrent modifications. Pass ``None`` (default) to skip
                the check.

        Returns:
            :class:`~markdown_vault_mcp.types.WriteResult`.

        Raises:
            SubmodulePathError: If *path* lies inside a git submodule or
                nested repository (#1564, #1949).
            ReadOnlyError: If the vault is read-only.
            ConcurrentModificationError: If *if_match* is provided and does
                not match the current file hash, or *if_match* is supplied
                for a file that does not yet exist.
            DocumentExistsError: If ``write_protect_existing`` is enabled and
                *path* already exists while no *if_match* is supplied.
            InvalidRequestError: If the path escapes the source directory or
                has an extension not in the allowlist.
        """
        return self._artifacts.write(path, content, if_match)

    def edit(
        self,
        path: str,
        old_text: str | None = None,
        new_text: str = "",
        if_match: str | None = None,
        line_start: int | None = None,
        line_end: int | None = None,
    ) -> EditResult:
        """Patch a section of a document.

        Supports three modes:

        - **Exact match** (``old_text`` only): verifies *old_text* exists
          exactly once in the full file content (including frontmatter),
          replaces it with *new_text*.
        - **Line-range** (``line_start``/``line_end`` only): replaces the
          specified line range with *new_text*.
        - **Scoped match** (both): searches for *old_text* only within the
          specified line range, allowing disambiguation of repeated text.

        When exact match fails, a normalized comparison is attempted
        (Unicode NFC, dash/quote normalization, whitespace collapsing).
        If a unique normalized match is found, it is used and
        ``match_type="normalized"`` is returned.

        Args:
            path: Relative document path.
            old_text: Text to replace. Required for exact-match and
                scoped-match modes.  Must appear exactly once (in the
                file or in the line range).
            new_text: Replacement text. In line-range mode an empty string
                (``""``) removes the selected lines entirely (#1607).
            if_match: Optional etag from a previous :meth:`read` call.
                When provided, the edit is only performed if the current
                file hash matches this value, preventing edits based on
                stale content. Pass ``None`` (default) to skip the check.
            line_start: First line to replace (1-based, inclusive).
                Must be provided together with *line_end*.
            line_end: Last line to replace (1-based, inclusive).
                Must be provided together with *line_start*.

        Returns:
            :class:`~markdown_vault_mcp.types.EditResult`.

        Raises:
            SubmodulePathError: If *path* lies inside a git submodule or
                nested repository (#1564, #1949).
            ReadOnlyError: If the vault is read-only.
            DocumentNotFoundError: If the file does not exist.
            ConcurrentModificationError: If *if_match* is provided and does
                not match the current file hash.
            EditConflictError: If *old_text* is not found or appears
                more than once.
            InvalidRequestError: If parameter combination is invalid, or line
                numbers are out of range.
        """
        self._check_writable()

        # --- Parameter validation ---
        if old_text is not None and not old_text:
            raise InvalidRequestError("old_text must not be empty")
        has_lines = line_start is not None or line_end is not None
        if old_text is None and not has_lines:
            raise InvalidRequestError(
                "Must provide old_text, line_start/line_end, or both"
            )
        if (line_start is None) != (line_end is None):
            raise InvalidRequestError(
                "Must provide both line_start and line_end, not just one"
            )
        if line_start is not None and line_end is not None:
            if line_start < 1:
                raise InvalidRequestError("line_start must be >= 1 (lines are 1-based)")
            if line_start > line_end:
                raise InvalidRequestError(
                    f"line_start ({line_start}) must be <= line_end ({line_end})"
                )

        with self._file_write_lock:
            abs_path = self._validate_path(path)
            self._refuse_submodule(abs_path, "path", path)
            if not is_regular_file(abs_path):
                raise DocumentNotFoundError.note(path)

            check_if_match(abs_path, path, if_match)

            file_content = _read_text_utf8(abs_path)

            if has_lines:
                assert line_start is not None and line_end is not None
                new_content, match_type = self._edit_with_lines(
                    file_content,
                    old_text,
                    new_text,
                    line_start,
                    line_end,
                    path,
                )
            else:
                assert old_text is not None
                new_content, match_type = self._edit_with_text(
                    file_content, old_text, new_text, path
                )

            self._finalize_content_write(
                abs_path, path, new_content, "edit", stored=file_content
            )

        return EditResult(path=path, replacements=1, match_type=match_type)

    def _edit_with_lines(
        self,
        file_content: str,
        old_text: str | None,
        new_text: str,
        line_start: int,
        line_end: int,
        path: str,
    ) -> tuple[str, str]:
        """Handle line-range and scoped-match edit modes.

        Returns:
            Tuple of (new_file_content, match_type).
        """
        lines = file_content.split("\n")
        total_lines = len(lines) - 1 if lines and lines[-1] == "" else len(lines)
        if line_end > total_lines:
            raise InvalidRequestError(
                f"line_end ({line_end}) out of range (file has {total_lines} lines)"
            )

        start_idx = line_start - 1
        end_idx = line_end

        if old_text is not None:
            scope = "\n".join(lines[start_idx:end_idx])
            context_desc = f"lines {line_start}-{line_end} of {path}"
            new_scope, match_type = self._match_and_replace(
                scope, old_text, new_text, path, context_desc=context_desc
            )
            lines[start_idx:end_idx] = new_scope.split("\n")
        else:
            match_type = "exact"
            # Empty new_text removes the range rather than blanking it (#1607).
            replacement_lines = new_text.rstrip("\n").split("\n") if new_text else []
            lines[start_idx:end_idx] = replacement_lines

        return "\n".join(lines), match_type

    def _edit_with_text(
        self,
        file_content: str,
        old_text: str,
        new_text: str,
        path: str,
    ) -> tuple[str, str]:
        """Handle exact-match edit mode (with normalized fallback).

        Returns:
            Tuple of (new_file_content, match_type).
        """
        return self._match_and_replace(file_content, old_text, new_text, path)

    def _match_and_replace(
        self,
        content: str,
        old_text: str,
        new_text: str,
        path: str,
        context_desc: str | None = None,
    ) -> tuple[str, str]:
        """Try exact match, then normalized match, then raise with diagnostics.

        Args:
            content: The text to search within (full file or line-range scope).
            old_text: Text to find and replace.
            new_text: Replacement text.
            path: Vault-relative file path, used in error messages.
            context_desc: Optional human-readable context for error messages.

        Returns:
            Tuple of (new_content, match_type).
        """
        location = context_desc or path
        count = content.count(old_text)

        if count == 1:
            return content.replace(old_text, new_text, 1), "exact"

        if count > 1:
            raise EditConflictError(
                f"old_text appears {count} times in {location}; "
                f"must appear exactly once. {_DISAMBIGUATE}"
            )

        # count == 0: try normalized matching.
        normalized_content = _normalize_text(content)
        normalized_old = _normalize_text(old_text)
        norm_count = normalized_content.count(normalized_old)

        if norm_count == 1:
            pos_map = _build_position_map(content, normalized_content)
            norm_start = normalized_content.index(normalized_old)
            norm_end = norm_start + len(normalized_old)
            orig_start = pos_map[norm_start]
            orig_end = pos_map[norm_end]
            new_content = content[:orig_start] + new_text + content[orig_end:]
            return new_content, "normalized"

        if norm_count > 1:
            raise EditConflictError(
                f"old_text appears {norm_count} times in {location} after "
                f"normalization; must appear exactly once. {_DISAMBIGUATE}"
            )

        # norm_count == 0: raise with diagnostics.
        diag = _find_closest_match(old_text, content)
        raise EditConflictError(f"old_text not found in {location}", **diag)

    def delete(self, path: str, if_match: str | None = None) -> DeleteResult:
        """Delete a document or attachment.

        Removes the file from disk.  For ``.md`` documents, also removes all
        FTS and embedding index entries.  For attachments, only the file is
        deleted (no index update).

        Args:
            path: Relative document or attachment path.
            if_match: Optional etag from a previous :meth:`read` or
                :meth:`read_attachment` call. When provided, the deletion is
                only performed if the current file hash matches this value.
                Pass ``None`` (default) to skip the check.

        Returns:
            :class:`~markdown_vault_mcp.types.DeleteResult`.

        Raises:
            SubmodulePathError: If *path* lies inside a git submodule or
                nested repository (#1564, #1949).
            ReadOnlyError: If the vault is read-only.
            DocumentNotFoundError: If the file does not exist.
            ConcurrentModificationError: If *if_match* is provided and does
                not match the current file hash.
            InvalidRequestError: If the path escapes the source directory, or
                a non-.md path has an extension not in the attachment allowlist.
        """
        self._check_writable()
        with self._file_write_lock:
            if is_note(path):
                abs_path = self._validate_path(path)
                self._refuse_submodule(abs_path, "path", path)
                if not is_regular_file(abs_path):
                    raise DocumentNotFoundError.note(path)
                check_if_match(abs_path, path, if_match)
                abs_path.unlink()
                if self._mark_paths_dirty is not None:
                    self._mark_paths_dirty([path])
            else:
                abs_path = self._artifacts.unlink(path, if_match)

            self._notifier.fire(abs_path, "", "delete")

        return DeleteResult(path=path)

    def rename(
        self,
        old_path: str,
        new_path: str,
        if_match: str | None = None,
        *,
        update_links: bool = False,
        tolerate_link_rewrites: bool = False,
    ) -> RenameResult:
        """Rename or move a document or attachment.

        Renames the file on disk.  For ``.md`` documents, also updates FTS
        and embedding index entries.  For attachments, only the file is moved
        (no index update).  Creates intermediate directories for *new_path*
        as needed.

        When *update_links* is ``True`` and *old_path* is a ``.md`` document,
        every document that links to *old_path* is also updated so its links
        point to *new_path*.  For an attachment the flag does not apply —
        references to attachments are not tracked as links — and the result's
        *hint* says so instead of reporting a bare ``0`` (#1338).

        Args:
            old_path: Current relative document or attachment path.
            new_path: Target relative document or attachment path.
            if_match: Optional etag from a previous :meth:`read` or
                :meth:`read_attachment` call for *old_path*. When provided,
                the rename is only performed if the current file hash matches
                this value. Pass ``None`` (default) to skip the check.
            update_links: When ``True``, find all documents that link to
                *old_path* and rewrite their link targets to point to
                *new_path*. Also preserve resolved outgoing vault-fallback
                links when the source note moves. Those changes may invalidate
                its old etag; read *new_path* before a guarded write. Only
                applies to ``.md`` documents.
            tolerate_link_rewrites: When ``True``, a note's *if_match* that
                no longer matches is still accepted if every change since
                it is a link rewrite this manager recorded, such as one a
                rename made a moment earlier (#1492). The note's current
                bytes move, so those rewrites are kept. ``False`` (default)
                keeps the whole-file check strict.

        Returns:
            :class:`~markdown_vault_mcp.types.RenameResult` with
            *updated_links* counting source documents successfully updated,
            *hint* set when *update_links* was requested for an attachment,
            and *link_rewrites_since_etag* set when *if_match* was accepted
            across recorded link rewrites.

        Raises:
            SubmodulePathError: If either path lies inside a git submodule
                or nested repository (#1564, #1949).
            ReadOnlyError: If the vault is read-only.
            TimeoutError: If the configured index refresh times out.
            DocumentNotFoundError: If *old_path* does not exist.
            DocumentExistsError: If *new_path* already exists.
            ConcurrentModificationError: If *if_match* is provided and does
                not match the current hash of *old_path*, and
                *tolerate_link_rewrites* does not accept it.
            InvalidRequestError: If either path escapes the source directory,
                or a non-.md path has an extension not in the attachment
                allowlist.
        """
        self._check_writable()
        updated_links = 0
        hint: str | None = None
        crossed: int | None = None
        backlink_callbacks: list[tuple[Path, str]] = []
        if update_links and is_note(old_path):
            self.ensure_index_current()

        with self._file_write_lock:
            if is_note(old_path):
                old_abs = self._validate_path(old_path)
                new_abs = self._validate_path(new_path)
                self._refuse_submodule(old_abs, "old_path", old_path)
                self._refuse_submodule(new_abs, "new_path", new_path)

                if not is_regular_file(old_abs):
                    raise DocumentNotFoundError.note(old_path)
                if is_regular_file(new_abs):
                    raise DocumentExistsError(
                        f"Target already exists: {new_path!r}. Pass a new_path "
                        "that is free; list_documents shows what exists."
                    )
                crossed = self._check_rename_etag(
                    old_abs, old_path, if_match, tolerate=tolerate_link_rewrites
                )

                backlinks = self._fts.get_backlinks(old_path) if update_links else []
                outgoing = self._fallback_outgoing(old_path) if update_links else []

                new_abs.parent.mkdir(parents=True, exist_ok=True)
                shutil.move(str(old_abs), str(new_abs))

                note = parse_note(
                    new_abs,
                    self._source_dir,
                    self._chunk_strategy,
                    title_field=self._title_field,
                )

                backlink_callbacks, backlink_paths, unrewritten = (
                    self._update_backlinks(old_path, new_path, backlinks, outgoing)
                )
                callback_content = _read_text_utf8(new_abs)
                updated_links = len(set(backlink_paths))
                hint = self._submodule_links_hint(unrewritten)
                if new_path in unrewritten:
                    warning = (
                        f"Note {new_path!r} moved but its links could not be rewritten; "
                        "a link may now point to a different file. Check its links "
                        "or rename it back."
                    )
                    hint = f"{hint} {warning}" if hint else warning

                if self._mark_paths_dirty is not None:
                    dirty: list[str] = [old_path, note.path]
                    dirty.extend(backlink_paths)
                    self._mark_paths_dirty(dirty)
            else:
                old_abs, new_abs = self._artifacts.move(old_path, new_path, if_match)
                callback_content = ""
                if update_links:
                    hint = _ATTACHMENT_UPDATE_LINKS_HINT

            self._notifier.fire_rename(new_abs, callback_content, old_abs)
            with auxiliary_commit_writes():
                for src_abs, src_content in backlink_callbacks:
                    if src_abs == new_abs:
                        continue
                    self._notifier.fire(src_abs, src_content, "edit")

        return RenameResult(
            old_path=old_path,
            new_path=new_path,
            updated_links=updated_links,
            hint=hint,
            link_rewrites_since_etag=crossed,
        )

    def _fallback_outgoing(self, source: str) -> list[tuple[str, dict[str, Any]]]:
        """Capture live markdown links resolved beyond their source directory."""
        result: list[tuple[str, dict[str, Any]]] = []
        for row in self._fts.get_outlinks(source):
            if row["link_type"] not in ("markdown", "reference"):
                continue
            if not row["raw_target"] or not row["target_exists"]:
                continue
            baseline, _ = _resolve_link_path(
                row["raw_target"], source, decode_markdown=True
            )
            target = row["target_path"]
            if baseline is not None and baseline != target:
                row["source_path"] = source
                result.append((target, row))
        return result

    def _check_rename_etag(
        self, abs_path: Path, path: str, if_match: str | None, *, tolerate: bool
    ) -> int | None:
        """Check a note's rename etag, crossing recorded link rewrites if allowed.

        Args:
            abs_path: Absolute path of the note, which exists.
            path: Vault-relative path of the note.
            if_match: The caller's etag, or ``None`` for no check.
            tolerate: Whether a stale etag may be accepted across the link
                rewrites :attr:`_link_rewrites` holds for *path*.

        Returns:
            How many recorded rewrites the etag was accepted across, or
            ``None`` when it matched outright or no check was asked for.

        Raises:
            ConcurrentModificationError: If *if_match* does not match and
                the recorded rewrites do not lead from it to the note's
                current hash.
        """
        try:
            check_if_match(abs_path, path, if_match)
        except ConcurrentModificationError as exc:
            if not tolerate or if_match is None:
                raise
            # The ledger keys on the index's spelling of the path, so
            # "./b.md" must find the entries recorded for "b.md".
            crossed = self._link_rewrites.rewrites_since(
                posixpath.normpath(path), etag=if_match, current=exc.actual
            )
            if crossed is None:
                raise
            logger.info(
                "rename_etag_crossed_link_rewrites path=%s rewrites=%d",
                path,
                crossed,
            )
            return crossed
        return None

    def _rewrite_one_source(
        self,
        source_abs: Path,
        rewrites: list[tuple[str, str, str | None, str, str]],
        source_path: str,
    ) -> str | None:
        """Rewrite all link targets in a single source file in one pass.

        Reads *source_abs*, applies every ``(link_type, raw_target, fragment,
        target_old, target_new)`` rewrite using the source's *current* vault
        path (which, for a moved source, is its new path), and writes the
        result back atomically.

        Args:
            source_abs: Absolute path of the source file to rewrite (its
                current on-disk location).
            rewrites: One tuple per link to rewrite:
                ``(link_type, raw_target, fragment, target_old, target_new)``.
            source_path: Vault-relative path of the source at its current
                location — used for correct relative-path computation.

        Returns:
            The rewritten file content, or ``None`` when the file is already
            as the rewrite would leave it. The caller must not count, write
            back or announce such a source.

        Raises:
            ValueError: A selected destination was not found in the file, so
                the source is left unwritten and still names the old target;
                saying otherwise is what made #1521 silent.
        """
        # One read, hashed as is: a second read could see an external edit
        # the ledger would then vouch for (#1492). Newlines are normalised
        # as Path.read_text would, which the rewrite has always relied on.
        raw = source_abs.read_bytes()
        original = _decode_utf8(raw).replace("\r\n", "\n").replace("\r", "\n")
        content, unmatched = self._apply_rewrites(original, rewrites, source_path)
        if unmatched:
            # All or nothing per source, decided before anything is written:
            # the index held a row the rewrite could not find. That is a
            # disagreement between the two, logged because #1521 was exactly
            # this, invisible; a partly rewritten note would still name the
            # old target through the spellings it missed.
            logger.warning(
                "link_rewrite_matched_nothing source=%s links=%d",
                source_path,
                len(rewrites),
            )
            raise ValueError(
                f"link rewrite of {source_path!r} found no destination for "
                f"{sorted(unmatched)!r}"
            )
        if content == original:
            return None
        # The bytes a text-mode write would produce, encoded here so the
        # ledger records the hash of exactly what landed.
        encoded = content.replace("\n", os.linesep).encode("utf-8")
        atomic_write(source_abs, encoded)
        self._link_rewrites.record(
            source_path, compute_etag(raw), compute_etag(encoded)
        )
        return content

    def _apply_rewrites(
        self,
        original: str,
        rewrites: list[tuple[str, str, str | None, str, str]],
        source_path: str,
    ) -> tuple[str, set[str]]:
        """Apply *rewrites* to a note's body, keeping its frontmatter verbatim.

        Args:
            original: Whole note text with line endings normalised.
            rewrites: ``(link_type, raw_target, fragment, target_old,
                target_new)`` per link, as in :meth:`_rewrite_one_source`.
            source_path: Vault-relative path of the source at its current
                location.

        Returns:
            ``(content, unmatched)``: the rewritten text and the written
            destinations no scan of the body found.
        """
        body = strip_frontmatter_block(original)
        head = original[: len(original) - len(body)]
        replacements: dict[str, dict[str, str]] = defaultdict(dict)
        for link_type, raw_target, fragment, target_old, target_new in rewrites:
            replacements[link_type].setdefault(
                raw_target,
                _compute_new_raw_target(
                    link_type,
                    raw_target,
                    fragment,
                    target_new,
                    source_path=source_path,
                    old_path=target_old,
                ),
            )
        unmatched: set[str] = set()
        for link_type, mapping in replacements.items():
            body, matched = _rewrite_link_destinations(body, link_type, mapping)
            unmatched.update(set(mapping) - matched)
        return head + body, unmatched

    def _rewrite_link_sources(
        self,
        by_source: dict[str, list[tuple[str, dict[str, Any]]]],
        target_map: dict[str, str],
        *,
        op_name: str,
    ) -> tuple[list[tuple[Path, str]], list[str], list[str]]:
        """Rewrite link targets in each grouped source file (best effort).

        Shared engine behind :meth:`rename` (single target) and
        :meth:`move_folder` (many targets). A source that cannot be
        rewritten is logged and reported without aborting the operation.

        This method must be called while ``_file_write_lock`` is held. It
        does **not** fire write callbacks or mark paths dirty itself — the
        caller is responsible for both.

        Args:
            by_source: Mapping of source path (at its *current* on-disk
                location) to ``(target_old, backlink_row)`` pairs to rewrite
                within that source.
            target_map: Mapping of moved target paths to their new paths;
                targets absent from the map remain at their old paths.
            op_name: Caller name used as the log-message prefix.

        Returns:
            Tuple ``(callbacks, dirty_paths, failed_sources)``:

            * ``callbacks`` — ``(abs_path, new_content)`` pairs for every
              source document whose bytes actually changed. A source the
              rewrite left untouched is in none of the three lists: it is
              not a failure, but it is not an update either (#1521).
            * ``dirty_paths`` — vault-relative paths of those same sources,
              for the caller to feed to ``mark_paths_dirty``.
            * ``failed_sources`` — sources that were skipped or failed.
        """
        pending_callbacks: list[tuple[Path, str]] = []
        dirty_paths: list[str] = []
        failed_sources: list[str] = []
        for source_path, items in by_source.items():
            try:
                source_abs = self._validate_path(source_path)
                if self.in_submodule(source_path):
                    # Expected in a vault with submodules: not degraded.
                    logger.info(
                        "link_rewrite_source_skipped op=%s path=%s reason=submodule",
                        op_name,
                        source_path,
                    )
                    failed_sources.append(source_path)
                    continue
                if not is_regular_file(source_abs):
                    logger.warning(
                        "link_rewrite_source_skipped op=%s path=%s reason=not_found",
                        op_name,
                        source_path,
                    )
                    failed_sources.append(source_path)
                    continue
                rewrites = [
                    (
                        row["link_type"],
                        row["raw_target"],
                        row["fragment"],
                        target_old,
                        target_map.get(target_old, target_old),
                    )
                    for target_old, row in items
                ]
                content = self._rewrite_one_source(source_abs, rewrites, source_path)
                if content is None:
                    # Nothing changed on disk, so there is nothing to
                    # reindex, announce or count (#1521).
                    continue
                pending_callbacks.append((source_abs, content))
                dirty_paths.append(source_path)
            except (OSError, UnicodeDecodeError, ValueError, sqlite3.Error) as exc:
                logger.warning(
                    "link_rewrite_source_failed op=%s path=%s err=%s",
                    op_name,
                    source_path,
                    exc,
                )
                failed_sources.append(source_path)
            except Exception as exc:
                logger.warning(
                    "link_rewrite_source_unexpected_error op=%s path=%s err=%s",
                    op_name,
                    source_path,
                    exc,
                    exc_info=True,
                )
                failed_sources.append(source_path)
        return pending_callbacks, dirty_paths, failed_sources

    def _submodule_links_hint(self, unrewritten: list[str]) -> str | None:
        """Build the protected-backlink hint without aborting a completed rename."""
        in_submodules = []
        for source in unrewritten:
            try:
                if self.in_submodule(source):
                    in_submodules.append(source)
            except OSError as exc:
                # Diagnostic inspection must not prevent index/Git notification.
                logger.debug(
                    "submodule_hint_check_failed path=%s error=%s", source, exc
                )
                continue
        return _submodule_links_text(in_submodules) if in_submodules else None

    def _update_backlinks(
        self,
        old_path: str,
        new_path: str,
        backlinks: list[dict[str, Any]],
        outgoing: Iterable[tuple[str, dict[str, Any]]] = (),
    ) -> tuple[list[tuple[Path, str]], list[str], list[str]]:
        """Rewrite source files that link to *old_path* to point to *new_path*.

        Called by :meth:`rename` after the file has already been moved on
        disk.  Each source file is read, all of its links to *old_path*
        are rewritten in a single pass, then written back.

        This method must be called while ``_file_write_lock`` is held.  It
        does **not** fire write callbacks or mark paths dirty itself —
        :meth:`rename` is responsible for both, using the returned
        ``callbacks`` and ``dirty_paths``.

        Args:
            old_path: Vault-relative path that was renamed (the old location).
            new_path: Vault-relative path after the rename (the new location).
            backlinks: Rows returned by :meth:`FTSIndex.get_backlinks` before
                the rename.
            outgoing: Resolved fallback links in the moved source.

        Returns:
            Tuple ``(callbacks, dirty_paths, failed_sources)``:

            * ``callbacks`` — list of ``(abs_path, new_content)`` pairs for
              every source document that was successfully rewritten.
            * ``dirty_paths`` — vault-relative paths of those same source
              documents, for the caller to feed to
              ``mark_paths_dirty``.
            * ``failed_sources`` — sources left naming *old_path*, such as
              a note inside a git submodule or nested repository (#1564).
        """
        by_source: dict[str, list[tuple[str, dict[str, Any]]]] = defaultdict(list)
        for row in backlinks:
            by_source[row["source_path"]].append((old_path, row))

        if old_path in by_source:
            by_source[new_path] = by_source.pop(old_path)

        target_map = {old_path: new_path}
        for target, row in outgoing:
            if target != old_path:
                by_source[new_path].append((target, row))

        return self._rewrite_link_sources(
            by_source, target_map, op_name="_update_backlinks"
        )

    def _plan_folder_move(
        self, old_abs: Path, old_dir: str, new_dir: str
    ) -> tuple[list[tuple[Path, Path]], dict[str, str], list[tuple[Path, str, Path]]]:
        """Enumerate the subtree under *old_abs* and gate on collisions.

        Pure planning: walks the filesystem (not the index — attachments and
        other files are not indexed), classifies each file, and fails before
        anything moves if a destination already exists.

        Args:
            old_abs: Absolute path of the source folder.
            old_dir: Vault-relative source prefix, as passed by the caller
                (used verbatim in error messages).
            new_dir: Vault-relative target prefix.

        Returns:
            Tuple ``(moves, md_map, non_note_moves)``:

            * ``moves`` — ``(src_abs, dst_abs)`` for every file to move.
            * ``md_map`` — old→new vault-relative path map (``.md`` only).
            * ``non_note_moves`` — ``(dst_abs, new_rel_path, src_abs)`` for
              every other moved file, allowlisted or not (#1238).

        Raises:
            DocumentNotFoundError: If the folder contains no files.
            DocumentExistsError: If any destination file already exists.
            SubmodulePathError: If a destination lies inside a git submodule
                or nested repository,
                checked before collisions so the refusal names the real cause.
        """
        old_rel = old_dir.strip("/")
        new_rel = new_dir.strip("/")
        moves: list[tuple[Path, Path]] = []  # (src_abs, dst_abs)
        md_map: dict[str, str] = {}  # old_rel_path -> new_rel_path (.md only)
        # (dst_abs, new_rel, src_abs) — src_abs so the rename callback can
        # scope its git staging to both sides of the move (#894).
        non_note_moves: list[tuple[Path, str, Path]] = []
        # A strict walk: an unreadable subfolder is a fault, not an empty one
        # whose files would be left behind (#1625).
        for src_abs in walk_files_strict(old_abs):
            if not is_regular_file(src_abs):
                continue
            rel_within = src_abs.relative_to(old_abs).as_posix()
            old_path = f"{old_rel}/{rel_within}"
            new_path = f"{new_rel}/{rel_within}"
            dst_abs = (self._source_dir / new_path).resolve()
            self._refuse_move_into_submodule(dst_abs, new_dir, new_path)
            moves.append((src_abs, dst_abs))
            if is_note(old_path):
                md_map[old_path] = new_path
            else:
                # Every non-note file that moves gets a rename callback, not
                # just allowlisted ones (#1238). The allowlist governs which
                # files the *tools* expose, not what the repository tracks:
                # git staging is scoped to the paths a callback names, so a
                # file moved without one is left as an unstaged delete plus an
                # untracked add, and never committed.
                non_note_moves.append((dst_abs, new_path, src_abs))

        if not moves:
            raise DocumentNotFoundError(
                f"Folder is empty: {old_dir!r}, so there is nothing to move. "
                "Pick a folder with notes in it; list_folders shows them."
            )

        # Atomic collision gate — fail before moving anything.
        for _src_abs, dst_abs in moves:
            if path_exists(dst_abs):
                rel = dst_abs.relative_to(self._source_dir.resolve()).as_posix()
                raise DocumentExistsError(
                    f"Target already exists: {rel!r}. Pass a new_dir where "
                    "nothing is in the way."
                )

        return moves, md_map, non_note_moves

    def _refuse_move_into_submodule(
        self, dst_abs: Path, new_dir: str, new_path: str
    ) -> None:
        """Refuse a folder move landing in a submodule or nested repository.

        *new_dir* may hold one; only a destination inside one is lost.
        """
        guard = self._submodule_guard
        found = (
            guard.submodule_of(dst_abs, holding=False) if guard is not None else None
        )
        if found is not None and found[1]:
            raise SubmodulePathError.into("new_dir", new_dir, found[0], new_path)

    def _dispatch_move_callbacks(
        self,
        md_map: dict[str, str],
        non_note_moves: list[tuple[Path, str, Path]],
        pending_callbacks: list[tuple[Path, str]],
    ) -> None:
        """Fire write callbacks for a completed folder move.

        Emits ``rename`` for every moved file — notes and everything else
        alike — and ``edit`` for every rewritten source. A source inside the
        moved subtree already gets a ``rename`` callback (it is in *md_map*),
        so its redundant ``edit`` is skipped to avoid a duplicate git commit.

        Args:
            md_map: Old→new vault-relative path map for moved notes.
            non_note_moves: ``(dst_abs, new_rel_path, src_abs)`` for every
                moved file that is not a note (#1238).
            pending_callbacks: ``(abs_path, new_content)`` for rewritten
                link sources.
        """
        moved_note_paths = set(md_map.values())
        source_root = self._source_dir.resolve()
        for old_path, new_path in md_map.items():
            new_note_abs = (self._source_dir / new_path).resolve()
            self._notifier.fire_rename(
                new_note_abs,
                _read_text_utf8(new_note_abs),
                (self._source_dir / old_path).resolve(),
            )
        for dst_abs, _new_rel, src_abs_moved in non_note_moves:
            self._notifier.fire_rename(dst_abs, "", src_abs_moved)
        for src_abs, src_content in pending_callbacks:
            src_rel = src_abs.relative_to(source_root).as_posix()
            if src_rel in moved_note_paths:
                continue
            self._notifier.fire(src_abs, src_content, "edit")

    def move_folder(self, old_dir: str, new_dir: str) -> MoveFolderResult:
        """Move an entire folder subtree to a new prefix, rewriting links.

        Moves every file under *old_dir* (``.md`` notes, allowlisted
        attachments, and any other files) to the matching path under
        *new_dir*, preserving relative structure. All links across the vault
        that point into the moved subtree — including links *between*
        documents inside it — are rewritten in a single pass.

        The move is atomic at the gate: if any destination file path already
        exists, the operation raises before moving anything. Link rewrites are
        best-effort: a source that cannot be rewritten is logged and reported
        in :attr:`MoveFolderResult.failed_links` without aborting the move.

        Args:
            old_dir: Relative source folder prefix (e.g. ``"drafts"``).
            new_dir: Relative target folder prefix (e.g. ``"archive/2026"``).

        Returns:
            :class:`~markdown_vault_mcp.types.MoveFolderResult`.

        Raises:
            SubmodulePathError: If *old_dir* lies in or holds a git submodule
                or nested repository,
                or a moved file would land inside one (#1564).
            ReadOnlyError: If the vault is read-only.
            TimeoutError: If the configured index refresh times out.
            DocumentNotFoundError: If *old_dir* is missing, not a directory,
                or empty.
            DocumentExistsError: If any destination file already exists.
            InvalidRequestError: If either path escapes the vault, is the vault
                root, or one path is nested inside the other.
            FolderMoveInterruptedError: If the OS raises while files are
                being moved (e.g. a permission error, full disk, or concurrent
                file removal). The pre-move collision gate prevents
                destination clashes, but an OS error mid-move can leave the
                subtree partially moved with the index unchanged; a
                subsequent reindex reconciles the index with the on-disk
                state. It subclasses :class:`OSError`.
        """
        self._check_writable()
        self.ensure_index_current()

        with self._file_write_lock:
            old_abs = self._validate_dir_path(old_dir)
            new_abs = self._validate_dir_path(new_dir)
            self._refuse_submodule(old_abs, "old_dir", old_dir)
            self._refuse_submodule(new_abs, "new_dir", new_dir, holding=False)

            if not is_directory(old_abs):
                raise DocumentNotFoundError.folder(old_dir)

            # Reject nesting in either direction (would corrupt the prefix map).
            if old_abs == new_abs:
                raise InvalidRequestError("old_dir and new_dir are the same folder")
            if new_abs.is_relative_to(old_abs) or old_abs.is_relative_to(new_abs):
                raise InvalidRequestError(
                    "move_folder: old_dir and new_dir must not be nested"
                )

            # 1+2. Enumerate the subtree, build the old->new path map, and
            #      gate on destination collisions before moving anything.
            moves, md_map, non_note_moves = self._plan_folder_move(
                old_abs, old_dir, new_dir
            )

            # 3. Capture backlinks for every moved note BEFORE the move, while
            #    the index still reflects old paths. Annotate each row with its
            #    target's old/new path so a multi-target rewrite is possible.
            annotated: list[tuple[str, dict[str, Any]]] = []  # (target_old, row)
            for target_old in md_map:
                for row in self._fts.get_backlinks(target_old):
                    annotated.append((target_old, row))
            for source_old in md_map:
                for target, row in self._fallback_outgoing(source_old):
                    if target not in md_map:
                        annotated.append((target, row))

            # 4. Move every file. From here an OS error can leave the subtree
            #    part-moved, which callers must tell apart from an error
            #    raised before anything moved.
            try:
                for src_abs, dst_abs in moves:
                    dst_abs.parent.mkdir(parents=True, exist_ok=True)
                    shutil.move(str(src_abs), str(dst_abs))
            except OSError as exc:
                raise FolderMoveInterruptedError(old_dir, new_dir) from exc

            # 5. Single-pass link rewrite. Group annotated rows by source,
            #    remapping a source that moved to its new path so it is read at
            #    its new on-disk location.
            by_source: dict[str, list[tuple[str, dict[str, Any]]]] = defaultdict(list)
            for target_old, row in annotated:
                src_old = row["source_path"]
                src_new = md_map.get(src_old, src_old)  # remap if inside subtree
                by_source[src_new].append((target_old, row))

            pending_callbacks, dirty_paths, failed_links = self._rewrite_link_sources(
                by_source, md_map, op_name="move_folder"
            )

            # 6. Index: purge old note paths, reparse new note paths, plus the
            #    rewritten sources. A single mark_paths_dirty batch makes the
            #    writer run resolve_vault_wikilinks() once.
            if self._mark_paths_dirty is not None:
                move_dirty: list[str] = []
                move_dirty.extend(md_map.keys())  # old paths -> purged
                move_dirty.extend(md_map.values())  # new paths -> reparsed
                move_dirty.extend(dirty_paths)  # rewritten sources
                self._mark_paths_dirty(move_dirty)

            scope = current_commit_scope()
            if scope is not None:
                # All queued callbacks share this scope; set it before firing any.
                scope.folder_move = (old_abs, new_abs)

            # 7. Callbacks: rename for every moved file, edit for every
            #    rewritten source (minus intra-subtree dupes).
            self._dispatch_move_callbacks(md_map, non_note_moves, pending_callbacks)

            # 8. Remove the source tree. rmtree takes whatever is still in it
            #    — a file a concurrent write dropped there after step 4 is
            #    deleted, not preserved. Only a failure to remove is reported,
            #    and only as a warning: the move itself already succeeded.
            try:
                shutil.rmtree(old_abs)
            except OSError as exc:
                logger.warning(
                    "move_folder_remove_source_tree_failed path=%s err=%s",
                    old_dir,
                    exc,
                )

        return MoveFolderResult(
            old_dir=old_dir,
            new_dir=new_dir,
            files_moved=len(moves),
            updated_links=len(pending_callbacks),
            failed_links=failed_links,
        )
