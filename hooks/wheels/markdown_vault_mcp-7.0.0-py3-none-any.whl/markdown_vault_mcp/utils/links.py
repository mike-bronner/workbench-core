"""Link target helpers: decoding, encoding, replacement, substitution.

:func:`decode_link_target` is shared with link extraction and
:func:`encode_uri_path` with every site that *writes* a markdown
destination; the rest compute replacement link targets and apply
substitutions in file content when a note is renamed within the vault.
"""

from __future__ import annotations

import os.path as osp
import re
from html.entities import html5 as _HTML5_ENTITIES
from pathlib import Path
from typing import TYPE_CHECKING, NamedTuple, TypeVar
from urllib.parse import quote, unquote

if TYPE_CHECKING:
    from collections.abc import Callable, Iterable, Iterator, Mapping

# Fenced code block: a ``` or ~~~ run opening a line (after indentation or
# quote markers), with an optional info string, closed by the same run
# opening a later line. Anchoring both fences to a line start is what keeps
# three backticks in running prose from swallowing the blank line after
# them, which would let a stray ``[`` pair across it (#1334); a same-line
# multi-backtick span is a code span, matched by _RE_INLINE_CODE.
_RE_FENCED_CODE = re.compile(
    r"^[ \t>]*(```|~~~)[^\n]*\n.*?^[ \t>]*\1", re.DOTALL | re.MULTILINE
)
# Inline code: a backtick run and its closing run on one line.
# Retry only at run starts: an unsuccessful run has the same following
# text from every interior backtick, so retrying there is quadratic (#1749).
# Keep the literal first so the engine can skip ordinary prose quickly.
_RE_INLINE_CODE = re.compile(r"`(?<!``)`*[^`\n]+`+")
#: Characters left unescaped when re-encoding a destination that the author
#: already wrote percent-encoded. Only ``/`` — it is the path separator, and
#: encoding it would change the link's structure rather than its spelling.
_QUOTE_SAFE = "/"

#: Escapes that are refused rather than decoded, because decoding would name
#: something no file can be: an encoded path separator (``%2F`` is path
#: *data*, so ``dir%2Fnote.md`` must not become a link to the unrelated note
#: at ``dir/note.md``) and an encoded NUL (no file system allows one in a
#: name). Either case, ``decode_link_target`` leaves the whole destination
#: as written.
_RE_REFUSED_ESCAPE = re.compile(r"%(?:2[Ff]|00)")


def decode_link_target(target: str) -> str:
    """Percent-decode a link destination, or leave it as written.

    CommonMark defines a markdown destination as a URL, so its escapes name
    the same file the literal spelling does (#1332): ``b%5B1%5D.md`` is
    ``b[1].md``. Three escapes are refused, and a refusal leaves the *whole*
    destination exactly as written. A matching literal source-relative file
    can still resolve; vault-wide fallback does not use refused destinations:

    * an encoded separator (``%2F``) — path data, not structure;
    * an encoded NUL (``%00``) — no file system allows it in a name;
    * an escape sequence that is not valid UTF-8 (``bad%FF.md``) —
      ``unquote`` would substitute U+FFFD, inventing a name and collapsing
      distinct malformed spellings onto one target.

    A ``%`` not followed by two hex digits is not an escape and passes
    through untouched, as does ``+``, which is a space only in form
    encoding.

    Args:
        target: The destination's path portion, fragment already split off.

    Returns:
        The decoded path, or *target* unchanged when it carries a refused
        escape.
    """
    decoded = _decode_link_target_strict(target)
    return target if decoded is None else decoded


def _decode_link_target_strict(target: str) -> str | None:
    """Decode a percent spelling, returning None when the escape is refused."""
    if _RE_REFUSED_ESCAPE.search(target):
        return None
    try:
        return unquote(target, errors="strict")
    except UnicodeDecodeError:
        return None


#: What a *plain* (unbracketed) markdown destination cannot hold: the space
#: and the ASCII control characters (CommonMark §6.3, "Link destination").
#: A literal space does not merely look wrong — it ends the destination and
#: starts the title slot, so the link stops being a link (#1494).
_RE_PLAIN_DESTINATION_ILLEGAL = re.compile(r"[\x00-\x20\x7f]")


def encode_plain_destination(path: str) -> str:
    """Percent-encode what a plain markdown destination cannot hold.

    The minimal repair, for text the server re-emits but did not choose:
    the fragment an author wrote, which a rename re-attaches as found. A
    space anywhere in a plain destination ends it (#1494), so that much is
    encoded even there. A name the server writes goes through
    :func:`encode_uri_path` instead, which encodes everything RFC 3986
    requires (#2417).

    Only the characters §6.3 forbids are touched; everything else is left
    as the author wrote it.

    A NUL is encoded like any other control character, to ``%00``, which
    :func:`decode_link_target` then refuses — the link shows up broken
    instead of resolving onto a name no file system allows. No path from a
    real vault reaches that case.

    Args:
        path: A destination's path portion (and fragment, if any) as the
            name spells it, not percent-encoded.

    Returns:
        *path* with spaces and ASCII control characters percent-encoded.
    """
    return _RE_PLAIN_DESTINATION_ILLEGAL.sub(
        lambda match: f"%{ord(match.group()):02X}", path
    )


#: A backslash before an ASCII punctuation character is an escape (CommonMark
#: §2.4); before anything else it is a literal backslash (Ex. 13).
_RE_BACKSLASH_ESCAPE = re.compile(r"\\([!-/:-@\[-`{-~])")


#: An entity or numeric character reference (CommonMark §2.5): a valid HTML5
#: entity name, or a decimal (1-7 digits) or hexadecimal (1-6 digits)
#: reference, always closed by ``;``. Anything else stays literal, which is
#: stricter than ``html.unescape`` — that follows HTML5's legacy list and
#: reads ``&not`` without a semicolon as ``¬``.
_RE_CHARACTER_REFERENCE = re.compile(
    r"&(?:#[xX](?P<hex>[0-9A-Fa-f]{1,6})|#(?P<dec>[0-9]{1,7})|(?P<name>[A-Za-z][A-Za-z0-9]{1,31}));"
)
#: Escapes and references in one pass, the escape leftmost, so ``\\&#46;``
#: yields a literal ``&`` followed by ``#46;`` rather than an escaped ``&``
#: that is then re-read as the start of a reference (CommonMark resolves
#: §2.4 and §2.5 together).
_RE_ESCAPE_OR_REFERENCE = re.compile(
    rf"(?P<esc>{_RE_BACKSLASH_ESCAPE.pattern})|{_RE_CHARACTER_REFERENCE.pattern}"
)


def _decode_reference(match: re.Match[str]) -> str:
    if match.group("esc") is not None:
        return match.group("esc")[1]
    if (name := match.group("name")) is not None:
        return _HTML5_ENTITIES.get(name + ";", match.group(0))
    codepoint = int(
        match.group("hex") or match.group("dec"), 16 if match.group("hex") else 10
    )
    # U+0000, a surrogate, and anything outside Unicode become U+FFFD
    # (§2.5, "invalid Unicode code points"); a lone surrogate would not
    # even survive the trip into SQLite (UTF-8 refuses it).
    if codepoint == 0 or 0xD800 <= codepoint <= 0xDFFF or codepoint > 0x10FFFF:
        return "\ufffd"
    return chr(codepoint)


def _decode_escapes_and_entities(text: str) -> str:
    return _RE_ESCAPE_OR_REFERENCE.sub(_decode_reference, text)


#: A numeric character reference's body after its ``&#`` (§2.5).
_RE_NUMERIC_REFERENCE_TAIL = re.compile(r"#(?:[xX][0-9A-Fa-f]{1,6}|[0-9]{1,7});")


def _is_escaped(written: str, pos: int) -> bool:
    """Whether an odd run of backslashes precedes *pos* (§2.4)."""
    backslashes = 0
    while pos - backslashes - 1 >= 0 and written[pos - backslashes - 1] == "\\":
        backslashes += 1
    return backslashes % 2 == 1


def _is_fragment_marker(written: str, pos: int) -> bool:
    """Whether the ``#`` at *pos* begins the fragment rather than the name.

    Not when it is escaped (``\\#``; ``\\\\#`` is an escaped backslash then a
    marker, §2.4), and not when it is the ``#`` of a well-formed numeric
    character reference whose ``&`` is not itself escaped (``&#46;``, §2.5).
    """
    if _is_escaped(written, pos):
        return False
    return not (
        pos > 0
        and written[pos - 1] == "&"
        and not _is_escaped(written, pos - 1)
        and _RE_NUMERIC_REFERENCE_TAIL.match(written, pos) is not None
    )


def split_markdown_fragment(written: str) -> tuple[str, str | None]:
    """Split a markdown destination, brackets already off, at its fragment.

    Runs on the text *as written*, before any decoding, so an encoded or
    escaped ``#`` stays in the name (#1332, #1353). Extraction and the
    rename path both use it, so the two cannot disagree on where a
    destination ends.

    Args:
        written: The destination without its ``<…>`` brackets, title
            excluded.

    Returns:
        ``(path_part, fragment)``; *fragment* is ``None`` when absent or
        empty.
    """
    pos = written.find("#")
    while pos != -1 and not _is_fragment_marker(written, pos):
        pos = written.find("#", pos + 1)
    if pos == -1:
        return written, None
    return written[:pos], written[pos + 1 :] or None


def is_anchor_destination(raw: str) -> bool:
    """Whether a destination, as written, names only a fragment of its note.

    ``#h`` and ``<#h>`` are same-document anchors; ``%23x.md``, ``\\#x.md``
    and ``&#35;x.md`` are files whose name begins with a literal ``#`` and
    must be judged on the written spelling, before any decoding turns that
    ``#`` into a leading character (#1353).

    Args:
        raw: The destination exactly as written, title excluded.

    Returns:
        ``True`` when the written path part is empty.
    """
    written = raw[1:-1] if is_pointy_destination(raw) else raw
    path_part, _fragment = split_markdown_fragment(written)
    return not path_part


def is_pointy_destination(raw: str) -> bool:
    """Return whether *raw* is written in CommonMark's ``<…>`` destination form.

    Args:
        raw: A destination exactly as written, title excluded.

    Returns:
        ``True`` for ``<my note.md>``; ``False`` for a plain destination.
    """
    return len(raw) >= 2 and raw[0] == "<" and raw[-1] == ">"


def decode_markdown_destination(raw: str) -> str:
    """Decode a markdown destination, as written, into the name it spells.

    CommonMark's inline-link destination has five spellings beyond the
    literal one (#1353; ``docs/design/reference/commonmark-gfm.md``, "Inline
    links"), decoded in the order ``docs/design/design.md`` fixes: the
    ``<…>`` form loses its brackets, backslash escapes and entity references
    are decoded (``\\(`` → ``(``, ``&amp;`` → ``&``, ``&#46;`` → ``.``; an
    invalid entity stays literal), and only then the URL layer's
    percent-escapes through :func:`decode_link_target`, with its refusals.
    Extraction and the rename path both call this, so they cannot disagree
    on what a spelling names.

    Args:
        raw: The destination exactly as written, title excluded, fragment
            included.

    Returns:
        The decoded destination, fragment still attached.
    """
    return _decode_destination(raw)[0]


def _decode_destination(raw: str) -> tuple[str, bool]:
    """Decode a destination and retain whether its percent layer was refused."""
    inner = raw[1:-1] if is_pointy_destination(raw) else raw
    spelling = _decode_escapes_and_entities(inner)
    decoded = _decode_link_target_strict(spelling)
    return (spelling, True) if decoded is None else (decoded, False)


class MarkdownDestination(NamedTuple):
    """A decoded path, its written fragment, and percent-decoding status."""

    path: str
    fragment: str | None
    refused: bool


def parse_markdown_destination(raw: str) -> MarkdownDestination:
    """Decode a destination's path after separating its written fragment.

    Args:
        raw: The destination as written, including optional pointy brackets.

    Returns:
        The decoded path, original fragment, and whether decoding was refused.
    """
    written = raw[1:-1] if is_pointy_destination(raw) else raw
    path, fragment = split_markdown_fragment(written)
    decoded, refused = _decode_destination(path)
    return MarkdownDestination(decoded, fragment, refused)


#: How deep the destination parser balances parentheses before giving up —
#: three, the depth §6.3's own examples reach, a departure recorded in
#: ``docs/design/design.md``. :func:`_parentheses_parse_plainly` mirrors it
#: on the write side, so the two cannot disagree about which names the plain
#: form can hold; ``tests/test_links_generated_destinations.py`` pins the
#: agreement.
_MAX_PLAIN_PAREN_DEPTH = 3


def _parentheses_parse_plainly(name: str) -> bool:
    """Whether *name*'s parentheses survive a plain destination unescaped.

    CommonMark §6.3 admits parentheses in the plain form only escaped or in
    balanced pairs, and this project's parser balances them to
    :data:`_MAX_PLAIN_PAREN_DEPTH`.

    A parenthesis that is already backslash-escaped is exempt from the
    balance requirement — §6.3 admits it "escaped **or** balanced" — so it
    is skipped rather than counted, the way :func:`_is_fragment_marker`
    skips an escaped ``#``. Counting it would judge an author's legal
    ``a\\(b`` unbalanced and send it to be escaped again.

    Args:
        name: A destination as it is written, escapes included.

    Returns:
        ``True`` when the unescaped parentheses are balanced and no deeper
        than the parser goes, so escaping them would be noise.
    """
    depth = 0
    for pos, char in enumerate(name):
        if char not in "()" or _is_escaped(name, pos):
            continue
        if char == "(":
            depth += 1
            if depth > _MAX_PLAIN_PAREN_DEPTH:
                return False
        else:
            depth -= 1
            if depth < 0:
                return False
    return depth == 0


#: What a written path segment may hold literally beyond the unreserved
#: characters ``quote`` never encodes: RFC 3986 §3.3's ``pchar`` is
#: ``unreserved / pct-encoded / sub-delims / ":" / "@"``, and ``/`` is the
#: separator between segments. One sub-delim is taken out: ``&``, which a
#: markdown reader decodes as a character reference before the URL layer
#: sees it (``&amp;`` is ``&``), so it is written ``%26``.
_PATH_SAFE = "/!$'()*+,;=:@"
#: RFC 3986 §3.5: ``fragment = *( pchar / "/" / "?" )``.
_FRAGMENT_SAFE = _PATH_SAFE + "?"


def encode_uri_path(path: str) -> str:
    """Percent-encode a vault path into an RFC 3986 path reference.

    OKF 0.3 §6 makes every link target a URI reference (RFC 3986), so a
    destination the server writes encodes everything a path segment cannot
    hold literally: a space and the controls, ``%`` itself (always ``%25``,
    RFC 3986 §2.4), the delimiters ``#``, ``?``, ``[`` and ``]``, the
    characters outside the URI set (``"``, ``<``, ``>``, ``\\``, ``^``,
    backtick, ``{``, ``|``, ``}``), and every non-ASCII character as its
    UTF-8 octets (§2.5; a URI holds ASCII only). Sub-delims, ``:`` and
    ``@`` stay literal, as ``pchar`` allows, except ``&`` (see
    :data:`_PATH_SAFE`). A relative path whose first segment holds a ``:``
    is written behind a ``./`` dot-segment, as RFC 3986 §4.2 prescribes,
    since otherwise it would read as a scheme (``draft:v2.md``).

    :func:`decode_link_target` reads back exactly *path*, and so does
    Obsidian, which percent-decodes a markdown destination before resolving
    it (``docs/design/reference/obsidian-markdown.md``).

    Args:
        path: A vault path, as the file system spells it.

    Returns:
        The path as a URI reference, ``/`` kept as structure.
    """
    return _guard_scheme_lookalike(
        path, quote(path, safe=_PATH_SAFE, errors="surrogateescape")
    )


def _guard_scheme_lookalike(path: str, encoded: str) -> str:
    """Prefix ``./`` when *path*'s first relative segment holds a ``:``.

    RFC 3986 §4.2: such a segment "cannot be used as the first segment of a
    relative-path reference, as it would be mistaken for a scheme name", and
    "must be preceded by a dot-segment". Encoding the colon instead is no
    help here: the scanner tests for a scheme after percent-decoding.
    """
    if path.startswith("/") or ":" not in path.split("/", 1)[0]:
        return encoded
    return "./" + encoded


def _encode_uri_fragment(fragment: str) -> str:
    """Percent-encode a generated fragment as RFC 3986 §3.5 requires."""
    return quote(fragment, safe=_FRAGMENT_SAFE, errors="surrogateescape")


def escape_unparsable_parentheses(written: str) -> str:
    """Percent-escape a plain destination's parentheses when they would not parse.

    The repair that cannot be made per-part: CommonMark §6.3 reads a
    destination's parentheses as one balanced run, so ``a(b.md#c)d``
    parses — the fragment closes what the path opened — while encoding the
    path's ``(`` alone would unbalance it and break a link that worked. The
    test therefore runs on the assembled destination, and when it fails
    every parenthesis is written ``%28`` or ``%29``, the author's fragment
    included: at that point the alternative is not a tidier link but no
    link (#1516). Percent-escapes, not backslashes, because a backslash is
    not a URI character and OKF 0.3 §6 makes the target a URI reference
    (#2417).

    Left alone when they parse, so a balanced ``a(b).md`` stays literal:
    parentheses are sub-delims, which RFC 3986 §3.3 admits in a segment.

    Only *unescaped* parentheses are encoded. An author's existing ``\\(``
    is already legal (§6.3 admits a parenthesis "escaped or balanced") and
    is left as found.

    Args:
        written: The assembled destination — path, marker and fragment —
            as it is written, escapes included.

    Returns:
        *written*, with every unescaped parenthesis percent-encoded if any
        of them would not parse.
    """
    if _parentheses_parse_plainly(written):
        return written
    out: list[str] = []
    for pos, char in enumerate(written):
        if char in "()" and not _is_escaped(written, pos):
            out.append("%28" if char == "(" else "%29")
        else:
            out.append(char)
    return "".join(out)


def build_plain_destination(path: str, fragment: str | None = None) -> str:
    """Render a vault path as an RFC 3986 reference a markdown reader parses.

    The write-side entry point for every site that *generates* a link
    rather than rewriting one (the OKF index builder, the wikilink
    converter and so the bundle export). The path goes through
    :func:`encode_uri_path`, the same encoder the rename path uses, so a
    generated destination and a rewritten one cannot disagree about what a
    name needs; OKF 0.3 §6 requires the result to be a URI reference
    (#2417), which also keeps it a link that means what it says (#1494,
    #1513): a space cannot end it and a ``#`` in a name, written ``%23``,
    cannot become a fragment marker.

    The fragment is encoded as RFC 3986 §3.5 allows and attached after the
    path is encoded, so the marker between them stays the only ``#``, and
    before the parenthesis test, which §6.3 runs on the whole destination.

    Args:
        path: The destination's path portion, as the vault spells it.
        fragment: The heading fragment, without its ``#``, if any.

    Returns:
        The destination, ready to interpolate between ``(`` and ``)``.
    """
    written = encode_uri_path(path)
    if fragment:
        written += "#" + _encode_uri_fragment(fragment)
    return escape_unparsable_parentheses(written)


def escape_link_text(text: str) -> str:
    """Backslash-escape the brackets that would end a link's text early.

    A generated link's text is a title or an alias, not markdown the author
    wrote, so a ``]`` in it ends the text and the line stops being a link;
    an unmatched ``[`` re-opens it and a spec reader shows different text
    than intended (#1513). Backslashes go first, or an escape this function
    adds could be neutralised by one already in *text*.

    Escaping makes the line valid CommonMark, which is what Obsidian and the
    docs site read. This project's own scanner still does not index a link
    whose text carries an escaped ``]`` — its link-text pattern is not
    escape-aware — so such an entry renders correctly but contributes no
    edge to the link graph until #1517 is fixed.

    Args:
        text: The display text, as the title or alias spells it.

    Returns:
        *text* with ``\\``, ``[`` and ``]`` backslash-escaped.
    """
    return text.replace("\\", "\\\\").replace("[", "\\[").replace("]", "\\]")


def compute_new_raw_target(
    link_type: str,
    raw_target: str,
    fragment: str | None,
    new_path: str,
    source_path: str = "",
    old_path: str = "",
) -> str:
    """Compute the replacement raw_target string when a file is renamed.

    Args:
        link_type: One of ``"markdown"``, ``"reference"``, ``"wikilink"``.
        raw_target: The literal link string stored in the source file.
        fragment: The heading fragment (``#heading``) of the link, if any.
        new_path: The vault-relative path of the renamed file (e.g.
            ``"notes/new-name.md"``).
        source_path: Vault-relative path of the file that contains the link.
            Required for correct relative-path handling in markdown and
            reference links (cross-directory links would otherwise be silently
            broken).
        old_path: Vault-relative path of the file being renamed.  Used to
            detect whether *raw_target* was written as a vault-root-relative
            or source-directory-relative path.

    Returns:
        The replacement raw_target string to write into the source file,
        preserving the original spelling where possible: a destination the
        author percent-encoded is re-encoded with ``quote`` (#1105, #1332);
        otherwise the new name goes through :func:`encode_uri_path`, which
        leaves what RFC 3986 admits in a path literal and encodes the rest,
        so the rewrite is a URI reference as OKF 0.3 §6 requires (#1494,
        #2417). The ``<…>`` form keeps its brackets.
        A vault-path spelling from a nested source becomes source-relative so
        a source-local path cannot shadow the rewritten target.
    """
    if link_type == "wikilink":
        # Determine whether the original wikilink included the .md extension.
        old_path_part = raw_target.split("#")[0]
        if old_path_part.lower().endswith(".md"):
            new_path_part = new_path
        else:
            new_path_part = new_path[:-3]
        return new_path_part + ("#" + fragment if fragment else "")
    else:
        # markdown and reference links, in one of three shapes:
        #   "/folder/target.md"  leading-slash root-relative (#969, and what
        #                        OKF recommends and its tooling emits)
        #   "folder/target.md"   root-relative, matching old_path
        #   "../target.md"       relative to the source file's directory
        # Leading-slash links stay rooted. A bare vault path from a nested
        # source becomes source-relative to avoid a local shadow.
        # A ``<…>`` destination keeps its brackets in raw_target (they are
        # what the file holds); take them off for the shape test and put
        # them back on the answer, so a rename keeps the form that let the
        # author write a space (#1353).
        pointy = is_pointy_destination(raw_target)
        written = raw_target[1:-1] if pointy else raw_target
        raw_path_part, _ = split_markdown_fragment(written)
        # The shape test below compares the destination to old_path, and
        # old_path is never encoded. Comparing the encoded spelling therefore
        # never matched, so a root-relative encoded link fell into the
        # relative-to-source branch and came back rewritten as a relative
        # one — the same fidelity defect as #1105, reached by a different
        # route (#1332). Decode for the comparison — escapes and entities
        # too (#1353); re-encode the answer only if the author was
        # percent-encoding.
        decoded_path_part = decode_markdown_destination(raw_path_part)
        was_encoded = decode_link_target(raw_path_part) != raw_path_part

        if raw_path_part.startswith("/"):
            new_path_part = "/" + new_path
        elif (
            source_path
            and old_path
            and (decoded_path_part != old_path or "/" in source_path)
        ):
            # Relative-to-source link: compute the correct new relative path so
            # cross-directory links continue to resolve after the rename.
            source_dir = str(Path(source_path).parent)
            new_rel = osp.relpath(new_path, source_dir)
            # os.path.relpath uses OS separators on Windows; normalise to /.
            new_path_part = new_rel.replace("\\", "/")
        else:
            new_path_part = new_path
        if was_encoded:
            new_path_part = _guard_scheme_lookalike(
                new_path_part, quote(new_path_part, safe=_QUOTE_SAFE)
            )
        else:
            new_path_part = encode_uri_path(new_path_part)
        # The fragment is the author's spelling, not a name this rewrite
        # introduces, so it is re-attached as found and never reformatted.
        # The two plain-form repairs below still reach it, because both are
        # properties of the destination as a whole rather than of the part
        # that changed: a space anywhere in it ends the link, and the
        # parentheses balance as one run. Repairing a fragment we are
        # already rewriting the line around beats re-emitting something
        # that is not a link.
        new_raw = new_path_part + ("#" + fragment if fragment else "")
        if pointy:
            # ``<…>`` holds a space and a parenthesis, so neither plain-form
            # repair applies; the new name inside is still a URI reference.
            return f"<{new_raw}>"
        if not was_encoded:
            # Both plain-form repairs, on the assembled destination: the
            # parenthesis test is a property of the whole run (#1516), and a
            # space anywhere in it ends the link (#1494). An encoded
            # original was re-encoded by ``quote`` above, which covers both.
            new_raw = encode_plain_destination(escape_unparsable_parentheses(new_raw))
        return new_raw


#: A bracket span (link text, reference label) is read by an escape-aware
#: scan rather than a negated character class, so a ``\\]`` does not close
#: it (CommonMark §6.3; #1517 for the inline text, #1519 for the two
#: reference forms) — :func:`find_bracket_span` below.
#:
#: It lives in this module, not in ``scanner.py``, because the rewrite
#: side needs the same answer: when the two disagreed about where a
#: link's text ends, a rename found a link the index held and silently
#: failed to rewrite it (#1521).
#:
#: The scan steps between the only characters that can matter rather than
#: over every one of them, so the engine keeps doing the scanning and a
#: note with no brackets costs one failed search rather than a Python loop
#: the length of the note.
#:
#: These three and no others: :func:`find_bracket_span` handles the
#: backslash and then treats what is left as the two brackets, so a
#: character added here needs a branch added there.
_RE_LINK_TEXT_MARK = re.compile(r"[\[\]\\]")


#: An optional link title after the destination, moved here from
#: ``scanner.py`` with the destination grammar it belongs to (#1526):
#: reading a link and rewriting one are the same grammar, and keeping
#: them apart is what let the two drift in #1521.
#: honoured, whitespace-separated, at the end of the parenthesised text.
#: Spaces and tabs separate it (§6.3; a NBSP is an ordinary destination
#: character, Ex. 507); a line ending never reaches here (#1334).
#: A failed separator run must not be retried at each interior space/tab:
#: every retry meets the same next token and cannot change the result (#1749).
#: Consume the first separator before the guard to retain the engine's skip.
trailing_title_pattern = re.compile(
    r"""[ \t](?<![ \t]{2})[ \t]*(?:"(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*'|\((?:[^()\\]|\\.)*\))[ \t]*$"""
)


_PLAIN_CHAR = r"[^()\\\x00-\x08\x0a-\x1f\x7f]|\\."
_RE_PLAIN_DESTINATION = re.compile(
    rf"(?:{_PLAIN_CHAR}"
    rf"|\((?:{_PLAIN_CHAR}|\((?:{_PLAIN_CHAR}|\((?:{_PLAIN_CHAR})*\))*\))*\)"
    rf")*\)"
)


def _scan_plain_destination(region: str, pos: int) -> int | None:
    """Find the ``)`` that closes a plain destination (and title) at *pos*.

    See :data:`_RE_PLAIN_DESTINATION` for the grammar.

    Returns:
        The index of the closing ``)``, or ``None``.
    """
    m = _RE_PLAIN_DESTINATION.match(region, pos)
    return None if m is None else m.end() - 1


def _scan_pointy_destination(region: str, pos: int) -> int | None:
    """Find the end of a ``<…>`` destination opening at *pos*.

    No line ending and no unescaped ``<`` or ``>`` inside (§6.3, Ex. 491,
    493); a ``)`` or a space is fine (Ex. 489, 492).

    Returns:
        The index just past the closing ``>``, or ``None``.
    """
    i = pos + 1
    while i < len(region):
        char = region[i]
        if char == "\n" or char == "<":
            return None
        if char == "\\" and i + 1 < len(region) and region[i + 1] != "\n":
            i += 2
            continue
        if char == ">":
            return i + 1
        i += 1
    return None


def _parse_destination(region: str, pos: int) -> tuple[str, int, int] | None:
    """Read an inline link's destination starting just after its ``(``.

    Implements §6.3's two destination forms and the optional title (#1353).
    The returned destination is the text **as written**, title excluded —
    ``<my note.md>`` keeps its brackets, ``a\\(b\\).md`` its escapes — since
    that is what the rename path searches the file for; decoding is
    :func:`~markdown_vault_mcp.utils.links.decode_markdown_destination`'s job.

    Args:
        region: The paragraph region being scanned.
        pos: Index of the first character after ``(``.

    Returns:
        ``(raw_destination, start, end)`` with *start* the index of the
        destination's first character and *end* the index just past the
        closing ``)``, or ``None`` when no link is written here. The offset
        is returned rather than re-derived by the caller: a rewrite that
        searches the region for *raw_destination* finds the wrong
        occurrence whenever the title repeats it (#1526 review).
    """
    i = pos
    while i < len(region) and region[i] in " \t":
        i += 1
    if i < len(region) and region[i] == "<":
        return _parse_pointy_destination(region, i)
    close = _scan_plain_destination(region, i)
    if close is None:
        return None
    # Only spaces and tabs are trimmed: a NBSP is a destination character.
    # Only trailing text is removed above, so the destination still
    # begins at ``i`` and ``region[i : i + len(raw)] == raw``.
    raw = trailing_title_pattern.sub("", region[i:close]).strip(" \t")
    return (raw, i, close + 1) if raw else None


def _pointy_destination_span(region: str, pos: int) -> tuple[str, int] | None:
    """``(raw, close)`` for a ``<…>`` destination at *pos*, or ``None``.

    The grammar shared by the two questions asked about a pointy
    destination: *is one written here* (this), and *is there one worth
    storing* (:func:`_parse_pointy_destination`, which additionally
    rejects the empty ``<>``). Separated because an over-loose copy of
    this test, checking only that the parens balanced, let
    ``[a](<x.md> not a title)`` claim its span as an inline link although
    the parser then rejected it — so neither family stored the row a
    reader finds. One grammar, two callers, no room to drift.

    *close* is the index of the closing ``)``.
    """
    end = _scan_pointy_destination(region, pos)
    if end is None:
        return None
    close = _scan_plain_destination(region, end)
    if close is None:
        return None
    rest = region[end:close]
    if rest.strip(" \t") and not trailing_title_pattern.fullmatch(rest):
        return None
    return region[pos:end], close


def _parse_pointy_destination(region: str, pos: int) -> tuple[str, int, int] | None:
    """The ``<…>`` half of :func:`_parse_destination`; *pos* is at the ``<``."""
    span = _pointy_destination_span(region, pos)
    if span is None:
        return None
    raw, close = span
    # ``<>`` closes an inline link but names nothing, so there is a span
    # here and no destination to store. That is exactly the distinction
    # :func:`inline_link_follows` keeps and this function does not.
    return None if raw == "<>" else (raw, pos, close + 1)


def find_bracket_span(region: str, pos: int) -> tuple[int, int, str] | None:
    """Find the next ``[…]`` at or after *pos*, honouring escapes.

    The primitive under every bracket span the scanner reads: an inline
    link's text, and a reference usage's two labels and a definition's one.
    Each used to be matched by a negated character class (``[^\\]]*``), which
    cannot see a backslash, so a ``\\]`` closed the span and the link it
    belonged to produced no row at all — for inline text (#1517) and for the
    reference family (#1519) alike.

    The scan, not a wider regex, is what makes that affordable. An
    escape-aware class has to read past every escaped ``]``, so the engine's
    retry from each ``[`` turns quadratic: on one 40 KB paragraph of
    ``[a\\]b`` the class costs seconds where this costs a single pass. The
    walk also improves the *existing* pathological case, a run of ``[`` that
    never closes (#1343).

    Matching follows the classes it replaces, so backslash-free input
    behaves exactly as before: the **first** ``[`` since the last unescaped
    ``]`` opens the span, and the span ends at the first unescaped ``]``. A
    caller that rejects the span it is handed resumes at ``close + 1``,
    which is where the engine's start-position retry would have landed.

    Args:
        region: The text to scan — one paragraph region for a usage, the
            whole body for a definition (#1334).
        pos: Index to resume from.

    Returns:
        ``(open_index, close_index, inner)`` with ``region[close_index]``
        the unescaped ``]`` that closed the span; ``None`` when no further
        span exists.
    """
    first_open: int | None = None
    index = pos
    while (mark := _RE_LINK_TEXT_MARK.search(region, index)) is not None:
        at = mark.start()
        char = region[at]
        if char == "\\":
            # An escaped character is literal, so neither a bracket that
            # opens the span nor one that closes it.
            index = at + 2
            continue
        if char == "[":
            if first_open is None:
                first_open = at
        else:
            # A ``]``: the mark class yields nothing else once the
            # backslash above is handled, so this needs no test of its own
            # — and stays an ``else`` rather than a third branch that could
            # never be taken.
            if first_open is not None:
                return first_open, at, region[first_open + 1 : at]
            # A ``]`` before any ``[`` closes nothing and is skipped, which
            # is where the engine's start-position retry used to land.
        index = at + 1
    return None


#: What :func:`iter_bracket_links` hands back for a link its caller accepted.
_Payload = TypeVar("_Payload")


def iter_bracket_links(
    region: str,
    follow: Callable[[str, int, int], tuple[_Payload, int] | None],
) -> Iterator[tuple[int, int, _Payload, int]]:
    r"""Walk *region*'s brackets under CommonMark's delimiter-stack rule.

    The one place the rule lives, for both link families. It replaces a scan
    that took the **first** ``[`` since the last unescaped ``]`` as the
    opener, where CommonMark takes the **nearest unmatched** one (§6.3): a
    ``]`` closes the innermost ``[`` still open, and an opener that closes
    nothing is discarded rather than swallowing what follows.

    What differs between the families is only what has to *follow* a closed
    span for a link to exist — a destination in ``(…)`` for the inline form
    (#1526), a second adjacent span for the reference form (#1528) — so
    that is the argument, and the walk itself is shared rather than written
    twice. Sharing it is the point: the two families drifted apart once
    already (#1521), and a rule that lives in one function cannot.

    Two rules travel with it. An opener preceded by an unescaped ``!`` is an
    image, so its own span yields nothing — but a link *inside* an image's
    description still does, since it closes first (§6.4, Ex. 575). And once
    a link is found, every *link* opener still on the stack is deactivated,
    while an image opener stays live (Ex. 575), because
    links may not contain links (Ex. 518).

    The walk steps between ``[``, ``]`` and ``\`` rather than over every
    character, and pushes and pops each opener at most once, so it stays
    linear: a run of ``[`` costs one push apiece and no rescan.

    Args:
        region: One paragraph region, code already stripped (#1334).
        follow: Given *region*, the index of the ``[`` that opened a span
            and the index of the ``]`` that closed it, returns
            ``(payload, end)`` when a link is written there and ``None``
            when one is not. *end* is the index just past the whole link.
            The opener is passed because a reference form may resolve on
            the span's own text (#1531), which only its bounds identify.

    Yields:
        ``(open_index, close_index, payload, end)`` per link, in the order
        the links close. An image is consumed but never yielded.
    """
    # Each entry is ``(index, is_image, rank)``. *rank* is how many link
    # openers sat below this one when it was pushed, and ``-1`` for an
    # image — which is what lets the deactivation below stay O(1) while
    # still being selective.
    stack: list[tuple[int, bool, int]] = []
    link_depth = 0
    retired_below = 0
    index = 0
    while (mark := _RE_LINK_TEXT_MARK.search(region, index)) is not None:
        at = mark.start()
        char = region[at]
        if char == "\\":
            # An escaped character is literal, so neither bracket nor image
            # marker.
            index = at + 2
            continue
        if char == "[":
            is_image = (
                at > 0 and region[at - 1] == "!" and not _is_escaped(region, at - 1)
            )
            stack.append((at, is_image, -1 if is_image else link_depth))
            link_depth += 0 if is_image else 1
            index = at + 1
            continue
        # A ``]``. With no opener it is literal; otherwise it consumes the
        # nearest one whether or not a link comes of it, which is what stops
        # a failed candidate from being retried and keeps the walk linear.
        if not stack:
            index = at + 1
            continue
        open_index, is_image, rank = stack.pop()
        # An image opener is never retired; a link opener is retired when
        # its rank falls below the watermark. Read *before* the watermark
        # is clamped below, or popping the outer opener of
        # ``[a [b](y) c](x)`` lowers the mark past its own rank and revives
        # the very opener the inner link retired.
        active = is_image or rank >= retired_below
        if not is_image:
            link_depth -= 1
            retired_below = min(retired_below, link_depth)
        matched = follow(region, open_index, at) if active else None
        if matched is None:
            index = at + 1
            continue
        payload, end = matched
        if not is_image:
            yield open_index, at, payload, end
            # "Links may not contain links" (Ex. 518) retires the openers
            # this one sits inside — but only the *link* openers. An image
            # may contain a link (Ex. 575) and stays live, so it can still
            # take the label or destination that follows, which is how
            # ``![an [a][r] alt][r]`` is one image and one link rather than
            # two links.
            #
            # Ranking the link openers separately is what keeps that
            # selective *and* constant-time. Walking the stack to clear a
            # flag each time reads more plainly and is quadratic on a run
            # of unclosed ``[``, which is the shape this file exists to
            # keep linear: it cost 8.5 s on 20000 ``[ar][`` before this
            # was a watermark again.
            retired_below = link_depth
        # An image is consumed rather than retried: its own span yields no
        # link, but the text it spans has already been walked, so anything
        # linking inside it was yielded on the way.
        index = end


def inline_link_follows(region: str, close_index: int) -> bool:
    """Whether a ``(…)`` inline destination closes just after *close_index*.

    The *reference* family's precedence test. CommonMark tries the inline
    destination before any reference rung (§6.3), so a span the inline
    family owns is not a reference at all — and while a reference needed a
    second bracket span, that was free, because a ``(`` can never be one.
    The shortcut rung resolves on the text alone, so it is no longer free.

    Deliberately **not** :func:`_follow_inline_destination`, though the two
    look like the same question. That one answers "is there a destination
    to store", and returns ``None`` for ``[a]()`` because there is nothing
    to index. This one answers "did the inline form claim this span", and
    ``[a]()`` is a link to the empty string for a reader, so the span is
    claimed and must not resolve as a shortcut. Equally it is not a test
    for a literal ``(``: ``[a](unclosed`` never closes, so the inline form
    did not claim it and the shortcut rung is right to have it.
    """
    if region[close_index + 1 : close_index + 2] != "(":
        return False
    index = close_index + 2
    while index < len(region) and region[index] in " \t":
        index += 1
    if index < len(region) and region[index] == "<":
        return _pointy_destination_span(region, index) is not None
    return _scan_plain_destination(region, index) is not None


def _follow_inline_destination(
    region: str, _open_index: int, close_index: int
) -> tuple[tuple[str, int], int] | None:
    """The inline family's shape test: a destination in ``(…)``.

    The opener is unused here: an inline link is decided entirely by what
    follows its ``]``, never by its own text.
    """
    if region[close_index + 1 : close_index + 2] != "(":
        return None
    parsed = _parse_destination(region, close_index + 2)
    if parsed is None:
        return None
    raw_target, target_start, end = parsed
    return (raw_target, target_start), end


class InlineLink(NamedTuple):
    """One inline link, as :func:`iter_inline_links` reads it.

    Named rather than a bare tuple because *target_start* is easy to
    confuse with *open_index*, and a rewrite that reaches for the wrong one
    corrupts a file silently.
    """

    #: Index of the ``[`` that opened the link.
    open_index: int
    #: The link text as written, escapes and all.
    link_text: str
    #: The destination as written, title excluded.
    raw_target: str
    #: Index of *raw_target*'s first character in the region.
    target_start: int
    #: Index just past the closing ``)``.
    end: int


def iter_inline_links(region: str) -> Iterator[InlineLink]:
    r"""Yield every inline ``[text](destination)`` link in *region*.

    The one place the inline-link grammar is decided, for the index and for
    the rewrite alike (#1521). It replaces a scan that took the **first**
    ``[`` since the last unescaped ``]`` as the opener, where CommonMark
    takes the **nearest unmatched** one (§6.3, "Process emphasis"): a ``]``
    closes the innermost ``[`` still open, and an opener that closes nothing
    is discarded rather than swallowing what follows.

    That one difference was three recorded departures (#1526). The old rule
    read ``[a[b](x)``'s text as ``a[b`` where it is ``b``; it stored no row
    at all for ``[a [b] c](x)``, a link whose text merely contains a
    balanced pair; and it read ``![a[b](x)`` as an image, because the
    ``!`` sits before the *outer* ``[`` while the link CommonMark finds
    opens at the inner one. All three follow from the nearest-unmatched
    rule; none of them needed its own repair.

    Two rules travel with it. An opener preceded by an unescaped ``!`` is an
    image, so its own span yields no link — but a link *inside* an image's
    description still does, since it closes first (§6.4, Ex. 575). And once
    a link is found, every *link* opener still on the stack is deactivated,
    while an image opener stays live (Ex. 575), because
    links may not contain links (Ex. 518): in ``[a [b](y) c](x)`` only ``b``
    links.

    The walk steps between ``[``, ``]`` and ``\`` rather than over every
    character, and pushes and pops each opener at most once, so it stays
    linear: a run of ``[`` costs one push apiece and no rescan.

    Args:
        region: One paragraph region, code already stripped (#1334).

    Yields:
        An :class:`InlineLink` per link, in the order the links close.
    """
    for open_index, close_index, (raw_target, target_start), end in iter_bracket_links(
        region, _follow_inline_destination
    ):
        yield InlineLink(
            open_index,
            region[open_index + 1 : close_index],
            raw_target,
            target_start,
            end,
        )


#: A reference definition's line start: optional whitespace, then the ``[``
#: that opens the label. What follows is read by :func:`find_bracket_span`
#: and :data:`_RE_REF_DEF_TAIL` rather than by one pattern, so an escaped
#: ``]`` inside the label does not close it (#1519). ``\s*`` rather than
#: ``[ \t]*`` because the class it replaces used ``\s*``: a line indented
#: with an exotic Unicode space is still a definition, as it was before.
_RE_REF_DEF_OPEN = re.compile(r"^\s*\[", re.MULTILINE)
#: What follows a definition's ``]:`` — the target, to the end of its line.
#: The destination may sit on the next line (§4.7), so the gap admits one
#: line ending; ``(.+)`` then requires a non-empty destination.
#:
#: **One** line ending, not any run of whitespace. A blank line ends the
#: attempt (§4.7: the destination may be "preceded by ... up to one line
#: ending"), and a gap of ``\s*`` crossed it — so ``[:]:`` followed by a
#: blank line and an unrelated ``[ar]: x.md`` defined the label ``:`` with
#: that whole line as its target. Nothing referenced such a definition
#: until the shortcut form arrived (#1531), which is why a wrong entry in
#: the table produced no wrong row and went unseen.
_RE_REF_DEF_TAIL = re.compile(r"[ \t]*\n?[ \t]*(.+)$", re.MULTILINE)
#: A CommonMark blank line holds only spaces or tabs, so a label may not
#: cross one even when the "empty" line is not literally empty.
_RE_BLANK_LINE = re.compile(r"\n[ \t]*\n")
# Markdown footnotes ([^label] / [^label]: body) differ from reference-style
# links by exactly this character, and both reference scans read them.
FOOTNOTE_LABEL_PREFIX = "^"


def _definition_destination_end(clean: str, pos: int) -> int | None:
    """Index just past a definition's destination, or ``None`` if there is none.

    §4.7's destination, not §6.3's: a definition's runs to the first
    whitespace (or to ``>``, in the pointy form), where an inline one runs
    to its closing ``)``. That is why :func:`_parse_destination` cannot be
    reused here despite parsing the same two forms.

    This exists because the definition scan's tail is deliberately greedy
    to the end of the line, which over-matches: ``[TODO]: revisit [a][r]
    later`` is yielded as a definition of ``TODO``. Harmless while nothing
    consumed the span — but the scanner's ``_blank_reference_definitions`` now cuts
    that span out of the region, so the whole line, links and all, left
    the index. Blanking stops at the destination instead, so prose a
    reader still parses survives the cut.

    Args:
        clean: Body text with code removed and line endings normalised.
        pos: Index of the tail's first character. ``_RE_REF_DEF_TAIL``'s
            ``(.+)`` guarantees one exists, so this never reads past the
            end — but it may be a *space*, since the pattern backtracks
            to leave one behind on a tail of pure whitespace, and that is
            the "no destination here" case.

    Returns:
        The index just past the destination, or ``None`` when nothing
        parses as one — in which case the caller keeps the greedy end,
        since there is no better answer than the one the scan already had.
    """
    if clean[pos] == "<":
        index = pos + 1
        while index < len(clean) and clean[index] not in ">\n":
            index += 2 if clean[index] == "\\" else 1
        return index + 1 if index < len(clean) and clean[index] == ">" else None
    index = pos
    while index < len(clean) and clean[index] not in " \t\n":
        index += 2 if clean[index] == "\\" else 1
    return min(index, len(clean)) if index > pos else None


#: A definition's optional title, and nothing else, to the line's end. What
#: follows the destination is blanked with it when it is a title, and left
#: alone when it is prose.
_RE_TITLE_ONLY = re.compile(
    r"""[ \t]*(?:"(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*'|\((?:[^()\\]|\\.)*\))[ \t]*"""
)


def _blank_end(clean: str, tail: re.Match[str], dest_end: int) -> int:
    """How far the scanner's ``_blank_reference_definitions`` may cut this definition.

    To the end of the destination, plus a trailing title when the rest of
    the line is exactly one. Anything else on the line is prose a reader
    still parses, so it stays — that is the whole point of not simply
    using ``tail.end()``.
    """
    rest = clean[dest_end : tail.end()]
    return tail.end() if _RE_TITLE_ONLY.fullmatch(rest) else dest_end


def iter_definition_matches(clean: str) -> Iterator[tuple[str, str, int, int, int]]:
    """Yield ``(label, target, start, end, target_start)`` per ``[label]: target``.

    The label is read by :func:`find_bracket_span` so an escaped ``]``
    does not close it (#1519); the rest keeps the shape of the pattern this
    replaced (``^\\s*\\[([^\\]]+)\\]:\\s*(.+)$``, multi-line), including the
    destination's freedom to sit on the next line and the greedy run to
    that line's end — **except where §4.7 says the old pattern was wrong**.
    Neither the destination nor the label may cross a blank line, and the
    old pattern let both; a label must hold a non-whitespace character,
    and ``[^\\]]+`` admitted ``[ ]``. The greedy tail is kept, because the
    table has always been built from it, but *end* no longer follows it —
    see :func:`_blank_end`.

    Args:
        clean: Body text with code removed and line endings normalised.

    Yields:
        ``(label, target, start, end, target_start)`` — both as written
        and neither stripped, with *start* and *end* bounding the whole
        definition so that the scanner's ``_blank_reference_definitions``
        can cut it out, and *target_start* the index of *target*'s first
        character so that a rewrite can splice it in place.
    """
    pos = 0
    while (opener := _RE_REF_DEF_OPEN.search(clean, pos)) is not None:
        bracket = opener.end() - 1
        span = find_bracket_span(clean, bracket)
        if span is None:
            # ``return``, not ``continue``: the scan starts on that ``[``,
            # so a span is missing only when no unescaped ``]`` follows it
            # anywhere — and a later definition would need one too.
            return
        _, close_index, label = span
        tail = (
            _RE_REF_DEF_TAIL.match(clean, close_index + 2)
            # A label may run across a line ending but never across a
            # *blank* one (§6.3), and the span scan does not know that: in
            # ``[ar]\n[\n\n[ar]: x.md`` the stray ``[`` opened a label that
            # swallowed the blank line and the real definition with it, so
            # ``ar`` was never defined at all. Invisible until the shortcut
            # form (#1531) started resolving against this table.
            #
            # A blank line is one holding only spaces or tabs, not just
            # ``\n\n``: testing for the literal pair let the same defect
            # through on the whitespace-dirty spelling, which is the more
            # common one in a hand-edited note.
            if label
            and _RE_BLANK_LINE.search(label) is None
            and clean[close_index + 1 : close_index + 2] == ":"
            else None
        )
        dest_end = (
            None if tail is None else _definition_destination_end(clean, tail.start(1))
        )
        if tail is None or dest_end is None:
            # Not a definition after all — either nothing followed the
            # ``:``, or what did is no destination: ``[r]:`` alone and
            # ``[r]: <unclosed`` both define nothing, and a reader reads
            # such a line as ordinary prose, so a ``[r]`` in it is a
            # shortcut like any other. Rejecting it *here* rather than
            # when blanking is what keeps the table and the cut in
            # lockstep: leave it in the table and the label resolves to
            # junk; drop it from the cut alone and the two disagree.
            #
            # Resume past this ``[``, where the engine's next start
            # position would have been; the label's own ``]`` is not a
            # safe resume point, since a line start inside the span can
            # open a definition of its own.
            pos = bracket + 1
            continue
        yield (
            label,
            tail.group(1),
            opener.start(),
            _blank_end(clean, tail, dest_end),
            tail.start(1),
        )
        pos = tail.end()


def iter_reference_targets(clean: str) -> Iterator[tuple[str, str, int]]:
    """Yield ``(key, destination, offset)`` for each definition that names a link.

    The table the scanner resolves usages against and the rewrite that
    repoints a definition read the same definitions through this one
    generator, so they cannot disagree about which lines are definitions
    or where a destination sits.

    Args:
        clean: Body text with code removed or masked and line endings
            normalised.

    Yields:
        The lower-cased label, the destination as written with its title
        stripped, and the index in *clean* where that destination starts.
    """
    for label, target, _start, _end, target_start in iter_definition_matches(clean):
        key = label.strip().lower()
        if not key:
            # §4.7 requires a non-whitespace character in the label, and
            # the old pattern's ``[^\]]+`` admitted ``[ ]``, keying it as
            # ``""``. Another latent table entry nothing could reference
            # until the shortcut rung arrived, at which point both ``[]``
            # and ``[ ]`` resolved against it — the second being every
            # unchecked task-list box in the vault.
            continue
        if key.startswith(FOOTNOTE_LABEL_PREFIX):
            # Footnote definition: the body is prose, so storing it as a
            # target resolved whatever the footnote said as a vault path.
            continue
        # The destination as written, title stripped (escape-aware): the
        # pointy, escaped and entity spellings are decoded at resolution,
        # like an inline destination (#1353).
        destination = trailing_title_pattern.sub("", target.strip(" \t")).strip(" \t")
        if destination and destination != "<>":
            yield key, destination, target_start


def _inline_destination_spans(masked: str) -> Iterator[tuple[int, str]]:
    r"""Yield ``(offset, destination)`` for each inline link in *masked*.

    The links are read by :func:`iter_inline_links`, the same scan the
    index is built with, because a rewrite has to see exactly the links the
    index holds. It did not: the class this replaces
    (``(?<!!)(\[[^\]]*?\])\(``) could not cross an escaped ``]``, so after
    #1517 made ``[Bra\]cket](old.md)`` an indexed link, a rename computed a
    replacement for it and then quietly matched nothing (#1521).

    The scan is also what keeps the rewrite linear. An escape-aware class
    is not affordable here even though a literal destination follows it:
    39 KB of ``[a\]b`` costs it about 5 s, quadrupling per doubling, and
    the class it replaces is already quadratic on a run of bare ``[``
    (285 ms at 8000). The scan is a single pass over both.

    Only the destination is matched literally: each replacement key
    is the destination as the file spells it, which is what the index
    stored, so an equality test is the right one and the pointy, encoded
    and escaped spellings need no special case here.

    Args:
        masked: File content with code masked by :func:`_mask_code`.

    Yields:
        Where each destination starts and the destination as written.

    The scan reports where each destination starts, and the splice uses
    that offset rather than searching the region for the destination. A search
    finds the wrong occurrence whenever the text after the destination
    repeats it: given ``[a](x.md "the x.md note")`` it rewrote the title
    and left the destination stale, a broken link reported as a successful
    rewrite. Caught in review of #1526; the scan this replaced anchored at
    a fixed offset and so never had the ambiguity.

    """
    for link in iter_inline_links(masked):
        yield link.target_start, link.raw_target


def _mask_code(content: str) -> str:
    """Mask code with equal-length spaces while retaining line endings."""

    def mask(match: re.Match[str]) -> str:
        return re.sub(r"[^\r\n]", " ", match.group())

    return _RE_INLINE_CODE.sub(mask, _RE_FENCED_CODE.sub(mask, content))


#: A wikilink around one target key. The scanner strips a target's
#: surrounding whitespace and a table-cell ``\`` before ``|`` (#731); only the
#: key group is replaced, so both and the alias survive.
_WIKI_OPEN = r"\[\[[^\S\n]*("
_WIKI_CLOSE = r")[^\S\n]*\\?[^\S\n]*(?=\]\]|\|[^\]]*\]\])"


def _wikilink_destination_spans(
    masked: str, keys: Iterable[str]
) -> Iterator[tuple[int, str]]:
    """Yield ``(offset, target)`` for each wikilink in *masked* naming a key."""
    alternatives = "|".join(
        re.escape(key) for key in sorted(keys, key=len, reverse=True)
    )
    for match in re.finditer(_WIKI_OPEN + alternatives + _WIKI_CLOSE, masked):
        yield match.start(1), match.group(1)


def rewrite_link_destinations(
    content: str, link_type: str, replacements: Mapping[str, str]
) -> tuple[str, set[str]]:
    """Replace original link destinations without cascading replacements.

    Every destination is found by the scan the index is built with, in the
    file's own offsets, and spliced once; a replacement never feeds another.

    Args:
        content: Full file content to modify, frontmatter excluded.
        link_type: One of ``"markdown"``, ``"reference"``, ``"wikilink"``.
        replacements: Original raw targets mapped to their replacements.

    Returns:
        ``(content, matched)``: the updated content and the keys of
        *replacements* that named at least one destination, so a caller can
        tell a rewrite that found every link from one that missed some.
    """
    masked = _mask_code(content)
    spans: Iterator[tuple[int, str]] = iter(())
    if replacements and link_type == "markdown":
        spans = _inline_destination_spans(masked)
    elif replacements and link_type == "reference":
        spans = (
            (offset, dest) for _key, dest, offset in iter_reference_targets(masked)
        )
    elif replacements and link_type == "wikilink":
        spans = _wikilink_destination_spans(masked, replacements)
    out: list[str] = []
    matched: set[str] = set()
    read = 0
    for start, key in spans:
        new_raw = replacements.get(key)
        if new_raw is None:
            continue
        out.extend((content[read:start], new_raw))
        read = start + len(key)
        matched.add(key)
    out.append(content[read:])
    return "".join(out), matched


def apply_link_replacement(
    content: str, link_type: str, old_raw: str, new_raw: str
) -> str:
    """Replace all occurrences of one written link destination.

    Args:
        content: Full file content to modify.
        link_type: One of ``markdown``, ``reference``, or ``wikilink``.
        old_raw: The original destination.
        new_raw: The replacement destination.

    Returns:
        Updated content with matching destinations replaced.
    """
    return rewrite_link_destinations(content, link_type, {old_raw: new_raw})[0]
